package jalon1;

import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;

import javax.swing.JOptionPane;
public class Jeu {

	public static void main(String[] args) {
		int taille=15;
		int pourcentage=10;
		int rocher=(int)((taille-1)*(taille-1)*((double)(pourcentage)/(double)(100)));
		boolean finished=false;
		boolean []membre=new boolean[]{true,true,false,false,true,true,false,false};
		int equipe=0;
		InputEvent event;
		String[] elements={"images/mer.png","images/sable.png","images/1.navire.png",
				"images/rocher.png","images/2.navire.png","images/1.explorateur.png",
				"images/2.explorateur.png","images/1.voleur.png","images/2.voleur.png",
				"images/arbre","images/coffre.png",};
		// Ici choix du mode de jeu (mode test, mode jeu ...)
		Ile ile=new Ile(taille,rocher);
		Ile navire=new Ile(2);
		System.out.println(ile);
		Plateau [] grille=new Plateau [4]; 
		grille[0]=new Plateau(elements,taille,true,"Plateau de jeu");
		grille[1]=new Plateau(elements,taille,true,"Plateau de jeu");
		grille[2]=new Plateau(elements,2,true,"Navire");
		grille[3]=new Plateau(elements,2,true,"Navire");
		//ile.PlacerExplorateurs();
		while(!finished){
			grille[1-equipe].masquer();
			grille[equipe].setJeu(ile.getJeu());
			grille[equipe].affichage();
			int x=0,y=0;
			do{
				event = grille[equipe].waitEvent();
				if(event instanceof MouseEvent){
					y = grille[equipe].getX((MouseEvent) event);
					x = grille[equipe].getY((MouseEvent) event);
				}
			}while (!(event instanceof MouseEvent));
			grille[equipe].println("x : "+x+" y : "+y+" equipe "+equipe+" entier "+ile.getInt(x,y));
			if (equipe==0){
					if(ile.getInt(x, y)==3){ //Selection du navire
						navire.setNavire(membre[0],membre[1],membre[2],membre[3]);
						grille[equipe+2].setJeu(navire.getJeu());
						grille[equipe+2].affichage();						
					}
					if(ile.getInt(x,y)==6){  //Selection de l explorateur
						grille[0].println("c est un explorateur");
						do{ event = grille[equipe].waitEvent();
							if(event instanceof MouseEvent){
								y = grille[equipe].getX((MouseEvent) event);
								x = grille[equipe].getY((MouseEvent) event);
							}
						}while (!(event instanceof MouseEvent));
						grille[equipe].println("x : "+x+" y : "+y+" bis");
						ile.Deplacer(new Explorateur(6),x,y);
						
					}
					if(ile.getInt(x,y)==8){
						grille[0].println("c est un voleur"); // Selection du voleur
						do{ event = grille[equipe].waitEvent();
							if(event instanceof MouseEvent){
								y = grille[equipe].getX((MouseEvent) event);
								x = grille[equipe].getY((MouseEvent) event);
							}
						}while (!(event instanceof MouseEvent));
						grille[equipe].println("x : "+x+" y : "+y+" bis");
						ile.Deplacer(new Voleur(8),x,y);
					}
					if(ile.getParcelle(x,y) instanceof Piegeur){
	
					}
					if(ile.getParcelle(x,y) instanceof Guerrier){
	
					}
			}else{
				if(ile.getInt(x, y)==5){ //Selection du navire
					navire.setNavire(membre[4],membre[5],membre[6],membre[7]);
					grille[equipe+2].setJeu(navire.getJeu());
					grille[equipe+2].affichage();	
				}
				if(ile.getInt(x,y)==7){ //Selection de l explorateur
					grille[0].println("c est un explorateur");
					do{ event = grille[equipe].waitEvent();
						if(event instanceof MouseEvent){
							y = grille[equipe].getX((MouseEvent) event);
							x = grille[equipe].getY((MouseEvent) event);
						}
					}while (!(event instanceof MouseEvent));
					grille[equipe].println("x : "+x+" y : "+y+" bis");
					ile.Deplacer(new Explorateur(7),x,y);
				}if(ile.getInt(x,y)==9){ //Selection du voleur
					grille[0].println("c est un voleur");
					do{ event = grille[equipe].waitEvent();
						if(event instanceof MouseEvent){
							y = grille[equipe].getX((MouseEvent) event);
							x = grille[equipe].getY((MouseEvent) event);
						}
					}while (!(event instanceof MouseEvent));
					grille[equipe].println("x : "+x+" y : "+y+" bis");
					ile.Deplacer(new Voleur(9),x,y);
				}if(ile.getParcelle(x,y) instanceof Piegeur){

				}if(ile.getParcelle(x,y) instanceof Guerrier){

				}
			}
			equipe=1-equipe;
		}
	}
	/** Renvoie un chaine de charactere correspondant au choix de l utilisateur(quel personnage deplacer) via un JOptionPane. **/
	public static String ChoixPersonnage(){
		String[] personnage = new String[]{"Explorateur","Voleur"};
		String choix = null;
		choix = (String)JOptionPane.showInputDialog(null,"Choississez le personnage que vous aller déplacer","Personnage",JOptionPane.QUESTION_MESSAGE, null, personnage, personnage[0]);
		return choix;
	}
}
/* 1=mer
 * 2=herbe
 * 3=Navire 1
 * 4=Rocher
 * 5=Navires 2
 * 6=explorateur 1
 * 7=explorateur 2
 * 8=voleur 1
 * 9=voleur 2*/