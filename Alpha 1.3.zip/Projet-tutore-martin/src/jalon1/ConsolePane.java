package jalon1;

import java.util.Scanner;

import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

 public class ConsolePane extends JScrollPane {
	static final long serialVersionUID = 3L;
	private JTextArea textArea ;
	Scanner sc =new Scanner(System.in);
	public ConsolePane() {
		super() ;
		textArea = new JTextArea() ;
		textArea.setEditable(false) ;
		textArea.setFocusable(false) ;
		textArea.setText("Console:\n") ;
		this.setViewportView(textArea) ;
	}
	public void println(String message) {
		textArea.append(message + '\n') ;
		// Positionne la scrollPane à son extrémité inférieure.
		JScrollBar vertical = this.getVerticalScrollBar() ;
		vertical.setValue(vertical.getMaximum()) ;
	}
	public boolean interact(String question){
		final char reponse_OUI='O';
		final char reponse_NON='N';
		char reponse=sc.nextLine().charAt(0);
		if(reponse == reponse_OUI){
			return true;
		}else if(reponse == reponse_NON){
			return false;
		}
		return false;
	}
}
