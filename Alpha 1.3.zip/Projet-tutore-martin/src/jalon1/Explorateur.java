package jalon1;

public class Explorateur extends Parcelle{
	private int energy;
	private boolean coffreFound;
	public boolean getCoffreFound() {
		return coffreFound;
	}
	public void setCoffreFound(boolean coffreFound) {
		this.coffreFound = coffreFound;
	}
	private boolean clef,coffre;
	public Explorateur(int n) {
		super(n);
	}
	public int getEnergy() {
		return energy;
	}
	public void setEnergy(int energy) {
		this.energy = energy;
	}
	public boolean getCoffre(){
		return coffre;
	}
	public boolean getClef(){
		return clef;
	}
	public void setClef(boolean clef){
		this.clef=clef;
	}
	public void setCoffre(boolean coffre){
		this.coffre=coffre;
	}
}
