package barreVie;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextField;


public class SquadMaker implements ActionListener ,  MouseListener{
	/* DECLARATION DES VARIABLES OBJET */
	protected JFrame frame;
	protected int equipe;
	protected JPanel PANE_MENULIST;
	protected JPanel VOS_CHOIX;
	protected JButton explorateur,voleur,piegeur,guerrier;
	protected JProgressBar barre = new JProgressBar( );
	protected int currentValue=8;
	protected JOptionPane content=new JOptionPane("Contenu de ton bateau");
	protected final String content_explorateur="|   Explorateur    ";
	protected final String content_voleur="|    Voleur   ";
	protected final String content_piegeur="|  Piegeur   ";
	protected final String content_guerrier="|    Guerrier  |";
	protected String contenu;
	protected int compteurElements=0;
	protected int[] parcelles =new int[4];


	public SquadMaker(int equipe) {
		this.equipe=equipe;
		frame=new JFrame(" Squad manager   ------------->      Equipe numero : "+(equipe+1));
		frame.getContentPane().setPreferredSize(new Dimension(800, 800));
		PANE_MENULIST=new JPanel();
		VOS_CHOIX=new JPanel();
		/*IMPLEMENTATION DES BOUTTONS*/
		explorateur=new JButton("Explorateur");
		explorateur.addActionListener(this);
		explorateur.setIcon(new ImageIcon("images/1.explorateur.png"));
		voleur=new JButton("Voleur");
		voleur.addActionListener(this);
		voleur.setIcon(new ImageIcon("images/1.voleur.png"));
		piegeur=new JButton("Piegeur");
		piegeur.addActionListener(this);
		piegeur.setIcon(new ImageIcon("images/1.piegeur.png"));
		guerrier=new JButton("Guerrier");
		guerrier.addActionListener(this);
		guerrier.setIcon(new ImageIcon("images/1.guerrier.png"));
		barre.setMinimum(0);
		// D�finir la valeur maximale de la barre de progression
		barre.setMaximum(this.currentValue);
		//VALEUR INITAILE DES CHOIX
		this.updateBar(100);
		barre.setBackground(Color.RED);
		barre.setForeground(Color.GREEN);
		//GESTION DES CHOIX UTILISATEUR
		// TODO
		/*LAYOUT MANAGE*/
		PANE_MENULIST.add(explorateur,BorderLayout.CENTER);
		PANE_MENULIST.add(voleur,BorderLayout.CENTER);
		PANE_MENULIST.add(piegeur,BorderLayout.CENTER);
		PANE_MENULIST.add(guerrier,BorderLayout.CENTER);
		/*GESTION DES PANELS*/
		frame.getContentPane().add(barre, BorderLayout.NORTH);
		frame.getContentPane().add(PANE_MENULIST, BorderLayout.CENTER);
		frame.add(content,BorderLayout.SOUTH);
		frame.setLocation(500, 500);
		frame.pack();
		frame.setVisible(true);
	}


	@Override
	public void mouseClicked(MouseEvent e) {


	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(explorateur)){
			this.updateBar((double)currentValue-1);
			currentValue -=1;
			contenu +=content_explorateur;
			if(equipe == 0)
				parcelles[compteurElements]=6;
			else
				parcelles[compteurElements]=7;
		}else if(e.getSource().equals(voleur)){
			this.updateBar((double)currentValue-2);
			currentValue -=2;
			contenu += content_voleur;
			if(equipe == 0)
				parcelles[compteurElements]=8;
			else
				parcelles[compteurElements]=9;
		}else if(e.getSource().equals(piegeur)){
			this.updateBar((double)currentValue-2);
			currentValue -=2;
			contenu += content_piegeur;
			if(equipe == 0)
				parcelles[compteurElements]=10;
			else
				parcelles[compteurElements]=11;
		}else{
			this.updateBar((double)currentValue-3);
			currentValue -=3;
			contenu += content_guerrier;
			if(equipe == 0)
				parcelles[compteurElements]=12;
			else
				parcelles[compteurElements]=13;
		}
		compteurElements += 1;
		if(compteurElements >= 4 ){
			content.setMessage("Votre bateau contient : "+ contenu);
			recap();
		}
		this.frame.pack();
		this.frame.repaint();
	}
	public static void main(String[] args) {
		SquadMaker s=new SquadMaker(0);
		SquadMaker s2=new SquadMaker(1);
	}
	public void updateBar(double newValue)
	{
		barre.setValue((int) newValue); // methode permettant de mettre a jour la barre
	}
	public void recap(){
		for (int i = 0; i < parcelles.length; i++) {
			System.out.println(parcelles[i]);
		}
	}

}
