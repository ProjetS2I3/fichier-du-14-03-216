package jalon1;

import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import javax.swing.JOptionPane;
public class Jeu {

	public static void main(String[] args) {
		int taille=15;
		int pourcentage=10;
		int rocher=(int)((taille-1)*(taille-1)*((double)(pourcentage)/(double)(100)));
		boolean finished=false;
		String s="";
		int equipe=0;
		InputEvent event;
		String[] elements={"images/mer.png","images/herbe.png","images/1.navire.png",
				"images/rocher.png","images/2.navire.png","images/1.explorateur.png",
				"images/2.explorateur.png","images/1.voleur.png","images/2.voleur.png",
				"images/arbre","images/coffre.png",};
		// Ici choix du mode de jeu (mode test, mode jeu ...)
		Ile ile=new Ile(taille,rocher);
		System.out.println(ile);
		Plateau [] grille=new Plateau [2]; grille[0]=new Plateau(elements,taille,true);
		grille[1]=new Plateau(elements,taille,true);
		//ile.PlacerExplorateurs();
		while(!finished){
			grille[equipe].setJeu(ile.getJeu());
			grille[equipe].affichage();
			do{
				event = grille[equipe].waitEvent();
			}while (event instanceof KeyEvent);
			int x = grille[equipe].getX((MouseEvent) event);
			int y = grille[equipe].getY((MouseEvent) event);
			if (equipe==0){
				if(ile.getParcelle(x,y) instanceof Explorateur){
					x = grille[equipe].getX((MouseEvent) event);
					y = grille[equipe].getY((MouseEvent) event);
					if(ile.getParcelle(x,y) instanceof Rocher){
						ile.Deplacer(new Explorateur(6),x,y);
					}
				}if(ile.getParcelle(x,y) instanceof Voleur){

				}if(ile.getParcelle(x,y) instanceof Piegeur){

				}if(ile.getParcelle(x,y) instanceof Guerrier){

				}
			}
			//try{Thread.sleep(1000);}catch(Exception ie){}
			//s=ChoixPersonnage();
			/*if(equipe==0) {
					if (s.equals("Explorateur")){ile.Deplacer(new Explorateur(6),ile.ChoixDeplacement(new Explorateur(6)));}
					if (s.equals("Voleur")){ile.Deplacer(new Voleur(8),ile.ChoixDeplacement(new Voleur(8)));}
				}else{
					if (s.equals("Explorateur")){ile.Deplacer(new Explorateur(7),ile.ChoixDeplacement(new Explorateur(7)));}
					if (s.equals("Voleur")){ile.Deplacer(new Voleur(9),ile.ChoixDeplacement(new Voleur(9)));}
				}*/
			equipe=1-equipe;
		}
		//grille[1]=new Plateau(elements,taille,false);
		/*for (int e = 0 ; e < 2 ; e++) {
			grille[e].setJeu(ile.getJeu());
		}*/
		/*int x=1,equipe=0;
		while (!finished){
			InputEvent event ;
			grille[equipe].setJeu(ile.getJeu());
			event =grille[equipe].waitEvent(3000);
			if(x!=taille-2 && ile.getInt(x,4)!=4){
				ile.PlacerCase(new Explorateur(6), x, 4);
				ile.PlacerCase(new Parcelles(2), x-1, 4);
				x++;
			}
			equipe = 1-equipe ;
		}*/
	}
	/** Renvoie un chaine de charactere correspondant au choix de l utilisateur(quel personnage deplacer) via un JOptionPane. **/
	public static String ChoixPersonnage(){
		String[] personnage = new String[]{"Explorateur","Voleur"};
		String choix = null;
		choix = (String)JOptionPane.showInputDialog(null,"Choississez le personnage que vous aller déplacer","Personnage",JOptionPane.QUESTION_MESSAGE, null, personnage, personnage[0]);
		return choix;
	}
}
/* 1=mer
 * 2=herbe
 * 3=Navire 1
 * 4=Rocher
 * 5=Navires 2
 * 6=explorateur 1
 * 7=explorateur 2
 * 8=voleur 1
 * 9=voleur 2*/