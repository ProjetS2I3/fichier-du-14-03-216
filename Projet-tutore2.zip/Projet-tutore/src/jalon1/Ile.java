package jalon1;

import java.util.Random;

import javax.swing.JOptionPane;
import javax.swing.Popup;
public class Ile {
	private Parcelle [][]ile;
	private int rocher=0;
	private Random r=new Random();
	/** Constructeur par defaut sans parametres, cree un tableau 10x10 de Parcelles et initialise ce tableau via la methode init(). 
	 * @param null
	 * @return cree une nouvelle ile par defaut ; de dimesions 10*10
	 * **/
	public Ile(){
		ile=new Parcelle[10][10];
		for (int i = 0; i < ile.length; i++) {
			for (int j = 0; j < ile.length; j++) {
				if(i == 0 || i== 9 || j == 0 || j == 9){
					this.ile[i][j]=new Parcelle(1);
				}else{
					this.ile[i][j]=new Parcelle(2);
				}
			}
		}
	}
	public Ile(int taille){
		ile=new Parcelle[2][2];
	}
	/** Constructeur avec en parametre la taille de l'ile ainsi que le nombre de rocher sur l ile, et initialise ce tableau via la methode init().
	 * @param taille
	 * @param nbrocher
	 * @return cree une ile avec les attributs nbrocher et taille chosis
	 * **/
	public Ile(int taille,int nbrocher){
		ile=new Parcelle[taille][taille];
		init(nbrocher);
	}
	/** Initialise les elements de l ile (mer ,navires ,rochers ,clef ,coffre). 
	 * @param nbrochers
	 * **/
	public void init(int nbrocher){
		int x,y;
		for (int i=0 ; i< ile.length ; i++){
			for (int j=0 ; j< ile.length ; j++){
				if (i==0 || i==ile.length-1 || j==0 || j==ile.length-1){
					this.ile[i][j]=new Parcelle(1);
				}else{
				PlacerCase(new Parcelle(2), i, j);}
			}
		}
		x=r.nextInt(ile.length-2)+1;
		y=r.nextInt(2);
		if(y==0){
			PlacerCase(new Navire(3), x, 0);
			PlacerCase(new Navire(5), ile.length-1-x, ile.length-1);
			//PlacerCase(new Explorateur(6),x,1);
			//PlacerCase(new Explorateur(7),ile.length-1-x, ile.length-2);
			//PlacerCase(new Voleur(8),x+1,1);
			//PlacerCase(new Voleur(9),ile.length-1-x+1, ile.length-2);
		}else {
			PlacerCase(new Navire(3), 0, x);
			PlacerCase(new Navire(5), ile.length-1, ile.length-1-x);
			//PlacerCase(new Explorateur(6),1,x);
			//PlacerCase(new Explorateur(7),ile.length-2,ile.length-1-x);
			//PlacerCase(new Voleur(8),1,x+1);
			//PlacerCase(new Voleur(9),ile.length-2,ile.length-1-x+1);
		}
		while (rocher<nbrocher){
			x=r.nextInt(ile.length-2)+1;
			y=r.nextInt(ile.length-2)+1;
			if (ile[x][y].remplacable() && rocherPlacable(x, y)){
			    rocher++;
				PlacerCase(new Rocher(4), x, y);
			}
		}
		placerClefCoffre(nbrocher);
	}
	/** Renvoie un booleen, vrai si la parcelle correspondante (parametres x et y) n a pas de rochers ou de navires adjacents. 
	 * @param int x
	 * @param int y
	 * @return true si possible false sinon
	 * **/
	public boolean rocherPlacable(int x,int y){
		if (ile[x][y+1].getInt()==4 || 
			ile[x][y-1].getInt()==4 || 
			ile[x+1][y].getInt()==4 || 
			ile[x-1][y].getInt()==4 ||
			ile[x][y-1].getInt()==3 ||
			ile[x][y+1].getInt()==3 ||
			ile[x+1][y].getInt()==3 || 
			ile[x-1][y].getInt()==3 ||
			ile[x][y-1].getInt()==5 ||
			ile[x][y+1].getInt()==5 ||
			ile[x+1][y].getInt()==5 || 
			ile[x-1][y].getInt()==5 /*||
			ile[x+1][y+1].getInt()==4 || 
			ile[x+1][y-1].getInt()==4 || 
			ile[x-1][y+1].getInt()==4 || 
			ile[x-1][y-1].getInt()==4*/){
			return false;
		}
		return true;
	}
	/** Place la clef ainsi que le coffre sous deux rochers distinct, prend en parametre le nombre de rochers sur l ile.
	 * @param int x
	 * @param int y
	 * @return true si possible false sinon
	 * **/
	public void placerClefCoffre(int rocher){
		int nbRocher=0;
		Random r=new Random();
		int Rclef=r.nextInt(rocher)+1;
		int Rcoffre;
		do{
		Rcoffre=((r.nextInt(rocher)+1+5)%rocher)+1;
		}while (Rcoffre==Rclef);
		boolean clef=false,coffre=false;
			for (int i=0 ; i<ile.length ; i++){
				for (int j=0 ; j<ile.length ; j++){
					if (ile[i][j].getInt()==4){nbRocher++;}
					if (nbRocher==Rclef && !clef){PlacerCase(new Rocher(4,true,false), i, j); clef=true;/*System.out.println("Clef sous le "+nbRocher+"eme rocher en x="+i+" et y="+j);*/}
					if (nbRocher==Rcoffre && !coffre){PlacerCase(new Rocher(4,false,true), i, j);coffre=true;/*System.out.println("Coffre sous le "+nbRocher+"eme rocher en x="+i+" et y="+j);*/}
				}
			}
	}
	/** Renvoie un tableau d'entier ou chaque entier correspond a l entier de sa parcelle. **/
	public int [][] getJeu(){
		int [][] result=new int [ile.length][ile.length];
		for (int i=0 ; i<ile.length ; i++){
			for (int j=0 ; j<ile.length ; j++){
				result[i][j]=ile[i][j].getInt();
			}
		}
		return result;
	}
	public void setNavire(boolean explorateur,boolean voleur,boolean piegeur,boolean guerrier,int equipe){
		if (equipe==0){
			if (explorateur) ile[0][0]=new Explorateur(6);
			else ile[0][0]=new Parcelle(2);
			if (voleur) ile[0][1]=new Voleur(8);
			else ile[0][1]=new Parcelle(2);
			if (piegeur) ile[1][0]=new Piegeur(10);
			else ile[1][0]=new Parcelle(2);
			if (guerrier) ile[1][1]=new Guerrier(12);
			else ile[1][1]=new Parcelle(2);
		}else{
			if (explorateur) ile[0][0]=new Explorateur(7);
			else ile[0][0]=new Parcelle(2);
			if (voleur) ile[0][1]=new Voleur(9);
			else ile[0][1]=new Parcelle(2);
			if (piegeur) ile[1][0]=new Piegeur(11);
			else ile[1][0]=new Parcelle(2);
			if (guerrier) ile[1][1]=new Guerrier(13);
			else ile[1][1]=new Parcelle(2);
		}
		
	}
	/** Retourne l entier correspondant a la parcelle d indice x,y 
	 * @param int x
	 * @param int y
	 * **/
	public int getInt(int x,int y){
		return ile[x][y].getInt();
	}
	public Parcelle getParcelle (int x, int y){
		return ile[x][y];
	}
	/** Place un element (Parcelles) a la case correspondante (x,y) du tableau de Parcelles ile, parametres : l element, coordonnees x et y. **/
	public void PlacerCase(Parcelle element,int x,int y){
		ile[x][y]=element;
	}
	/** Place un explorateur sur l ile en x et y, x et y sont des saisies de l utilisateur via deux JOptionPane. **/
	public void PlacerExplorateurs(){
		JOptionPane pane=new JOptionPane();
		int x=0,y=0;
		String value;
		boolean b;
		do{
			value=pane.showInputDialog("Placement de l'explorateur: \n      x:"); // value prend la valeur de l entree du JOptionPane
			b=value.matches("\\d*(\\d+)"); // b prend la valeur vrai si value est un nombre
			if (b) x=Integer.parseInt(value); // si b est vrai alors x prend la valeur de l entree de JOP
		}while (!b || x<1 || x>ile.length-2); // recommence jusqua ce que b soit vrai, et que 1<x<14
		do{
			value=pane.showInputDialog("Placement de l'explorateur: \n      y:");
			b=value.matches("\\d*(\\d+)"); // value prend la valeur de l entree du JOptionPane
			if(b) y=Integer.parseInt(value); // si b est vrai alors y prend la valeur de l entree de JOP
		}while (!b || y<1 || y>ile.length-2); // recommence jusqua ce que b soit vrai, et que 1<y<14
		if (ile[x][y].getInt()==2){ // si en [x;y] c'est une parcelle vide
			PlacerCase(new Explorateur(6),x,y);
		}else{ // sinon appel recursif sur la methode
			PlacerExplorateurs();
		}	    
	}
	/** Renvoie un tableau d entier correspondant aux indices x et y de l emplacement d une parcelle dans le tableau de parcelle (ile) 
	 * @param element, type Parcelle (element que l on cherche)
	 * **/
    public int[] SearchElement(Parcelle element){
		for (int x=0 ; x<ile.length ; x++){
			for (int y=0 ; y<ile.length ; y++){
				if (ile[x][y].getInt()==element.getInt()){
					return new int[]{x,y};
				}
			}
		}
		return null;
	}
	/** Methode de deplacement d une parcelle dans le tableau de parcelle (ile) en fonction de la chaine choix (Nord Sud Est Ouest)
	 * @param element de type Parcelles
	 * @param choix visant la methode choix qui genere un boite de dialogue
	 * **/
	public void Deplacer(Parcelle element,int x, int y){
		int [] emplacement=SearchElement(element);
		if (deplacementValide(element,x,y)) actionPersonnage(emplacement[0],emplacement[1],x,y);
	}
	public boolean deplacementValide(Parcelle element,int x, int y){
		int [] emplacement=SearchElement(element);
		boolean retour=false;
		if (element instanceof Explorateur || element instanceof Piegeur || element instanceof Guerrier){
			if (emplacement[0]==x && emplacement[1]-1==y||emplacement[0]==x && emplacement[1]+1==y ||
			    emplacement[0]+1==x && emplacement[1]==y||emplacement[0]-1==x && emplacement[1]==y)
				retour=true;
			
		}else if (element instanceof Voleur){
			if (emplacement[0]==x && emplacement[1]-1==y||emplacement[0]==x && emplacement[1]+1==y ||
				emplacement[0]+1==x && emplacement[1]==y||emplacement[0]-1==x && emplacement[1]==y ||
				emplacement[0]+1==x && emplacement[1]-1==y||emplacement[0]-1==x && emplacement[1]+1==y||
				emplacement[0]-1==x && emplacement[1]-1==y||emplacement[0]+1==x && emplacement[1]+1==y)
					retour=true;
				
		}
		return retour;
	}
	public void actionPersonnage(int x,int y,int a, int b){
		if(ile[x][y] instanceof Explorateur){
			if (ile[a][b].getInt()==2){
				ile[a][b]=ile[x][y];
				ile[x][y]=new Parcelle(2);
			}else if (ile[a][b] instanceof Rocher){
				fouillerRocher(a,b,x,y); //fouille du rocher en a;b par l explorateur en x;y
			}
		}else if (ile[x][y] instanceof Voleur){
			if (ile[a][b].getInt()==2){
				ile[a][b]=ile[x][y];
				ile[x][y]=new Parcelle(2);
			}
		}else if(ile[x][y] instanceof Piegeur){
			if (ile[a][b].getInt()==2){
				ile[a][b]=ile[x][y];
				ile[x][y]=new Parcelle(2);
			}
		}
		else if(ile[x][y] instanceof Guerrier){
			if (ile[a][b].getInt()==2){
				ile[a][b]=ile[x][y];
				ile[x][y]=new Parcelle(2);
			}
		}
	}
	/** Methode de fouille d un rocher en ile[x][y] par un explorateur en ile[a][b] (recuperation de la clef, du coffre automatiques)
	 * @param a coordonnee initiale 
	 * @param b coordonnee initiale
	 * @param x coordonnee a atteindre
	 * @param y coordonnee a atteindre
	 * **/
	public void fouillerRocher(int a,int b,int x,int y){
		popUP popup;
		if(((Rocher)ile[a][b]).getClef()){
			popup=new popUP("images/clef.png");
			popup.afficher("Clef trouv�e", "F�licitation vous avez trouv� la clef , il faut maintenant le coffre");
			((Rocher)ile[a][b]).setClef(false);
			((Explorateur)ile[x][y]).setClef(true);
		}
		if(((Rocher)ile[a][b]).getCoffre()){
			popup=new popUP("images/coffre.png");
			popup.afficher("Coffre trouv� ", "cherche maintenant la clef");
			if(((Explorateur)ile[x][y]).getClef()){
				popup=new popUP("images/coffreouvert.png");
				popup.afficher("Vous avez ouvert le coffre", "Partie gagn�e !");
				((Rocher)ile[a][b]).setCoffre(false);
				((Explorateur)ile[x][y]).setCoffre(true);
			}
		}popup=new popUP("images/info.png");
		popup.afficher("Rocher fouill�", "Aucune clef ni coffre trouv� , cherche ailleur");
	}
	/** Renvoie un chaine de charactere correspondant au choix du deplacement fait par l utilisateur via un JOptionPane 
	 * @param Parcelle element
	 * **/
	public String ChoixDeplacement(Parcelle element){
		String[] deplacementsExplorateur = new String[]{"Nord","Sud","Est","Ouest"};
		String[] deplacementsVoleur = new String[]{"Nord","Sud","Est","Ouest","Nord-Est","Nord-Ouest","Sud-Est","Sud-Ouest"};
		String choix = null;
		if (element instanceof Explorateur)
		choix = (String)JOptionPane.showInputDialog(null,"Choississez un deplacement","Direction",JOptionPane.QUESTION_MESSAGE, null, deplacementsExplorateur, deplacementsExplorateur[0]);
		if (element instanceof Voleur)
			choix = (String)JOptionPane.showInputDialog(null,"Choississez un deplacement","Direction",JOptionPane.QUESTION_MESSAGE, null, deplacementsVoleur, deplacementsVoleur[0]);
		return choix;
	}
	/** Renvoie une chaine correspondant a l affichage texte de l ile. **/
	public String toString() {
		String s = "";
		for (int i = 0 ; i < ile.length ; i++) {
			s += "+";
			for (int j = 0 ; j < ile.length ; j++) {
				s += "---+";
			}
			s += "\n|";

			for (int k = 0 ; k < ile.length ; k++) {
				s += " ";
				if (ile[k][i].getInt()==1){s +="~";}
				if (ile[k][i].getInt()==2){s +=" ";}
				if (ile[k][i].getInt()==3){s +="N";}
				if (ile[k][i].getInt()==4){s +="R";}
				if (ile[k][i].getInt()==5){s +="n";}
				if (ile[k][i].getInt()==6){s +="E";}// Ici la valeur des cases
				s += " |";
			}
			s += "\n";
		}
		s += "+";
		for (int l = 0 ; l < ile.length ; l++) {
			s += "---+";
		}
		return s;
	}
}