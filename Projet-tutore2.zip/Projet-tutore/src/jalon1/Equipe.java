package jalon1;

public class Equipe {
	Explorateur explorateur;
	Guerrier guerrier;
	Piegeur piegeur;
	Voleur voleur;

	public Equipe(int equipe){
		if(equipe == 0){
			explorateur=new Explorateur(6);
			guerrier=new Guerrier(12);
			piegeur=new Piegeur(10);
			voleur=new Voleur(8);
		}else{
			explorateur=new Explorateur(7);
			guerrier=new Guerrier(13);
			piegeur=new Piegeur(11);
			voleur=new Voleur(9);
			

		}
	}
}
/* 1=mer
 * 2=herbe
 * 3=Navire 1
 * 4=Rocher
 * 5=Navires 2
 * 6=explorateur 1
 * 7=explorateur 2
 * 8=voleur 1
 * 9=voleur 2*/