package gestionEvents;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

import ihm.HelloPaint;

public class Convertisor implements MouseListener {
	private JFrame frame;
	private JPanel pane;
	private JButton but1;
	private JButton but2;
	private JTextField field1;
	private JTextField field2;
	
	public Convertisor() {
		frame=new JFrame("convertisseur");
		but1=new JButton("€ ->£");
		but2=new JButton("£ -> €");
		pane=new JPanel();
		but2.setPreferredSize(new Dimension(75, 20));
		but1.setPreferredSize(new Dimension(75, 20));
		field1=new JTextField();
		field2=new JTextField();
		pane.setPreferredSize(new Dimension(200,100));
		pane.add(but1,BorderLayout.NORTH);
		pane.add(but2,BorderLayout.CENTER);
		field1.setSize(100,50);
		field2.setSize(100,50);
		field1.setText("              ");
		field2.setText("              ");
		field1.addMouseListener(this);
		field2.addMouseListener(this);
		frame.getContentPane().add(field1,BorderLayout.WEST);
		frame.getContentPane().add(field2,BorderLayout.EAST);
		frame.add(pane,BorderLayout.CENTER);
		frame.setPreferredSize(new Dimension(400, 100));
		frame.pack();
		frame.show();
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getSource().equals(field1)){
			System.out.println("1");
		}else if(e.getSource().equals(field2)){
			System.out.println("2");
		}
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	  public static void main(String args[]){
          javax.swing.SwingUtilities.invokeLater(new Runnable() {
                  public void run() {
                          new Convertisor();
                  }
          });
  }

}
