package gestionEvents;

import ihm.HelloPaint;

public class TestFigures {

}
