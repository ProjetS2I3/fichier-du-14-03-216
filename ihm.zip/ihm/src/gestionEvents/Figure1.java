package gestionEvents;

import java.awt.BorderLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


public class Figure1 implements ChangeListener ,MouseListener{
	static final int MIN = 0;
	static final int MAX = 100;
	static final int INIT = 50;
	JSlider bs;
	JFrame fen;
	JLabel label=new JLabel();
	int number = INIT;
	

	public Figure1() {
		fen=new JFrame("figure1");
		bs=new JSlider(JSlider.HORIZONTAL,MIN, MAX, INIT);
		fen.add(bs,BorderLayout.SOUTH);
		fen.add(label,BorderLayout.NORTH);
		bs.addChangeListener( this);
		bs.setMajorTickSpacing(30);
		bs.setMinorTickSpacing(10);
		bs.setPaintTicks(true);
		bs.setPaintLabels(true);
		fen.addMouseListener(this);
		label.setText(""+number);
		fen.pack();
		fen.setVisible(true);


	}
	public static void main(String args[]){
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new Figure1();
			}
		});

	}
	@Override
	public void stateChanged(ChangeEvent e) {
		 JSlider source = (JSlider)e.getSource();
		 if(source.equals(bs)){
			 number=source.getValue();
			 label.setText(""+number);
			 fen.pack();
			 fen.repaint();
			 
		 }
		
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getButton() == MouseEvent.BUTTON1){
			label.setText(""+(number-1));
			number -=1;
			fen.pack();
			fen.repaint();
		}else{
			label.setText(""+(number+1));
			number +=1;
			fen.pack();
			fen.repaint();
		}
		
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
