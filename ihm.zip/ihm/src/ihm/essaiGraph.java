package ihm;

import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
public class essaiGraph {

	public static void main(String[]args){

		Dimension dimension = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		int height = (int)dimension.getHeight();
		int width  = (int)dimension.getWidth();
		JFrame page =new JFrame();
		JPanel pane=new JPanel();
		 pane.setBackground(Color.DARK_GRAY);
		    pane.setLayout(new BorderLayout());
		    pane.setSize(width, height);
		page.add(pane);
		page.show();
		
		}

}
