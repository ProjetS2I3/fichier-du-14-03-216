package ihm;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.List;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.awt.Rectangle;

import javax.swing.JPanel;

public class Canvas extends JPanel implements MouseListener {
	int x=0;
	int y=0;
	ArrayList<Rectangle> rectancle=new ArrayList<Rectangle>();
	ArrayList<Point>points=new ArrayList<>();
	public void paintComponent(Graphics g) {
		addMouseListener(this);
		super.paintComponent(g);
		setBackground(Color.WHITE);
		g.setColor(Color.ORANGE);
		g. fillRect (x , y , 20 , 20);
		g.setColor(Color.BLACK);
		g. drawRect (x , y , 20 , 20); 
		for (Rectangle point : rectancle) {
			setBackground(Color.WHITE);
			g.setColor(Color.ORANGE);
			g.fillRect(point.x,point.y,20,20);
			g.setColor(Color.BLACK);
			g.drawRect(point.x, point.y,20,20);
		}
		g.setColor(Color.white);


		/*for(Rectangle : rect){	
                }*/
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		x=e.getX();
		y=e.getY();
		if(e.getButton() == MouseEvent.BUTTON1){
			rectancle.add(new Rectangle(x,y,20,20));
			points.add(new Point(x, y));
		}else if(e.getButton() == MouseEvent.BUTTON2){
			System.out.println("ok");
			for (Rectangle reck : rectancle) {
				if(reck.getX() == x && reck.getY()== y ){
					rectancle.remove(reck);
					System.out.println("ok");
				}
			}

		}
		repaint();
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}
}
