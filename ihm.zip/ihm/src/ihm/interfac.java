
import java.awt.Dimension;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class interfac {

  public interfac() {
    /*JFrame fenetre = new JFrame("test");
    JLabel text=new JLabel("NORD");
    JDialog dialog=new JDialog(fenetre,"Jdialog");
    dialog.setPreferredSize(new Dimension(200,100));
    fenetre.setPreferredSize(new Dimension(400,200));
    fenetre.setLocation(500, 300);
    fenetre.getContentPane().add(new JButton("nord"),BorderLayout.NORTH);
    fenetre.getContentPane().add(new JButton("center"),BorderLayout.CENTER);
    fenetre.getContentPane().add(new JButton("sud"),BorderLayout.SOUTH);
    fenetre.getContentPane().add(new JButton("est"),BorderLayout.EAST);
    fenetre.getContentPane().add(new JButton("ouest"),BorderLayout.WEST);
    fenetre.pack();
    fenetre.setLocationRelativeTo(null);
    fenetre.setResizable(false);
    fenetre.setVisible(true);*/
    //dialog.setLocation(200, 200);
    //dialog.pack();
    //dialog.setLocationRelativeTo(null);
    //dialog.setVisible(true);
    /*JFrame fenetre2 = new JFrame("test");
    fenetre2.getContentPane().setLayout(new FlowLayout(FlowLayout.CENTER));
    fenetre2.setPreferredSize(new Dimension(400,300));
    for (int i=0;i<16;i++){
    fenetre2.getContentPane().add(new JButton("bouton"+(i+1)));
    }
    fenetre2.setLocation(500, 300);
    fenetre2.pack();
    fenetre2.setLocationRelativeTo(null);
    fenetre2.setResizable(false);
    fenetre2.setVisible(true);
    */
    
	 /* JFrame fenetre3 = new JFrame("test");
	    fenetre3.getContentPane().setLayout(new GridLayout(4,4));
	    fenetre3.setPreferredSize(new Dimension(400,300));
	    for (int i=0;i<16;i++){
	    fenetre3.getContentPane().add(new JButton("bouton"+(i+1)));
	    }
	    fenetre3.setLocation(500, 300);
	    fenetre3.pack();
	    fenetre3.setLocationRelativeTo(null);
	    fenetre3.setResizable(false);
	    fenetre3.setVisible(true);
	    */
	    
	    JFrame fenetre4 = new JFrame("test");
	    fenetre4.getContentPane().setLayout(new BoxLayout(fenetre4.getContentPane(),BoxLayout.Y_AXIS));
	    fenetre4.setPreferredSize(new Dimension(400,300));
	    for (int i=0;i<3;i++){
	    fenetre4.add(new JButton("bouton"+(i+1)));
	    if(i==1) fenetre4.add(Box.createGlue());
	    }
	    fenetre4.setLocation(500, 300);
	    fenetre4.pack();
	    fenetre4.setLocationRelativeTo(null);
	    fenetre4.setResizable(false);
	    fenetre4.setVisible(true);
  }

  public static void main(String[] args) {
      //Schedule a job for the event-dispatching thread:
      //creating and showing this application’s GUI.
      javax.swing.SwingUtilities.invokeLater(new Runnable() {
        public void run() {
          new interfac();
        }
    });
  }
}