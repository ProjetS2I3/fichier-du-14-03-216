package ihm;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.Border;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class TestJList implements ListSelectionListener{
	protected JLabel label;
	protected JList list;
	protected JFrame f;
	protected String value;
	protected String source;
	Border c ;
	protected JList listesecondaire=new JList();

	TestJList() {
		f = new JFrame("File explorer");
		f.setPreferredSize(new Dimension(800,500));
		File path = new File("/usr/include/");
		File selection;
		String[] filelist = path.list();
		String[]selectionlist;
		list = new JList(filelist);
		list.addListSelectionListener(this);
		// nombre d’items visibles
		list.setVisibleRowCount(3);
		// mode de sélection: 1 seul élément
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); 			
		// Indispensable pour avoir la barre de défilement
		JScrollPane scroll= new JScrollPane(list);
		// Affichage d’une bordure pour des raisons esthétiques
		Border b = BorderFactory.createTitledBorder("Liste");
		scroll.setBorder(b);

		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(1,2));
		panel.add(scroll);
		label = new JLabel("Aucune selection");
		panel.add(label);

		f.getContentPane().add(panel);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.pack();
		f.setVisible(true);
	}

	public static void main(String args[]){
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new TestJList();
			}
		});
	}

	@Override
	public void valueChanged(ListSelectionEvent e) {
		File tmp = new File("/usr/include/"+list.getSelectedValue());
		String value=tmp.getPath();
		if(tmp.isDirectory()){
			value="Repertoire";
			String[]content=tmp.list();
			listesecondaire.setListData(content);
			f.add(listesecondaire,BorderLayout.EAST);
			source=tmp.getPath();
		}else{
			value="Fichier";
			f.remove(listesecondaire);
			source=tmp.getPath();
		}
		c =BorderFactory.createTitledBorder(source);
		listesecondaire.setCellRenderer(new MyCellRenderer());
		list.setCellRenderer(new MyCellRenderer());
		listesecondaire.setBorder(c);
		label.setText("Selection de   " + list.getSelectedValue()+"  Cet element est un : "+value);

	}
}