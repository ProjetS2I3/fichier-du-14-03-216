
package ihm;


import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.LayoutManager;
import java.awt.Point;
import java.awt.TextArea;
import java.awt.event.KeyEvent;

import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextArea;



public class editeur_de_texte {
	public editeur_de_texte() {
		JFrame fenetre = new JFrame();
		String[] items = {"Nouveau", "Ouvrir","Enregistrer","Enegistrer sous","Mise en page","imprimer","Quitter"};
		JComboBox menu = new JComboBox(items);
		menu.setSize(100, 20);
		fenetre.add(new JMenuBar().add(menu),BorderLayout.NORTH);
		fenetre.getContentPane().add(new TextArea(),BorderLayout.EAST);
		fenetre.setTitle("editeur de texte");
		fenetre.setPreferredSize(new Dimension(1400,700));
		fenetre.setResizable(false);
		fenetre.pack();
		fenetre.setVisible(true);
	}

	public static void main(String[] args) {
		//Schedule a job for the event-dispatching thread:

		//creating and showing this application’s GUI.
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new editeur_de_texte();
			}
		});
	}
}
