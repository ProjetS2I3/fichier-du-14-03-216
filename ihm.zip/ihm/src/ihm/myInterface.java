package ihm;


import java.awt.Container;
import java.awt.Dimension;
import java.awt.LayoutManager;
import java.awt.Point;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;



public class myInterface {
	public myInterface() {
		JFrame fenetre = new JFrame("Helloworld");
		fenetre.setPreferredSize(new Dimension(500,300));
			
		fenetre.getContentPane().add( new JLabel("helloworld"));
		fenetre.setResizable(false);
		JDialog dialog=new JDialog(fenetre);
		dialog.setSize(200, 200);
		dialog.setTitle("bakel city gangster");
		fenetre.setLocation(new Point(200, 500));
		dialog.setLocation(new Point(200,500));		
		fenetre.pack();
		fenetre.setVisible(true);
		dialog.setVisible(true);
	}

	public static void main(String[] args) {
		//Schedule a job for the event-dispatching thread:
		
		//creating and showing this application’s GUI.
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new myInterface();
			}
		});
	}
}
