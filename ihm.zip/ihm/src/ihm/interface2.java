

package ihm;


import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.Point;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;


public class interface2 { 
	public  interface2() {
		JFrame fenetre = new JFrame("figure3");
		JFrame fenetre2=new JFrame("figure2");
		JFrame fenetre3=new JFrame("figure1");
		fenetre3.getContentPane().setLayout(new FlowLayout(FlowLayout.CENTER));

		fenetre2.getContentPane().add(new JButton("nord"),BorderLayout.NORTH);
		fenetre2.getContentPane().add(new JButton("sud "),BorderLayout.SOUTH);
		fenetre2.getContentPane().add(new JButton("est"),BorderLayout.EAST);
		fenetre2.getContentPane().add(new JButton("ouest"),BorderLayout.WEST);
		fenetre2.getContentPane().add(new JButton("center"),BorderLayout.CENTER);
		fenetre2.setPreferredSize(new Dimension(500,300));
		fenetre.setPreferredSize(new Dimension(500,300));
		fenetre3.setPreferredSize(new Dimension(500,300));
		GridLayout experimentLayout = new GridLayout(0,4);
		        fenetre.setLayout(experimentLayout);
		        for (int i = 0; i < 4; i++) {
		        	for (int j = 0; j < 4; j++) {
		        		fenetre.add(new JButton("Button "));
					}
				}
		for (int i = 0; i < 16; i++) {
			fenetre3.add(new JButton("Button"+(i+1)));
			
		}
		fenetre.setResizable(false);
		fenetre2.setResizable(false);
		fenetre3.setResizable(false);
		fenetre.setLocation(new Point(300, 200));
		fenetre2.setLocation(new Point(100, 300));
		fenetre3.setLocation(new Point(400, 300));
		fenetre.pack();
		fenetre2.pack();
		fenetre3.pack();
		fenetre.setVisible(true);
		fenetre2.setVisible(true);
		fenetre3.setVisible(true);
	}

	public static void main(String[] args) {
		//Schedule a job for the event-dispatching thread:

		//creating and showing this application’s GUI.
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new interface2();
			}
		});
	}
}