package jalon1;

import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import javax.swing.JOptionPane;
public class Jeu {
	private static int taille=15,pourcentage=10,rocher=(int)((taille-2)*(taille-2)*((double)(pourcentage)/(double)(100)));
	private static boolean membreEquipe0[]=new boolean[]{true,true,true,true};
	private static boolean membreEquipe1[]=new boolean[]{true,true,true,true};
	private static Equipe []equipes=new Equipe [2];	
	private static boolean finished=false,findetour=false;
	private static InputEvent event;
	private static Plateau [] grille=new Plateau [4]; 
	private static Ile ile=new Ile(taille,rocher),navire=new Ile(6);
	private static boolean actionFaite []=new boolean [4];
	private static String[] elements={
			"images/mer.png", // 1
			"images/sable.png", // 2
			"images/rocher.png", // 3
			"images/1.navire.png", // 4
			"images/2.navire.png", // 5
			"images/1.explorateur.png", // 6
			"images/2.explorateur.png", // 7
			"images/1.voleur.png", // 8
			"images/2.voleur.png", // 9
			"images/1.piegeur.png", // 10
			"images/2.piegeur.png", // 11
			"images/1.guerrier.png", // 12
			"images/2.guerrier.png", // 13
			"images/coffreferme.png", // 14
			"images/coffreouvert.png", // 15
			"", // 16
			"", // 17
			"", // 18
			"", // 19
			"images/planche.png", // 20
			"images/tonneau.png","images/mat1.png", // 21
			"images/1.explorateur.navire.png", // 22
			"images/2.explorateur.navire.png", // 23
			"images/1.voleur.navire.png", // 24
			"images/2.voleur.navire.png", // 25
			"images/1.piegeur.navire.png", // 26
			"images/2.piegeur.navire.png", // 27
			"images/1.guerrier.navire.png", // 28
			"images/2.guerrier.navire.png" // 29
			};
	private static int x=0,y=0,equipe=0;
public static void main(String[] args) {
	// Ici choix du mode de jeu (mode test, mode jeu ...)
	System.out.println(ile);
	grille[0]=new Plateau(elements,taille,true,"Plateau de jeu");
	grille[1]=new Plateau(elements,taille,true,"Plateau de jeu");
	grille[2]=new Plateau(elements,6,true,"Navire");
	grille[3]=new Plateau(elements,6,true,"Navire");
	equipes[0]=new Equipe(membreEquipe0,0);
	equipes[1]=new Equipe(membreEquipe1,1);
	while(!finished){		
		findetour=false;
		resetTour();
		while (!findetour){
			resetTour(); // mode Test
			affichage();
			if (equipe==0){
				tourEquipe0();
				changementDeTour();
			}else{
				tourEquipe1();
				changementDeTour();
			}
		}
	}
}
public static void resetTour(){
	((Explorateur)equipes[equipe].getExplorateur()).setTourjoue(false);
	((Voleur)equipes[equipe].getVoleur()).setTourjoue(false);
	((Piegeur)equipes[equipe].getPiegeur()).setTourjoue(false);
	((Guerrier)equipes[equipe].getGuerrier()).setTourjoue(false);
}
public static void affichage(){
	grille[1-equipe].masquer();
	grille[2].close();
	grille[3].close();
	grille[equipe].setJeu(ile.getJeu(equipe));
	grille[equipe].affichage();
}
public static void tourEquipe0(){
	grille[0].clearHighlight();
	setTourJouer();
	cliqueSouris();
	grille[equipe].println("x : "+x+" y : "+y+" equipe "+equipe+" entier "+ile.getInt(x,y));
	tourNavire();
	tourExplorateur();
	tourVoleur();
	tourPiegeur();
	tourGuerrier();
}
public static void tourEquipe1(){
	grille[1].clearHighlight();
	setTourJouer();
	cliqueSouris();
	grille[equipe].println("x : "+x+" y : "+y+" equipe "+equipe+" entier "+ile.getInt(x,y));
	tourNavire();
	tourExplorateur();
	tourVoleur();
	tourPiegeur();
	tourGuerrier();
}
public static void tourNavire(){
	if (equipe==0){
		if(ile.getInt(x, y)==4){ //Selection du navire
			navire.setNavire(((Explorateur)equipes[equipe].getExplorateur()),((Voleur)equipes[equipe].getVoleur()),((Piegeur)equipes[equipe].getPiegeur()),((Guerrier)equipes[equipe].getGuerrier()));
			grille[equipe+2].setJeu(navire.getJeu(equipe));
			grille[equipe+2].affichage();
			int keyCode=0;
			int xbis=0,ybis=0;
			boolean sortir=false;
			do {
				grille[equipe+2].affichage();
				event=grille[equipe+2].waitEvent();
				if (event instanceof MouseEvent) {
					xbis = grille[equipe+2].getX((MouseEvent) event) ;
					ybis = grille[equipe+2].getY((MouseEvent) event) ;
					grille[equipe+2].println("ligne " + xbis + " colonne : " + ybis ) ;
					sortir=true;
				}else if(event instanceof KeyEvent) {
					keyCode = ((KeyEvent) event).getKeyCode() ;
					grille[equipe+2].println(""+keyCode ) ;
					if (keyCode==27){
						sortir=true;
				}
			}
			}while (!sortir);
			if(navire.getParcelle(ybis,xbis) instanceof Explorateur){
				if(ile.getInt(x+1,y)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x+1,y);
					((Explorateur)equipes[equipe].getExplorateur()).setSurnavire(false); // pas certain que ça fonctionne
				}else if (ile.getInt(x,y+1)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y+1);
					((Explorateur)equipes[equipe].getExplorateur()).setSurnavire(false);
				}
			}else if(navire.getParcelle(ybis,xbis) instanceof Voleur){
				if(ile.getInt(x+1,y)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x+1,y);
					((Voleur)equipes[equipe].getVoleur()).setSurnavire(false);
				}else if (ile.getInt(x,y+1)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y+1);
					((Voleur)equipes[equipe].getVoleur()).setSurnavire(false);
				}
			}else if(navire.getParcelle(ybis,xbis) instanceof Piegeur){
				if(ile.getInt(x+1,y)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x+1,y);
					((Piegeur)equipes[equipe].getPiegeur()).setSurnavire(false);
				}else if (ile.getInt(x,y+1)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y+1);
					((Piegeur)equipes[equipe].getPiegeur()).setSurnavire(false);
				}
			}else if(navire.getParcelle(ybis,xbis) instanceof Guerrier){
				if(ile.getInt(x+1,y)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x+1,y);
					((Guerrier)equipes[equipe].getGuerrier()).setSurnavire(false);
				}else if (ile.getInt(x,y+1)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y+1);
					((Guerrier)equipes[equipe].getGuerrier()).setSurnavire(false);
				}
			}
		}
	}else{
		if(ile.getInt(x, y)==5){ //Selection du navire
			navire.setNavire(((Explorateur)equipes[equipe].getExplorateur()),((Voleur)equipes[equipe].getVoleur()),((Piegeur)equipes[equipe].getPiegeur()),((Guerrier)equipes[equipe].getGuerrier()));
			grille[equipe+2].setJeu(navire.getJeu(equipe));
			grille[equipe+2].affichage();	
			int KeyCode=0;
			int xbis=0,ybis=0;
			boolean sortir=false;
			do {
				event=grille[equipe+2].waitEvent();
				if (event instanceof MouseEvent) {
					xbis = grille[equipe+2].getX((MouseEvent) event) ;
		        	ybis = grille[equipe+2].getY((MouseEvent) event) ;
		        	grille[equipe+2].println("ligne " + x + " colonne : " + y ) ;
		        	sortir=true;
		        } else if (event instanceof KeyEvent) {
		        	grille[equipe].println(event.toString()) ;
		        	KeyCode = ((KeyEvent) event).getKeyCode() ;
		        	if (KeyCode==27)
		        		sortir=true;
		        }
			}while (!sortir);
			if(navire.getParcelle(ybis,xbis) instanceof Explorateur){
				if(ile.getInt(x-1,y)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x-1,y);
					((Explorateur)equipes[equipe].getExplorateur()).setSurnavire(false);
				}else if (ile.getInt(x,y-1)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y-1);
					((Explorateur)equipes[equipe].getExplorateur()).setSurnavire(false);
				}
			}else if(navire.getParcelle(ybis,xbis) instanceof Voleur){
				if(ile.getInt(x-1,y)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x-1,y);
					((Voleur)equipes[equipe].getVoleur()).setSurnavire(false);
				}else if (ile.getInt(x,y-1)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y-1);
					((Voleur)equipes[equipe].getVoleur()).setSurnavire(false);
				}
			}else if(navire.getParcelle(ybis,xbis) instanceof Piegeur){
				if(ile.getInt(x-1,y)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x-1,y);
					((Piegeur)equipes[equipe].getPiegeur()).setSurnavire(false);
				}else if (ile.getInt(x,y-1)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y-1);
					((Piegeur)equipes[equipe].getPiegeur()).setSurnavire(false);
				}
			}else if(navire.getParcelle(ybis,xbis) instanceof Guerrier){
				if(ile.getInt(x-1,y)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x-1,y);
					((Guerrier)equipes[equipe].getGuerrier()).setSurnavire(false);
				}else if (ile.getInt(x,y-1)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y-1);
					((Guerrier)equipes[equipe].getGuerrier()).setSurnavire(false);
				}
			}
		}
	}
}
public static void tourExplorateur(){
	if(ile.getInt(x,y)==6+equipe && !actionFaite[0]){   	//Selection de l explorateur
		grille[equipe].setHighlight(y, x);
		int xbis=x,ybis=y;
		grille[equipe].println("c est un explorateur");
		do{ event = grille[equipe].waitEvent();
		if(event instanceof MouseEvent){
			y = grille[equipe].getX((MouseEvent) event);
			x = grille[equipe].getY((MouseEvent) event);
		}
		}while (!(event instanceof MouseEvent));
			grille[equipe].println("x : "+x+" y : "+y+" bis");
			if (ile.Deplacer(new Explorateur(6+equipe),x,y))
				((Explorateur)equipes[equipe].getExplorateur()).setTourjoue(true);
		if(ile.GetBack()&& ile.getParcelle(x, y).getInt()==4+equipe){
			((Explorateur)equipes[equipe].getExplorateur()).setSurnavire(true);
			navire.PlacerCase(ile.getParcelle(xbis, ybis),1,4);
			ile.PlacerCase(new Parcelle(2), xbis, ybis);
			ile.setGetBack(false);
		}
	}
}
public static void tourVoleur(){
	if(ile.getInt(x,y)==8+equipe &&!actionFaite[1]){
		grille[equipe].setHighlight(y, x);
		int xbis=x,ybis=y;
		grille[equipe].println("c est un voleur"); // Selection du voleur
		do{ 
			event = grille[equipe].waitEvent();
			if(event instanceof MouseEvent){
			y = grille[equipe].getX((MouseEvent) event);
			x = grille[equipe].getY((MouseEvent) event);
			}
		}while (!(event instanceof MouseEvent));
		grille[equipe].println("x : "+x+" y : "+y+" bis");
		if (ile.Deplacer(new Voleur(8+equipe),x,y))
			((Voleur)equipes[equipe].getVoleur()).setTourjoue(true);
		if(ile.GetBack() && ile.getParcelle(x, y).getInt()==4+equipe){
			((Voleur)equipes[equipe].getVoleur()).setSurnavire(true);
			navire.PlacerCase(ile.getParcelle(xbis, ybis),2,4);
			ile.PlacerCase(new Parcelle(2), xbis, ybis);
			ile.setGetBack(false);
		}
	}
}
public static void tourPiegeur(){
	if(ile.getInt(x, y)==10+equipe &&!actionFaite[2]){
		grille[equipe].setHighlight(y, x);
		int xbis=x,ybis=y;
		grille[equipe].println("c est un piegeur"); // Selection du piegeur
		do{ 
			event = grille[equipe].waitEvent();
			if(event instanceof MouseEvent){
				y = grille[equipe].getX((MouseEvent) event);
				x = grille[equipe].getY((MouseEvent) event);
			}
		}while (!(event instanceof MouseEvent));
			grille[equipe].println("x : "+x+" y : "+y+" bis");
			if (ile.Deplacer(new Piegeur(10+equipe),x,y))
				((Piegeur)equipes[equipe].getPiegeur()).setTourjoue(true);
		if(ile.GetBack()&& ile.getParcelle(x, y).getInt()==4+equipe){
			((Piegeur)equipes[equipe].getPiegeur()).setSurnavire(true);
			navire.PlacerCase(ile.getParcelle(xbis, ybis),3,4);
			ile.PlacerCase(new Parcelle(2), xbis, ybis);
			ile.setGetBack(false);
		}
		}
}
public static void tourGuerrier(){
	if(ile.getInt(x,y)==12+equipe &&!actionFaite[3]){
		grille[equipe].setHighlight(y, x);
		int xbis=x,ybis=y;
		grille[equipe].println("c est un guerrier"); // Selection du guerrier
		do{ event = grille[equipe].waitEvent();
		if(event instanceof MouseEvent){
			y = grille[equipe].getX((MouseEvent) event);
			x = grille[equipe].getY((MouseEvent) event);
		}
		}while (!(event instanceof MouseEvent));
			grille[equipe].println("x : "+x+" y : "+y+" bis");
			if (ile.Deplacer(new Guerrier(12+equipe),x,y))
				((Guerrier)equipes[equipe].getGuerrier()).setTourjoue(true);
			if(ile.GetBack()&& ile.getParcelle(x, y).getInt()==4+equipe){
				((Guerrier)equipes[equipe].getGuerrier()).setSurnavire(true);
				navire.PlacerCase(ile.getParcelle(xbis, ybis),4,4);
				ile.PlacerCase(new Parcelle(2), xbis, ybis);
				ile.setGetBack(false);
			}
		}
}
public static void cliqueSouris(){
	do{
		event = grille[equipe].waitEvent();
	if(event instanceof MouseEvent){
		y = grille[equipe].getX((MouseEvent) event);
		x = grille[equipe].getY((MouseEvent) event);
	}
	if (event instanceof KeyEvent && ((KeyEvent) event).getKeyCode()==27){
		findetour=true;
		equipe=1-equipe;
	}
	}while (!(event instanceof MouseEvent) || (event instanceof KeyEvent && ((KeyEvent) event).getKeyCode()==27));
}
public static void setTourJouer(){
		actionFaite[0]=((Explorateur)equipes[equipe].getExplorateur()).getTourjoue();
		actionFaite[1]=((Voleur)equipes[equipe].getVoleur()).getTourjoue();
		actionFaite[2]=((Piegeur)equipes[equipe].getPiegeur()).getTourjoue();
		actionFaite[3]=((Guerrier)equipes[equipe].getGuerrier()).getTourjoue();
}
public static void changementDeTour(){
	if (actionFaite[0] && actionFaite[1] && actionFaite[2] && actionFaite[3]){
		findetour=true;
		//equipe=1-equipe;
	}
}
}
