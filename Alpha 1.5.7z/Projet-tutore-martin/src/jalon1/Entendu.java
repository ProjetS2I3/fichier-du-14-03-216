package jalon1;

import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.Dimension;
import java.awt.Color;

public class Entendu extends JPanel implements MouseListener { 
 public Entendu() {
	setPreferredSize(new Dimension(200, 200));
	addMouseListener(this);
setBackground(Color.RED);
}
public void mouseEntered(MouseEvent e) {
	setBackground(Color.GREEN);
 }
 
 public void mouseExited(MouseEvent e) {
	setBackground(Color.RED);
 }
 
 public void mousePressed(MouseEvent e) {}
 
 public void mouseReleased(MouseEvent e) {}
 
 public void mouseClicked(MouseEvent e) {
	
 }
} 
 
class EssaiEntendu {
 public static void main(String[] arg) {
	JFrame fenetre = new JFrame();
	fenetre.setContentPane(new Entendu());

	fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	fenetre.pack();
	fenetre.setLocation(300, 300);
	fenetre.setVisible(true);
 } 
}
