package jalon1;

import javax.swing.JButton;
import javax.swing.JOptionPane;

public class TEST_menu {

	static 	int taille=Integer.parseInt(JOptionPane.showInputDialog("Entre la taille de l'ile"));

	static 	boolean finished=false;

	static 	Plateau [] grille=new Plateau [2];

	static int pourcentage=10;

	static int rocher=(int)((taille-1)*(taille-1)*((double)(pourcentage)/(double)(100)));

	static Ile ile=new Ile();

	static String choix;

	static int abscisse,ordonnee;

	static int joueur;


	/**FONCTION DU MAIN **/
	public static void main(String[] args) {

		//ile.PlacerExplorateurs();
		init();
		while(!finished){
			grille[0].setJeu(ile.getJeu(0));
			grille[0].affichage();
			ATester();
			test();
		}

	}
	public static void init(){
		String[] elements={"images/mer.png","images/herbe.png","images/1.navire.png",
				"images/rocher.png","images/2.navire.png","images/1.explorateur.png",
				"images/2.explorateur.png","images/1.piegeur.png","images/2.piegeur.png",
				"images/arbre","images/coffre.png",};

		System.out.println(ile);


		grille[0]=new Plateau(elements,taille,true,"Plateau de jeu");
		grille[0].setJeu(ile.getJeu(0));
		grille[0].setJeu(ile.getJeu(0));
		grille[0].affichage();
	}
	public static  void ATester(){
		String[]elements=new String[]{"Explorateur","Voleurs","rocher","bateauJ1","bateauJ2","a definir"};
		choix = (String)JOptionPane.showInputDialog(null,"Choississez un placement",
				"Direction",JOptionPane.QUESTION_MESSAGE, null, elements,elements[0]);
	}
	public static void test(){
		ConsolePane pane=new ConsolePane();
		switch (choix) {
		case "Explorateur":
			joueur=Integer.parseInt(JOptionPane.showInputDialog("1 pour J1 /2 pour J2"));
			abscisse=Integer.parseInt(JOptionPane.showInputDialog("abscisse"));
			ordonnee=Integer.parseInt(JOptionPane.showInputDialog("ordonnee"));
			if(joueur == 1){
				ile.PlacerCase(new Parcelle(6), abscisse, ordonnee);
				pane.println("Vous venez de placer l'exporateur de J1 ");
			}else if(joueur == 2){
				ile.PlacerCase(new Parcelle(7), abscisse, ordonnee);
				pane.println("Vous venez de placer l'exporateur de J2 ");

			}			break;
		case "Voleurs":
			joueur=Integer.parseInt(JOptionPane.showInputDialog("1 pour J1 /2 pour J2"));
			abscisse=Integer.parseInt(JOptionPane.showInputDialog("abscisse"));
			ordonnee=Integer.parseInt(JOptionPane.showInputDialog("ordonnee"));
			if(joueur == 1){
				ile.PlacerCase(new Parcelle(8), abscisse, ordonnee);
				pane.println("Vous venez de placer le voleur  de J1 ");
			}else if(joueur == 2){
				ile.PlacerCase(new Parcelle(9), abscisse, ordonnee);
				pane.println("Vous venez de placer le voleur de J2 ");
			}break;
		case "rocher":
			abscisse=Integer.parseInt(JOptionPane.showInputDialog("abscisse"));
			ordonnee=Integer.parseInt(JOptionPane.showInputDialog("ordonnee"));
			ile.PlacerCase(new Parcelle(4), abscisse, ordonnee);
			break;
		case "bateauJ1":
			abscisse=Integer.parseInt(JOptionPane.showInputDialog("abscisse"));
			ordonnee=Integer.parseInt(JOptionPane.showInputDialog("ordonnee"));
			if( !Exeptions() ){
			ile.PlacerCase(new Parcelle(3), abscisse, ordonnee);
			}else{
				pane.println("Erreur de placement  bateau de J1 \n -> cette case est deja occup�e \n voulez vous forcer le placement ?" );
			}
			break;
		case "bateauJ2":
			abscisse=Integer.parseInt(JOptionPane.showInputDialog("abscisse"));
			ordonnee=Integer.parseInt(JOptionPane.showInputDialog("ordonnee"));
			if( !Exeptions() ){
				ile.PlacerCase(new Parcelle(5), abscisse, ordonnee);
				pane.println("Vous venez de placer le bateau de J2 ");
			}else{
				pane.println("Erreur de placement  bateau de J2 \n -> cette case est deja occup�e \n voulez vous forcer le placement ? ");
			}

			break;
		case "a definir":
			JOptionPane.showConfirmDialog(null,"Cette section est a definir");
			break;
		default:
			break;
		}
	}
	public static boolean Exeptions(){
		int[][]tmp=ile.getJeu(0);
		if(tmp[abscisse][ordonnee] != 1 || tmp[abscisse][ordonnee] != 2 ){
			return true;
		}
		return false;
	}
}
