package jalon1;

public class Explorateur extends Parcelle{
	private int energy;
	private boolean coffreFound,tresorFound,clef,tresor,tourjoue,surnavire;
	public Explorateur(int n) {
		super(n);
	}
	public boolean getTresorFound() {
		return tresorFound;
	}
	public void setTresorFound(boolean tresorFound) {
		this.tresorFound = tresorFound;
	}
	public boolean getTourjoue() {
		return tourjoue;
	}
	public void setTourjoue(boolean tourjoue) {
		this.tourjoue = tourjoue;
	}
	public boolean getCoffreFound() {
		return coffreFound;
	}
	public void setCoffreFound(boolean coffreFound) {
		this.coffreFound = coffreFound;
	}
	public int getEnergy() {
		return energy;
	}
	public void setEnergy(int energy) {
		this.energy = energy;
	}
	public boolean getTresor(){
		return tresor;
	}
	public boolean getClef(){
		return clef;
	}
	public void setClef(boolean clef){
		this.clef=clef;
	}
	public void setTresor(boolean tresor){
		this.tresor=tresor;
	}
	public boolean getSurnavire() {
		return surnavire;
	}
	public void setSurnavire(boolean surnavire) {
		this.surnavire = surnavire;
	}
}
