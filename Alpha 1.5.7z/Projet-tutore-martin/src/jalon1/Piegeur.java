package jalon1;

public class Piegeur extends Parcelle{
	private int energy;
	private boolean tourjoue,surnavire;
	public Piegeur(int n) {
		super(n);
	}
	public int getEnergy() {
		return energy;
	}
	public void setEnergy(int energy) {
		this.energy = energy;
	}
	public boolean getTourjoue() {
		return tourjoue;
	}
	public void setTourjoue(boolean tourjoue) {
		this.tourjoue = tourjoue;
	}
	public boolean getSurnavire() {
		return surnavire;
	}
	public void setSurnavire(boolean surnavire) {
		this.surnavire = surnavire;
	}
}
