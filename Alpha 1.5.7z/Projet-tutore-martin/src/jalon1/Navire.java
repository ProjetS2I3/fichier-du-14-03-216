package jalon1;

public class Navire extends Parcelle{
	private boolean Explorateur,Voleur,Piegeur,Guerrier;
	/** Constructeur herite de Parcelle, cree une Parcelle de valeur n=3 qui correspond au navire, prend en parametres l entier n ainsi que le booleen camp qui determinenera a quel joueur appartient le navire.  **/
	public Navire(int n) {
		super(n);
	}
	public boolean getExplorateur() {
		return Explorateur;
	}
	public void setExplorateur(boolean explorateur) {
		Explorateur = explorateur;
	}
	public boolean getVoleur() {
		return Voleur;
	}
	public void setVoleur(boolean voleur) {
		Voleur = voleur;
	}
	public boolean getPiegeur() {
		return Piegeur;
	}
	public void setPiegeur(boolean piegeur) {
		Piegeur = piegeur;
	}
	public boolean getGuerrier() {
		return Guerrier;
	}
	public void setGuerrier(boolean guerrier) {
		Guerrier = guerrier;
	}
}
