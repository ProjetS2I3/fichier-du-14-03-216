package jalon1;

public class Voleur extends Parcelle{
	private int energy;
	private boolean clef,coffre;
	public boolean isClef() {
		return clef;
	}
	public void setClef(boolean clef) {
		this.clef = clef;
	}
	public boolean isCoffre() {
		return coffre;
	}
	public void setCoffre(boolean coffre) {
		this.coffre = coffre;
	}
	public Voleur(int n) {
		super(n);
	}
	public int getEnergy() {
		return energy;
	}
	public void setEnergy(int energy) {
		this.energy = energy;
	}
}
