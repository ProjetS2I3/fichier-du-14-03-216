package jalon1;

import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import javax.swing.JOptionPane;
public class Jeu {

	public static void main(String[] args) {
		int taille=15;
		int pourcentage=10;
		int rocher=(int)((taille-1)*(taille-1)*((double)(pourcentage)/(double)(100)));
		boolean finished=false;
		boolean []membreEquipe=new boolean[]{true,true,true,false,true,true,true,false};
		int equipe=1;
		InputEvent event;
		String[] elements={"images/mer.png","images/sable.png","images/1.navire.png",
				"images/rocher.png","images/2.navire.png","images/1.explorateur.png",
				"images/2.explorateur.png","images/1.voleur.png","images/2.voleur.png",
				"images/1.piegeur.png","images/2.piegeur.png"};
		// Ici choix du mode de jeu (mode test, mode jeu ...)
		Ile ile=new Ile(taille,rocher);
		Ile navire=new Ile(2);
		System.out.println(ile);
		Plateau [] grille=new Plateau [4]; 
		grille[0]=new Plateau(elements,taille,true,"Plateau de jeu");
		grille[1]=new Plateau(elements,taille,true,"Plateau de jeu");
		grille[2]=new Plateau(elements,2,true,"Navire");
		grille[3]=new Plateau(elements,2,true,"Navire");
		//ile.PlacerExplorateurs();
		while(!finished){
			grille[1-equipe].masquer();
			grille[2].close();
			grille[3].close();
			grille[equipe].setJeu(ile.getJeu());
			grille[equipe].affichage();
			int x=0,y=0;
			do{
				event = grille[equipe].waitEvent();
				if(event instanceof MouseEvent){
					y = grille[equipe].getX((MouseEvent) event);
					x = grille[equipe].getY((MouseEvent) event);
				}
			}while (!(event instanceof MouseEvent));
			grille[equipe].println("x : "+x+" y : "+y+" equipe "+equipe+" entier "+ile.getInt(x,y));
			if (equipe==0){
					if(ile.getInt(x, y)==3){ //Selection du navire
						navire.setNavire(membreEquipe[0],membreEquipe[1],membreEquipe[2],membreEquipe[3],equipe);
						grille[equipe+2].setJeu(navire.getJeu());
						grille[equipe+2].affichage();
						int KeyCode=0;
						int xbis=0,ybis=0;
						do {
							event=grille[equipe+2].waitEvent();
							if (event instanceof MouseEvent) {
					        	xbis = grille[equipe+2].getX((MouseEvent) event) ;
					        	ybis = grille[equipe+2].getY((MouseEvent) event) ;
					        	grille[equipe+2].println("ligne " + x + " colonne : " + y ) ;
					        } else if (event instanceof KeyEvent) {
					        	grille[equipe].println(event.toString()) ;
					        	KeyCode = ((KeyEvent) event).getKeyCode() ;
					        }
						}while (!(event instanceof MouseEvent) || event instanceof KeyEvent && KeyCode == 27);
						if(navire.getParcelle(ybis,xbis) instanceof Explorateur){
							if(ile.getInt(x+1,y)==2){
								ile.PlacerCase(navire.getParcelle(ybis,xbis),x+1,y);
								membreEquipe[0]=false;
								grille[0].println("wdfqg");
							}else if (ile.getInt(x,y+1)==2){
								ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y+1);
								membreEquipe[0]=false;
							}
						}else if(navire.getParcelle(ybis,xbis) instanceof Voleur){
							if(ile.getInt(x+1,y)==2){
								ile.PlacerCase(navire.getParcelle(ybis,xbis),x+1,y);
								membreEquipe[1]=false;
							}else if (ile.getInt(x,y+1)==2){
								ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y+1);
								membreEquipe[1]=false;
							}
						}else if(navire.getParcelle(ybis,xbis) instanceof Piegeur){
							if(ile.getInt(x+1,y)==2){
								ile.PlacerCase(navire.getParcelle(ybis,xbis),x+1,y);
								membreEquipe[2]=false;
							}else if (ile.getInt(x,y+1)==2){
								ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y+1);
								membreEquipe[2]=false;
							}
						}else if(navire.getParcelle(ybis,xbis) instanceof Guerrier){
							if(ile.getInt(x+1,y)==2){
								ile.PlacerCase(navire.getParcelle(ybis,xbis),x+1,y);
								membreEquipe[3]=false;
							}else if (ile.getInt(x,y+1)==2){
								ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y+1);
								membreEquipe[3]=false;
							}
						}
					}
					if(ile.getInt(x,y)==6){  //Selection de l explorateur
						grille[0].println("c est un explorateur");
						do{ event = grille[equipe].waitEvent();
							if(event instanceof MouseEvent){
								y = grille[equipe].getX((MouseEvent) event);
								x = grille[equipe].getY((MouseEvent) event);
							}
						}while (!(event instanceof MouseEvent));
						grille[equipe].println("x : "+x+" y : "+y+" bis");
						ile.Deplacer(new Explorateur(6),x,y);
						
					}
					if(ile.getInt(x,y)==8){
						grille[0].println("c est un voleur"); // Selection du voleur
						do{ event = grille[equipe].waitEvent();
							if(event instanceof MouseEvent){
								y = grille[equipe].getX((MouseEvent) event);
								x = grille[equipe].getY((MouseEvent) event);
							}
						}while (!(event instanceof MouseEvent));
						grille[equipe].println("x : "+x+" y : "+y+" bis");
						ile.Deplacer(new Voleur(8),x,y);
					}
					if(ile.getInt(x, y)==10){
						grille[0].println("c est un piegeur"); // Selection du piegeur
						do{ event = grille[equipe].waitEvent();
						if(event instanceof MouseEvent){
							y = grille[equipe].getX((MouseEvent) event);
							x = grille[equipe].getY((MouseEvent) event);
						}
					}while (!(event instanceof MouseEvent));
						grille[equipe].println("x : "+x+" y : "+y+" bis");
						ile.Deplacer(new Piegeur(10),x,y);
					}
					if(ile.getParcelle(x,y) instanceof Guerrier){
	
					}
			}else{
					if(ile.getInt(x, y)==5){ //Selection du navire
						navire.setNavire(membreEquipe[4],membreEquipe[5],membreEquipe[6],membreEquipe[7],equipe);
						grille[equipe+2].setJeu(navire.getJeu());
						grille[equipe+2].affichage();	
						int KeyCode=0;
						int xbis=0,ybis=0;
						do {
							event=grille[equipe+2].waitEvent();
							if (event instanceof MouseEvent) {
								xbis = grille[equipe+2].getX((MouseEvent) event) ;
					        	ybis = grille[equipe+2].getY((MouseEvent) event) ;
					        	grille[equipe+2].println("ligne " + x + " colonne : " + y ) ;
					        } else if (event instanceof KeyEvent) {
					        	grille[equipe].println(event.toString()) ;
					        	KeyCode = ((KeyEvent) event).getKeyCode() ;
					        }
						}while (!(event instanceof MouseEvent) || event instanceof KeyEvent && KeyCode == 27);
						if(navire.getParcelle(ybis,xbis) instanceof Explorateur){
							if(ile.getInt(x-1,y)==2){
								ile.PlacerCase(navire.getParcelle(ybis,xbis),x-1,y);
								membreEquipe[4]=false;
							}else if (ile.getInt(x,y-1)==2){
								ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y-1);
								membreEquipe[4]=false;
							}
						}else if(navire.getParcelle(ybis,xbis) instanceof Voleur){
							if(ile.getInt(x-1,y)==2){
								ile.PlacerCase(navire.getParcelle(ybis,xbis),x-1,y);
								membreEquipe[5]=false;
							}else if (ile.getInt(x,y-1)==2){
								ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y-1);
								membreEquipe[5]=false;
							}
						}else if(navire.getParcelle(ybis,xbis) instanceof Piegeur){
							if(ile.getInt(x-1,y)==2){
								ile.PlacerCase(navire.getParcelle(ybis,xbis),x-1,y);
								membreEquipe[6]=false;
							}else if (ile.getInt(x,y-1)==2){
								ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y-1);
								membreEquipe[6]=false;
							}
						}else if(navire.getParcelle(ybis,xbis) instanceof Guerrier){
							if(ile.getInt(x-1,y)==2){
								ile.PlacerCase(navire.getParcelle(ybis,xbis),x-1,y);
								membreEquipe[7]=false;
							}else if (ile.getInt(x,y-1)==2){
								ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y-1);
								membreEquipe[7]=false;
							}
						}
					}
					if(ile.getInt(x,y)==7){ //Selection de l explorateur
						grille[0].println("c est un explorateur");
						do{ event = grille[equipe].waitEvent();
							if(event instanceof MouseEvent){
								y = grille[equipe].getX((MouseEvent) event);
								x = grille[equipe].getY((MouseEvent) event);
							}
						}while (!(event instanceof MouseEvent));
						grille[equipe].println("x : "+x+" y : "+y+" bis");
						ile.Deplacer(new Explorateur(7),x,y);
					}if(ile.getInt(x,y)==9){ //Selection du voleur
						grille[0].println("c est un voleur");
						do{ event = grille[equipe].waitEvent();
							if(event instanceof MouseEvent){
								y = grille[equipe].getX((MouseEvent) event);
								x = grille[equipe].getY((MouseEvent) event);
							}
						}while (!(event instanceof MouseEvent));
						grille[equipe].println("x : "+x+" y : "+y+" bis");
						ile.Deplacer(new Voleur(9),x,y);
					}
					if(ile.getInt(x, y)==11){
						grille[0].println("c est un piegeur"); // Selection du piegeur
						do{ event = grille[equipe].waitEvent();
						if(event instanceof MouseEvent){
							y = grille[equipe].getX((MouseEvent) event);
							x = grille[equipe].getY((MouseEvent) event);
						}
					}while (!(event instanceof MouseEvent));
						grille[equipe].println("x : "+x+" y : "+y+" bis");
						ile.Deplacer(new Piegeur(11),x,y);
					}
					if(ile.getParcelle(x,y) instanceof Guerrier){
	
					}
			}
			equipe=1-equipe;
		}
	}
	/** Renvoie un chaine de charactere correspondant au choix de l utilisateur(quel personnage deplacer) via un JOptionPane. **/
	public static String ChoixPersonnage(){
		String[] personnage = new String[]{"Explorateur","Voleur"};
		String choix = null;
		choix = (String)JOptionPane.showInputDialog(null,"Choississez le personnage que vous aller déplacer","Personnage",JOptionPane.QUESTION_MESSAGE, null, personnage, personnage[0]);
		return choix;
	}
}
/* 1=mer
 * 2=herbe
 * 3=Navire 1
 * 4=Rocher
 * 5=Navires 2
 * 6=explorateur 1
 * 7=explorateur 2
 * 8=voleur 1
 * 9=voleur 2*/