package jalon1;

public class Guerrier extends Parcelle{
	private int energy;
	public int getEnergy() {
		return energy;
	}
	public void setEnergy(int energy) {
		this.energy = energy;
	}
	public Guerrier(int n) {
		super(n);
	}
}
