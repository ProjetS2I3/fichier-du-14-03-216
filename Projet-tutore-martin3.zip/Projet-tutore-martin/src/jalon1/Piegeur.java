package jalon1;

public class Piegeur extends Parcelle{
	private int energy;
	public Piegeur(int n) {
		super(n);
	}
	public int getEnergy() {
		return energy;
	}
	public void setEnergy(int energy) {
		this.energy = energy;
	}
}
