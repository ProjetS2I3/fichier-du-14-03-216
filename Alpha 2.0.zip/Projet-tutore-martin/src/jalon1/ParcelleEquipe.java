package jalon1;

public interface ParcelleEquipe {
	
}
