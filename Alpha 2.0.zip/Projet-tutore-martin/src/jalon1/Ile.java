package jalon1;

import java.util.Random;
import javax.swing.JOptionPane;

public class Ile {
	private Parcelle [][]ile;
	private boolean [] brouillard [][]=new boolean [2] [][] ;
	private int rocher=0;
	private Random r=new Random();
	private boolean getBack=false;
	/** Constructeur par defaut sans parametres, cree un tableau 10x10 de Parcelles et initialise ce tableau via la methode init(). 
	 * @param null
	 * @return cree une nouvelle ile par defaut ; de dimesions 10*10
	 * **/
	public Ile(){
		for (int x=0 ; x<brouillard.length ; x++){
			for (int y=0 ; y<brouillard.length ; y++){
				brouillard[0][x][y]=false;
				brouillard[1][x][y]=false;
			}
		}
		ile=new Parcelle[10][10];
		for (int i = 0; i < ile.length; i++) {
			for (int j = 0; j < ile.length; j++) {
				if(i == 0 || i== 9 || j == 0 || j == 9)
					this.ile[i][j]=new Parcelle(1);
				else
					this.ile[i][j]=new Parcelle(2);
				
			}
		}
	}
	/** Constructeur avec en parametre la taille de l ile uniquement
	* @param taille
	* **/
	public Ile(int taille){
		brouillard=new boolean [2][taille][taille];
		if (brouillard[0].length == 6 || brouillard[1].length == 6){
			for (int x=0 ; x<brouillard[0].length ; x++){
				for (int y=0 ; y<brouillard[0].length ; y++){
					brouillard[0][x][y]=true;
					brouillard[1][x][y]=true;
				}
			}
		}else{
			for (int x=0 ; x<brouillard[0].length ; x++){
				for (int y=0 ; y<brouillard[0].length ; y++){
					brouillard[0][x][y]=false;
					brouillard[1][x][y]=false;
				}
			}
		}
		ile=new Parcelle[taille][taille];
	}
	/** Constructeur avec en parametre la taille de l'ile ainsi que le nombre de rocher sur l ile, et initialise ce tableau via la methode init().
	 * @param taille
	 * @param nbrocher
	 * @return cree une ile avec les attributs nbrocher et taille chosis
	 * **/
	public Ile(int taille,int nbrocher){
		brouillard[0]=new boolean [taille][taille];
		brouillard[1]=new boolean [taille][taille];
		for (int x=0 ; x<brouillard[0].length ; x++){
			for (int y=0 ; y<brouillard[0].length ; y++){
				brouillard[0][x][y]=false;
				brouillard[1][x][y]=false;
			}
		}
		ile=new Parcelle[taille][taille];
		init(nbrocher);
	}
	/** Initialise les elements de l ile (mer ,navires ,rochers ,clef ,coffre). 
	 * @param nbrochers
	 * **/
	public void initBrouillard(int equipe){
		if (brouillard[equipe].length == 6){
			for (int x=0 ; x<brouillard.length ; x++){
				for (int y=0 ; y<brouillard.length ; y++){
					brouillard[equipe][x][y]=true;
				}
			}
		}else{
			for (int x=0 ; x<brouillard[equipe].length ; x++){
				for (int y=0 ; y<brouillard[equipe].length ; y++){
					if (ile[x][y] instanceof Navire && ((Navire)ile[x][y]).getEquipe()==equipe){
						retirerBrouillard(equipe,x,y);
					}else if (ile[x][y] instanceof Explorateur && ((Explorateur)ile[x][y]).getEquipe()==equipe){
						retirerBrouillard(equipe,x,y);
					}else if (ile[x][y] instanceof Voleur && ((Voleur)ile[x][y]).getEquipe()==equipe){
						retirerBrouillard(equipe,x,y);
					}else if (ile[x][y] instanceof Piegeur && ((Piegeur)ile[x][y]).getEquipe()==equipe){
						retirerBrouillard(equipe,x,y);
					}else if (ile[x][y] instanceof Guerrier && ((Guerrier)ile[x][y]).getEquipe()==equipe){
						retirerBrouillard(equipe,x,y);
					}
				}
			}
		}
	}
	public void retirerBrouillard(int equipe,int x,int y){
		for (int i=0 ; i<brouillard[equipe].length ; i++){
			for (int j=0 ; j<brouillard[equipe].length ; j++){
				if ((i==x+1 && j==y+1) || (i==x+1 && j==y-1) || (i==x-1 && j==y+1) || (i==x-1 && j==y-1) ||
					(i<=x+2 && i>=x-2 && j==y) || (j<=y+2 && j>=y-2 && i==x))
				brouillard[equipe][i][j]=true;
			}
		}
	}
	public void init(int nbrocher){
		int x,y;
		for (int i=0 ; i< ile.length ; i++){
			for (int j=0 ; j< ile.length ; j++){
				if (i==0 || i==ile.length-1 || j==0 || j==ile.length-1){
					this.ile[i][j]=new Parcelle(1);
				}else{
				PlacerCase(new Parcelle(2), i, j);}
			}
		}
		x=r.nextInt(ile.length-2)+1;
		y=r.nextInt(2);
		if(y==0){
			PlacerCase(new Navire(4), x, 0);
			PlacerCase(new Navire(5), ile.length-1-x, ile.length-1);
		}else {
			PlacerCase(new Navire(4), 0, x);
			PlacerCase(new Navire(5), ile.length-1, ile.length-1-x);
		}
		while (rocher<nbrocher){
			x=r.nextInt(ile.length-2)+1;
			y=r.nextInt(ile.length-2)+1;
			if (ile[x][y].remplacable() && rocherPlacable(x, y)){
			    rocher++;
				PlacerCase(new Rocher(3), x, y);
			}
		}
		placerClefCoffre(nbrocher);
	}
	/** Renvoie un booleen, vrai si la parcelle correspondante (parametres x et y) n a pas de rochers ou de navires adjacents. 
	 * @param int x
	 * @param int y
	 * @return true si possible false sinon
	 * **/
	public boolean rocherPlacable(int x,int y){
		if (ile[x][y+1].getInt()==3 || 
			ile[x][y-1].getInt()==3 || 
			ile[x+1][y].getInt()==3 || 
			ile[x-1][y].getInt()==3 ||
			ile[x][y-1].getInt()==4 ||
			ile[x][y+1].getInt()==4 ||
			ile[x+1][y].getInt()==4 || 
			ile[x-1][y].getInt()==4 ||
				ile[x+1][y+1].getInt()==4 ||
				ile[x+1][y-1].getInt()==4 ||
				ile[x-1][y+1].getInt()==4 || 
				ile[x-1][y-1].getInt()==4 ||
			ile[x][y-1].getInt()==5 ||
			ile[x][y+1].getInt()==5 ||
			ile[x+1][y].getInt()==5 || 
			ile[x-1][y].getInt()==5 ||
				ile[x+1][y+1].getInt()==5 ||
				ile[x+1][y-1].getInt()==5 ||
				ile[x-1][y+1].getInt()==5 || 
				ile[x-1][y-1].getInt()==5 ){
			return false;
		}
		return true;
	}
	/** Place la clef ainsi que le coffre sous deux rochers distinct, prend en parametre le nombre de rochers sur l ile.
	 * @param int x
	 * @param int y
	 * @return true si possible false sinon
	 * **/
	public void placerClefCoffre(int rocher){
		int nbRocher=0;
		Random r=new Random();
		int Rclef=r.nextInt(rocher)+1;
		int Rcoffre;
		do{
			Rcoffre=((r.nextInt(rocher)+1+5)%rocher)+1;
		}while (Rcoffre==Rclef);
		boolean clef=false,coffre=false;
			for (int i=0 ; i<ile.length ; i++){
				for (int j=0 ; j<ile.length ; j++){
					if (ile[i][j] instanceof Rocher){nbRocher++;}
					if (nbRocher==Rclef && !clef){PlacerCase(new Rocher(3,true,false), i, j); clef=true; }
					if (nbRocher==Rcoffre && !coffre){PlacerCase(new Rocher(3,false,true), i, j);coffre=true; }
				}
			}
	}
	/** Renvoie un tableau d'entier ou chaque entier correspond a l entier de sa parcelle.(N affiche pas les elements non decouverts les affichages des deux equipe n est donc pas le meme) 
	 * @param int equipe**/
	public int [][] getJeu(int equipe){
		initBrouillard(equipe);
		int [] emplacement=new int[]{0,0};
		boolean coffreFound=false;
		boolean tresorFound=false;
		if (equipe==0 && elementPresent(new Explorateur(6))){
			emplacement=SearchElement(new Explorateur(6));
			if (((Explorateur)ile[emplacement[0]][emplacement[1]]).getCoffreFound())				
				coffreFound=true;
			if (((Explorateur)ile[emplacement[0]][emplacement[1]]).getTresorFound())				
				tresorFound=true;	
		}
		if (equipe==1 && elementPresent(new Explorateur(7))){
			emplacement=SearchElement(new Explorateur(7));
			if (((Explorateur)ile[emplacement[0]][emplacement[1]]).getCoffreFound())
				coffreFound=true;
			if (((Explorateur)ile[emplacement[0]][emplacement[1]]).getTresorFound())				
				tresorFound=true;	
		}
		int [][] result=new int [ile.length][ile.length];
		
		for (int i=0 ; i<ile.length ; i++){
			for (int j=0 ; j<ile.length ; j++){
				if (brouillard[equipe][i][j]){
					if (ile[i][j] instanceof Rocher && ((Rocher)ile[i][j]).getCoffre() && coffreFound && !tresorFound)
						result[i][j]=14;
					else if (ile[i][j] instanceof Rocher && ((Rocher)ile[i][j]).getCoffre() && !((Rocher)ile[i][j]).getTresor() && tresorFound)
						result[i][j]=15;
					else if ((ile [i][j].getInt()==6 || ile [i][j].getInt()==7 || ile [i][j].getInt()==8 || 
							  ile [i][j].getInt()==9 || ile [i][j].getInt()==10 || ile [i][j].getInt()==11 ||
							  ile [i][j].getInt()==12 || ile [i][j].getInt()==13)&& ile.length==6)
						result[i][j]=ile[i][j].getInt()+17;
					else if (ile[i][j] instanceof Piege && ((Piege)ile[i][j]).getEquipe()==1-equipe)
						result[i][j]=2;
					else
					result[i][j]=ile[i][j].getInt();
				}else{
					result[i][j]=16; // brouillard
				}
			}
		}
		return result;
	}
	/** Renvoie un boolean true si l element place en parametre est present sur l ile
	 * @param Parcelle element
	 *  **/
	public boolean elementPresent(Parcelle element){
		boolean result=false;
		for (int i=0 ; i<ile.length ; i++){
			for (int j=0 ; j<ile.length ; j++){
				if (ile[i][j].getInt()==element.getInt())
					result=true;
			}
		}
		return result;
	}
	/** Initialise l ile correspondant au navire avec en parametre les personnages presents dans le navire et l equipe a laquelle ils appartiennent
	 * @param boolean explorateur
	 * @param boolean voleur
	 * @param boolean piegeur
	 * @param boolean guerrier
	 * @param int equipe
	 *  **/
	public void setNavire(Parcelle explorateur,Parcelle voleur,Parcelle piegeur,Parcelle guerrier){
		for (int i=0 ; i<ile.length ; i++){
			for (int j=0 ; j<ile.length ; j++){
				ile[j][i]=new Parcelle(20);
			}
		}
		ile[3][0]=new Parcelle(21);
		ile[2][0]=new Parcelle(22);
		if (explorateur instanceof Explorateur && ((Explorateur)explorateur).getSurnavire()) ile[1][4]=explorateur;
		if (voleur instanceof Voleur && ((Voleur)voleur).getSurnavire()) ile[2][4]=voleur;
		if (piegeur instanceof Piegeur && ((Piegeur)piegeur).getSurnavire()) ile[3][4]=piegeur;
		if (guerrier instanceof Guerrier && ((Guerrier)guerrier).getSurnavire()) ile[4][4]=guerrier;
		
		if (ile[1][4] instanceof Explorateur && ((Explorateur)ile[1][4]).getClef())
			System.out.println("Explorateur a la clef");
		else 
			System.out.println("Explorateur n a pas la clef");
	}
	/** Retourne l entier correspondant a la parcelle d indice x,y 
	 * @param int x
	 * @param int y
	 * **/
	public int getInt(int x,int y){
		return ile[x][y].getInt();
	}
	/** Renvoie la parcelle en ile[x][y]. **/
	public Parcelle getParcelle (int x, int y){
		return ile[x][y];
	}
	/** Place un element (Parcelles) a la case correspondante (x,y) du tableau de Parcelles ile, parametres : l element, coordonnees x et y. **/
	public void PlacerCase(Parcelle element,int x,int y){
		ile[x][y]=element;
	}
	/** Place un explorateur sur l ile en x et y, x et y sont des saisies de l utilisateur via deux JOptionPane. **/
	public void PlacerExplorateurs(){
		int x=0,y=0;
		String value;
		boolean b;
		do{
			value=JOptionPane.showInputDialog("Placement de l'explorateur: \n      x:"); // value prend la valeur de l entree du JOptionPane
			b=value.matches("\\d*(\\d+)"); // b prend la valeur vrai si value est un nombre
			if (b) x=Integer.parseInt(value); // si b est vrai alors x prend la valeur de l entree de JOP
		}while (!b || x<1 || x>ile.length-2); // recommence jusqua ce que b soit vrai, et que 1<x<14
		do{
			value=JOptionPane.showInputDialog("Placement de l'explorateur: \n      y:");
			b=value.matches("\\d*(\\d+)"); // value prend la valeur de l entree du JOptionPane
			if(b) y=Integer.parseInt(value); // si b est vrai alors y prend la valeur de l entree de JOP
		}while (!b || y<1 || y>ile.length-2); // recommence jusqua ce que b soit vrai, et que 1<y<14
		if (ile[x][y].getInt()==2){ // si en [x;y] c'est une parcelle vide
			PlacerCase(new Explorateur(6),x,y);
		}else{ // sinon appel recursif sur la methode
			PlacerExplorateurs();
		}	    
	}
	/** Renvoie un tableau d entier correspondant aux indices x et y de l emplacement d une parcelle dans le tableau de parcelle (ile) 
	 * @param element, type Parcelle (element que l on cherche)
	 * **/
    public int[] SearchElement(Parcelle element){
		for (int x=0 ; x<ile.length ; x++)
			for (int y=0 ; y<ile.length ; y++)
				if (ile[x][y].getInt()==element.getInt())
					return new int[]{x,y};
		return null;
	}
	/** Methode de deplacement d une parcelle dans le tableau de parcelle (ile) en fonction de la chaine choix (Nord Sud Est Ouest)
	 * @param element de type Parcelles
	 * @param choix visant la methode choix qui genere un boite de dialogue
	 * **/
	public boolean Deplacer(Parcelle element,int x, int y,boolean p){
		int [] emplacement=SearchElement(element);
		boolean b=false;
		if (deplacementValide(element,x,y)) b=actionPersonnage(emplacement[0],emplacement[1],x,y,p);
		return b;
	}
	/** Renvoie un boolean vrai si la parcelle place en parametre a acce a la parcelle en x;y.
	 * @param Parcelle element
	 * @param int x
	 * @param int y
	 *  **/
	public boolean deplacementValide(Parcelle element,int x, int y){
		int [] emplacement=SearchElement(element);
		boolean retour=false;
		if (element instanceof Explorateur || element instanceof Piegeur){
			if (emplacement[0]==x && emplacement[1]-1==y||emplacement[0]==x && emplacement[1]+1==y ||
			    emplacement[0]+1==x && emplacement[1]==y||emplacement[0]-1==x && emplacement[1]==y)
				retour=true;
			
		}else if (element instanceof Voleur || element instanceof Guerrier){
			if (emplacement[0]==x && emplacement[1]-1==y||emplacement[0]==x && emplacement[1]+1==y ||
				emplacement[0]+1==x && emplacement[1]==y||emplacement[0]-1==x && emplacement[1]==y ||
				emplacement[0]+1==x && emplacement[1]-1==y||emplacement[0]-1==x && emplacement[1]+1==y||
				emplacement[0]-1==x && emplacement[1]-1==y||emplacement[0]+1==x && emplacement[1]+1==y)
					retour=true;
				
		}
		return retour;
	}
	/** Realise l action du personnage en [x][y]  en fonction de la parcelle de destination en [a][b] (deplacement ou fouille de rocher ...) 
	 * @param int x 
	 * @param int y
	 * @param int a 
	 * @param int b
	 * **/
	public boolean actionPersonnage(int x,int y,int a, int b,boolean p){
		boolean t=false;
		if(ile[x][y] instanceof Explorateur){
			if (ile[a][b].getInt()==2){
				Energie(x,y,-1);
				ile[a][b]=ile[x][y];
				ile[x][y]=new Parcelle(2);
				t=true;
			}else if (ile[a][b] instanceof Rocher){
				Energie(x,y,-5);
				fouillerRocher(a,b,x,y); //fouille du rocher en a;b par l explorateur en x;y
				t=true;
			}else if (ile[a][b] instanceof Navire){
				getBack=true;
				t=true;
			}
		}else if (ile[x][y] instanceof Voleur){
			if (ile[a][b].getInt()==2){
				Energie(x,y,-1);
				ile[a][b]=ile[x][y];
				ile[x][y]=new Parcelle(2);
				t=true;
			}else if (ile[a][b] instanceof Navire){
				getBack=true;
				t=true;
			}else if (ile[a][b] instanceof Explorateur){
				if (ile[x][y].getInt()==8){
					if (ile[a][b].getInt()==7 && ( ((Explorateur)ile[a][b]).getClef() || ((Explorateur)ile[a][b]).getTresor() )){
						((Voleur)ile[x][y]).setClef(((Explorateur)ile[a][b]).getClef());
						((Voleur)ile[x][y]).setTresor(((Explorateur)ile[a][b]).getTresor());
						((Explorateur)ile[a][b]).setClef(!((Voleur)ile[x][y]).getClef());
						((Explorateur)ile[a][b]).setTresor(!((Voleur)ile[x][y]).getTresor());
						Energie(x,y,-10);
						System.out.println(((Explorateur)ile[a][b]).getClef()+" "+((Explorateur)ile[a][b]).getTresor()+" , "+((Voleur)ile[x][y]).getClef()+" "+((Voleur)ile[x][y]).getTresor());
					}else if (ile[a][b].getInt()==6 && ( ((Voleur)ile[x][y]).getClef() || ((Voleur)ile[x][y]).getTresor() )){
						((Explorateur)ile[a][b]).setClef(((Voleur)ile[x][y]).getClef());
						((Explorateur)ile[a][b]).setTresor(((Voleur)ile[x][y]).getTresor());
						((Voleur)ile[x][y]).setClef(!((Explorateur)ile[a][b]).getClef());
						((Voleur)ile[x][y]).setTresor(!((Explorateur)ile[a][b]).getTresor());
						System.out.println(((Explorateur)ile[a][b]).getClef()+" "+((Explorateur)ile[a][b]).getTresor()+" , "+((Voleur)ile[x][y]).getClef()+" "+((Voleur)ile[x][y]).getTresor());
					}
				}else if (ile[x][y].getInt()==9){
					if (ile[a][b].getInt()==6 && ( ((Explorateur)ile[a][b]).getClef() || ((Explorateur)ile[a][b]).getTresor() )){
						((Voleur)ile[x][y]).setClef(((Explorateur)ile[a][b]).getClef());
						((Voleur)ile[x][y]).setTresor(((Explorateur)ile[a][b]).getTresor());
						((Explorateur)ile[a][b]).setClef(!((Voleur)ile[x][y]).getClef());
						((Explorateur)ile[a][b]).setTresor(!((Voleur)ile[x][y]).getTresor());
						Energie(x,y,-10);
						System.out.println(((Explorateur)ile[a][b]).getClef()+" "+((Explorateur)ile[a][b]).getTresor()+" , "+((Voleur)ile[x][y]).getClef()+" "+((Voleur)ile[x][y]).getTresor());
					}else if (ile[a][b].getInt()==7 && ( ((Voleur)ile[x][y]).getClef() || ((Voleur)ile[x][y]).getTresor() )){
						((Explorateur)ile[a][b]).setClef(((Voleur)ile[x][y]).getClef());
						((Explorateur)ile[a][b]).setTresor(((Voleur)ile[x][y]).getTresor());
						((Voleur)ile[x][y]).setClef(!((Explorateur)ile[a][b]).getClef());
						((Voleur)ile[x][y]).setTresor(!((Explorateur)ile[a][b]).getTresor());
						System.out.println(((Explorateur)ile[a][b]).getClef()+" "+((Explorateur)ile[a][b]).getTresor()+" , "+((Voleur)ile[x][y]).getClef()+" "+((Voleur)ile[x][y]).getTresor());
					}
				}
			}
		}else if(ile[x][y] instanceof Piegeur){
			if (ile[a][b].getInt()==2 && !p){
				Energie(x,y,-1);
				ile[a][b]=ile[x][y];
				ile[x][y]=new Parcelle(2);
				t=true;
			}else if (ile[a][b] instanceof Navire){
				getBack=true;
				t=true;
			}else if (p && ile[a][b].getInt()==2){
				ile[a][b]=new Piege(((Piegeur)ile[x][y]).getInt()%2);
				Energie(x,y,-10);
				t=true;
			}
		}else if(ile[x][y] instanceof Guerrier){
			if (ile[a][b].getInt()==2){
				Energie(x,y,-1);
				ile[a][b]=ile[x][y];
				ile[x][y]=new Parcelle(2);
				t=true;
			}else if (ile[a][b] instanceof Navire){
				getBack=true;
				t=true;
			}
		}
		return t;
	}
	public void Energie(int x,int y,int energy){
		if (ile[x][y] instanceof Explorateur)
			((Explorateur)ile[x][y]).setEnergy(energy);
		if (ile[x][y] instanceof Voleur)
			((Voleur)ile[x][y]).setEnergy(energy);
		if (ile[x][y] instanceof Piegeur)
			((Piegeur)ile[x][y]).setEnergy(energy);
		if (ile[x][y] instanceof Guerrier)
			((Guerrier)ile[x][y]).setEnergy(energy);
	}
	/** Retourne le booleen getBack qui precise si un personnage veut remonter sur le navire **/
	public boolean GetBack() {
		return getBack;
	}
	/** Setter du booleen getBack qui determine si un personnage veut remonter sur le navire **/
	public void setGetBack(boolean getBack) {
		this.getBack = getBack;
	}
	/** Methode de fouille d un rocher en ile[x][y] par un explorateur en ile[a][b] (recuperation de la clef, du coffre automatiques)
	 * @param a coordonnee a atteindre
	 * @param b coordonnee a atteindre
	 * @param x coordonnee initiale
	 * @param y coordonnee initiale
	 * **/
	public void fouillerRocher(int a,int b,int x,int y){
		String result="";
		if(((Rocher)ile[a][b]).getClef()){
			result="Vous avez ramassé la clef !";
			((Rocher)ile[a][b]).setClef(false);
			((Explorateur)ile[x][y]).setClef(true);
		}
		if(((Rocher)ile[a][b]).getCoffre()){
			result="Vous avez trouvé le coffre !";
			((Explorateur)ile[x][y]).setCoffreFound(true);
			if(((Explorateur)ile[x][y]).getClef()){
				result="Vous avez ramassé le trésor !";
				((Rocher)ile[a][b]).setTresor(false);
				((Explorateur)ile[x][y]).setTresor(true);
			}
			if (!((Rocher)ile[a][b]).getTresor())
				((Explorateur)ile[x][y]).setTresorFound(true);
		}JOptionPane.showMessageDialog(null, "Rocher fouillé ! \n"+result);
	}
	/** Renvoie une chaine correspondant a l affichage texte de l ile. **/
	public String toString() {
		String s = "";
		for (int i = 0 ; i < ile.length ; i++) {
			s += "+";
			for (int j = 0 ; j < ile.length ; j++) {
				s += "---+";
			}
			s += "\n|";

			for (int k = 0 ; k < ile.length ; k++) {
				s += " ";
				if (ile[k][i].getInt()==1){s +="~";}
				if (ile[k][i].getInt()==2){s +=" ";}
				if (ile[k][i].getInt()==3){s +="R";}
				if (ile[k][i].getInt()==4){s +="N";}
				if (ile[k][i].getInt()==5){s +="n";}
				if (ile[k][i].getInt()==6){s +="E";}// Ici la valeur des cases
				s += " |";
			}
			s += "\n";
		}
		s += "+";
		for (int l = 0 ; l < ile.length ; l++) {
			s += "---+";
		}
		return s;
	}
}