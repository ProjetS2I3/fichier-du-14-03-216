package jalon1;

public class Voleur extends Parcelle implements ParcelleEquipe{
	private int energy=100,equipe;
	private boolean clef,tresor,tourjoue,surnavire,piege;
	public Voleur(int n) {
		super(n);
		equipe=n%2;
	}
	public boolean getClef() {
		return clef;
	}
	public void setClef(boolean clef) {
		this.clef = clef;
	}
	public boolean getTresor() {
		return tresor;
	}
	public void setTresor(boolean tresor) {
		this.tresor = tresor;
	}
	public int getEnergy() {
		return energy;
	}
	public void setEnergy(int energy) {
		if (this.energy+energy>100)
			this.energy=100;
		else
			this.energy = this.energy+energy;
	}
	public boolean getTourjoue() {
		return tourjoue;
	}
	public void setTourjoue(boolean tourjoue) {
		this.tourjoue = tourjoue;
	}
	public boolean getSurnavire() {
		return surnavire;
	}
	public void setSurnavire(boolean surnavire) {
		this.surnavire = surnavire;
	}
	public int getEquipe() {
		return equipe;
	}
	public void setEquipe(int equipe) {
		this.equipe = equipe;
	}
	public boolean getPiege() {
		return piege;
	}
	public void setPiege(boolean piege) {
		this.piege = piege;
	}
}
