package jalon1;

public class Equipe {
	Parcelle[] equipe=new Parcelle[4];
	public Equipe(boolean[] membre,int equipe){
		if (membre[0]){
			this.equipe[0]=new Explorateur(6+equipe);
			((Explorateur)this.equipe[0]).setSurnavire(true);
		}else{
			this.equipe[0]=null;
		}
		if (membre[1]){
			this.equipe[1]=new Voleur(8+equipe);
			((Voleur)this.equipe[1]).setSurnavire(true);
		}else{
			this.equipe[1]=null;
		}
		if (membre[2]){
			this.equipe[2]=new Piegeur(10+equipe);
			((Piegeur)this.equipe[2]).setSurnavire(true);
		}else{
			this.equipe[2]=null;
		}if (membre[3]){
			this.equipe[3]=new Guerrier(12+equipe);
			((Guerrier)this.equipe[3]).setSurnavire(true);
		}else{
			this.equipe[3]=null;
		}
	}
	public Parcelle[] getEquipe(){
		return this.equipe;
	}
	public Parcelle getExplorateur(){
		if (equipe[0]instanceof Explorateur)
			return equipe[0];
		else 
			return null;
	}
	public Parcelle getVoleur(){
		if (equipe[1]instanceof Voleur)
			return equipe[1];
		else 
			return null;
	}
	public Parcelle getPiegeur(){
		if (equipe[2]instanceof Piegeur)
			return equipe[2];
		else 
			return null;
	}
	public Parcelle getGuerrier(){
		if (equipe[3]instanceof Guerrier)
			return equipe[3];
		else 
			return null;
	}
	public void setExplorateur(Parcelle membre){
		this.equipe[0]=membre;
	}
	public void setVoleur(Parcelle membre){
		this.equipe[1]=membre;
	}
	public void setPiegeur(Parcelle membre){
		this.equipe[2]=membre;
	}
	public void setGuerrier(Parcelle membre){
		this.equipe[3]=membre;
	}
	
}
