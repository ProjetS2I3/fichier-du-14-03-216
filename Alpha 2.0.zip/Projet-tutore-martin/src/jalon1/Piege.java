package jalon1;

public class Piege extends Parcelle{
	private int equipe;
	public Piege(int equipe) {
		super(1);
		this.equipe=equipe;
	}
	public int getEquipe() {
		return equipe;
	}
}
