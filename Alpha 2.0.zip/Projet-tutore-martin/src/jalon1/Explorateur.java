package jalon1;

public class Explorateur extends Parcelle {
	private int energy=100,equipe;
	private boolean coffreFound,tresorFound,clef,tresor,tourjoue,surnavire,piege;
	public Explorateur(int n) {
		super(n);
		equipe=n%2;
	}
	public boolean getTresorFound() {
		return tresorFound;
	}
	public void setTresorFound(boolean tresorFound) {
		this.tresorFound = tresorFound;
	}
	public boolean getTourjoue() {
		return tourjoue;
	}
	public void setTourjoue(boolean tourjoue) {
		this.tourjoue = tourjoue;
	}
	public boolean getCoffreFound() {
		return coffreFound;
	}
	public void setCoffreFound(boolean coffreFound) {
		this.coffreFound = coffreFound;
	}
	public int getEnergy() {
		return energy;
	}
	public void setEnergy(int energy) {
		if (this.energy+energy>100)
			this.energy=100;
		else
			this.energy = this.energy+energy;
	}
	public boolean getTresor(){
		return tresor;
	}
	public boolean getClef(){
		return clef;
	}
	public void setClef(boolean clef){
		this.clef=clef;
	}
	public void setTresor(boolean tresor){
		this.tresor=tresor;
	}
	public boolean getSurnavire() {
		return surnavire;
	}
	public void setSurnavire(boolean surnavire) {
		this.surnavire = surnavire;
	}
	public int getEquipe() {
		return equipe;
	}
	public void setEquipe(int equipe) {
		this.equipe = equipe;
	}
	public boolean getPiege() {
		return piege;
	}
	public void setPiege(boolean piege) {
		this.piege = piege;
	}
}
