package jalon1;

public class Guerrier extends Parcelle{
	private int energy=100,equipe;
	private boolean tourjoue,surnavire,piege;
	public Guerrier(int n) {
		super(n);
		equipe=n%2;
	}
	public boolean getTourjoue() {
		return tourjoue;
	}
	public void setTourjoue(boolean tourjoue) {
		this.tourjoue = tourjoue;
	}
	public int getEnergy() {
		return energy;
	}
	public void setEnergy(int energy) {
		if (this.energy+energy>100)
			this.energy=100;
		else
			this.energy = this.energy+energy;
	}
	public boolean getSurnavire() {
		return surnavire;
	}
	public void setSurnavire(boolean surnavire) {
		this.surnavire = surnavire;
	}
	public int getEquipe() {
		return equipe;
	}
	public void setEquipe(int equipe) {
		this.equipe = equipe;
	}
	public boolean getPiege() {
		return piege;
	}
	public void setPiege(boolean piege) {
		this.piege = piege;
	}
}
