package jalon1;
/**
 * La classe Personnage est un heritage de Parcelle
 * @author GroupI-Team
 */
public abstract class Personnage extends Parcelle{
	private int energy=100,equipe,toursRestants;
	private boolean tourjoue,surnavire,piege=false,clef,tresor;
	public Personnage(int n) {
		super(n);
		equipe=n%2;
	}
	public boolean getTourjoue() {
		return tourjoue;
	}
	public int getToursRestants() {
		return toursRestants;
	}
	public void setToursRestants(int toursRestants) {
		this.toursRestants = toursRestants;
	}
	public void setTourjoue(boolean tourjoue) {
		this.tourjoue = tourjoue;
	}
	public int getEnergy() {
		return energy;
	}
	public void setEnergy(int energy) {
		if (this.energy+energy>100)
			this.energy=100;
		else
			this.energy += energy;
	}
	public boolean getSurnavire() {
		return surnavire;
	}
	public void setSurnavire(boolean surnavire) {
		this.surnavire = surnavire;
	}
	public int getEquipe() {
		return equipe;
	}
	public void setEquipe(int equipe) {
		this.equipe = equipe;
	}
	public boolean getPiege() {
		return piege;
	}
	public void setPiege(boolean piege) {
		this.piege = piege;
	}
	public boolean getClef() {
		return clef;
	}
	public void setClef(boolean clef) {
		this.clef = clef;
	}
	public boolean getTresor() {
		return tresor;
	}
	public void setTresor(boolean tresor) {
		this.tresor = tresor;
	}
}
