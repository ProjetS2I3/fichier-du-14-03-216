package jalon1;

public class Parametre {
	private int taille;
	private int rocher;
	private boolean explo1,explo2;
	private boolean voleur1,voleur2;
	private boolean piegeur1,piegeur2;
	private boolean guerrier1,guerrier2;
	private boolean brouillard;
	public Parametre(){}
	public Parametre (int taille,int rocher,boolean explo1,boolean voleur1 ,boolean piegeur1,boolean guerrier1,boolean explo2,boolean voleur2,boolean piegeur2,boolean guerrier2,boolean brouillard){
		this.taille=taille;
		this.rocher=rocher;
		this.explo1=explo1;
		this.explo2=explo2;
		this.voleur1=voleur1;
		this.voleur2=voleur2;
		this.piegeur1=piegeur1;
		this.piegeur2=piegeur2;
		this.guerrier1=guerrier1;
		this.guerrier2=guerrier2;
		this.brouillard=brouillard;
	}
	public Parametre (int taille,int rocher,boolean brouillard){
		this.taille=taille;
		this.rocher=rocher;
		this.brouillard=brouillard;
	}
	public boolean [] getEquipe(int equipe){
		boolean[] result=new boolean [4];
		if (equipe==0){
			result[0]=explo1;
			result[1]=voleur1;
			result[2]=piegeur1;
			result[3]=guerrier1;
		}else{
			result[0]=explo2;
			result[1]=voleur2;
			result[2]=piegeur2;
			result[3]=guerrier2;
		}
		return result;
	}
	public int[] getParam(){
		return new int[]{taille,rocher};
	}
	public boolean getBrouillard() {
		return brouillard;
	}
}
