package jalon1;

import static org.junit.Assert.*;

import javax.swing.JOptionPane;

import org.junit.Test;

public class test_Ile {
	public static void main(String[] args) {
		String[] choixtest = new String[]{"Explorateur","Voleur","Piegeur","Guerrier"};
		String choix = null;
		choix = (String)JOptionPane.showInputDialog(null,"Choississez le personnage que vous voulez tester","Personnage",JOptionPane.QUESTION_MESSAGE, null, choixtest, choixtest[0]);
	}
	@Test
	public void testIle() {
		Ile ile=new Ile();
		int[][]tmp=ile.getJeu();
		assertTrue("l'eau est mal generee",tmp[9][9]==1);
		assertTrue("l'eau est mal generee",tmp[0][0]==1);
		assertTrue("l'eau est mal generee",tmp[9][0]==1);
		assertTrue("l'eau est mal generee",tmp[0][9]==1);
	}
	@Test
	public void testIle2() {
		Ile ile2=new Ile(15,3 );
		int[][]tmp2=ile2.getJeu();
		assertTrue("la generation est invalide",tmp2[5][5]==2 || tmp2[5][5]==4);
		assertTrue("la generation est invalide",tmp2[4][3]==2 || tmp2[4][3]==4);
	}
	@Test
	public void testPlacements(){
		Ile ile3=new Ile(10, 5);
		//test de la methode placer case
		ile3.PlacerCase(new Parcelle(4), 9, 9);
		int[][]tmp3=ile3.getJeu();
		assertTrue("la methode ne fonctionne pas",tmp3[9][9]==4);
		assertFalse(tmp3[9][9]==1);
		//testPlacer explorateurs
		ile3=new Ile(10, 5);
		ile3.PlacerExplorateurs();
		int[][]tmp4=ile3.getJeu();
		assertNotEquals(tmp4, tmp3);
		//testPlacement coffre
		
		
		
	}

}
