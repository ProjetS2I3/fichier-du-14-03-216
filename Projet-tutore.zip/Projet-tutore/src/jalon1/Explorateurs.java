package jalon1;

public class Explorateurs extends Parcelles{
	static int energy;
	static int entitee;
	public Explorateurs(int entitee) {
		super(entitee);
		this.energy=energy;
	}
	public  int a_bouge(int entitee){
		return this.energy-=1;
	}
}
