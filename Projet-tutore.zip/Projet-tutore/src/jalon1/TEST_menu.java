package jalon1;

import javax.swing.JButton;
import javax.swing.JOptionPane;

public class TEST_menu {

	static 	int taille=Integer.parseInt(JOptionPane.showInputDialog("Entre la taille de l'ile"));

	static 	boolean finished=false;

	static 	Plateau [] grille=new Plateau [2];

	static int pourcentage=10;

	static int rocher=(int)((taille-1)*(taille-1)*((double)(pourcentage)/(double)(100)));

	static Iles ile=new Iles(taille,rocher);

	static String choix;

	/**FONCTION DU MAIN **/
	public static void main(String[] args) {

		//ile.PlacerExplorateurs();
		init();
		while(!finished){
			grille[0].setJeu(ile.getJeu());
			grille[0].affichage();
			ATester();
			test();
		}

	}
	public static void init(){
		String[] elements={"images/mer.png","images/herbe.png","images/1.navire.png",
				"images/rocher.png","images/2.navire.png","images/1.explorateur.png",
				"images/2.explorateur.png","images/1.piegeur.png","images/2.piegeur.png",
				"images/arbre","images/coffre.png",};

		System.out.println(ile);


		grille[0]=new Plateau(elements,taille,true);
		grille[0].setJeu(ile.getJeu());
		grille[0].setJeu(ile.getJeu());
		grille[0].affichage();
	}
	public static  void ATester(){
		String[]elements=new String[]{"Explorateur","Voleurs","rocher","bateauJ1","bateauJ2","a definir"};
		choix = (String)JOptionPane.showInputDialog(null,"Choississez un deplacement",
				"Direction",JOptionPane.QUESTION_MESSAGE, null, elements,elements[0]);
	}
	public static void test(){
		int joueur;
		switch (choix) {
		case "Explorateur":
			joueur=Integer.parseInt(JOptionPane.showInputDialog("1 pour J1 /2 pour J2"));
			if(joueur == 1)
				ile.PlacerCase(new Parcelles(6), Integer.parseInt(JOptionPane.showInputDialog("abscisse")), Integer.parseInt(JOptionPane.showInputDialog("abscisse")));
			else if(joueur == 2)
				ile.PlacerCase(new Parcelles(7), Integer.parseInt(JOptionPane.showInputDialog("abscisse")), Integer.parseInt(JOptionPane.showInputDialog("abscisse")));
			break;
		case "Voleurs":
			joueur=Integer.parseInt(JOptionPane.showInputDialog("1 pour J1 /2 pour J2"));
			if(joueur == 1)
				ile.PlacerCase(new Parcelles(8), Integer.parseInt(JOptionPane.showInputDialog("abscisse")), Integer.parseInt(JOptionPane.showInputDialog("abscisse")));
			else if(joueur == 2)
				ile.PlacerCase(new Parcelles(9), Integer.parseInt(JOptionPane.showInputDialog("abscisse")), Integer.parseInt(JOptionPane.showInputDialog("abscisse")));
			break;
		case "rocher":
			ile.PlacerCase(new Parcelles(4), Integer.parseInt(JOptionPane.showInputDialog("abscisse")), Integer.parseInt(JOptionPane.showInputDialog("abscisse")));
			break;
		case "bateauJ1":
			ile.PlacerCase(new Parcelles(3), Integer.parseInt(JOptionPane.showInputDialog("abscisse")), Integer.parseInt(JOptionPane.showInputDialog("abscisse")));
			break;
		case "bateauJ2":
			ile.PlacerCase(new Parcelles(5), Integer.parseInt(JOptionPane.showInputDialog("abscisse")), Integer.parseInt(JOptionPane.showInputDialog("abscisse")));
			break;
		case "a definir":
			JOptionPane.showConfirmDialog(null,"Cette section est a definir");
			break;
		default:
			break;
		}
	}

}
