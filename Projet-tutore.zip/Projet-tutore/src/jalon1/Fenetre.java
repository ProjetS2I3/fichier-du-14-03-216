package jalon1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class Fenetre extends JDialog {
	private Parametre params = new Parametre();
	private boolean sendData;
	private JComboBox taille,rocher,voleur1,voleur2,piegeur1,piegeur2,guerrier1,guerrier2,brouillard;
	private JLabel tailleLabel,rocherLabel,voleur1Label,voleur2Label,piegeur1Label,piegeur2Label,guerrier1Label,guerrier2Label,brouillardLabel;
	public Fenetre(JFrame parent, String title, boolean modal){
	    super(parent, title, modal);
	    this.setSize(700, 500);
	    this.setLocationRelativeTo(null);
	    this.setResizable(false);
	    this.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
	    this.initComponent();
	  }
	public Fenetre(JFrame parent, String title, boolean modal,boolean useless){
	    super(parent, title, modal);
	    this.setSize(600, 300);
	    this.setLocationRelativeTo(null);
	    this.setResizable(false);
	    this.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
	    this.initComponentModeTest();
	  }
	public Parametre showFenetre(){
		this.sendData = false;
		this.setVisible(true);      
		return this.params;      
	}
	private void initComponentModeTest(){
		//La taille
	    JPanel panTaille = new JPanel();
	    panTaille.setBackground(Color.white);
	    panTaille.setPreferredSize(new Dimension(260, 60));
	    taille = new JComboBox();
	    taille.addItem("10");
	    taille.addItem("11");
	    taille.addItem("12");
	    taille.addItem("13");
	    taille.addItem("14");
	    taille.addItem("15");
	    taille.addItem("16");
	    taille.addItem("17");
	    taille.setPreferredSize(new Dimension(75, 25));
	    panTaille.setBorder(BorderFactory.createTitledBorder("Taille de l'ile"));
	    tailleLabel = new JLabel("Selectionnez la taille :");
	    panTaille.add(tailleLabel);
	    panTaille.add(taille);
	    
	    //Le pourcentage de rocher
	    JPanel panRocher = new JPanel();
	    panRocher.setBackground(Color.white);
	    panRocher.setPreferredSize(new Dimension(260, 60));
	    rocher = new JComboBox();
	    rocher.addItem("10");
	    rocher.addItem("11");
	    rocher.addItem("12");
	    rocher.addItem("13");
	    rocher.addItem("14");
	    rocher.addItem("15");
	    rocher.addItem("16");
	    rocher.addItem("17");
	    rocher.setPreferredSize(new Dimension(75, 25));
	    panRocher.setBorder(BorderFactory.createTitledBorder("Pourcentage de rocher"));
	    rocherLabel = new JLabel("Saisir un entier :");
	    panRocher.add(rocherLabel);
	    panRocher.add(rocher);
	    
	 // Brouillard
	    JPanel panBrouillard = new JPanel();
	    panBrouillard.setBackground(Color.white);
	    panBrouillard.setPreferredSize(new Dimension(400, 60));
	    brouillard = new JComboBox();
	    brouillard.addItem("ACTIVER");
	    brouillard.addItem("DESACTIVER");
	    brouillard.setPreferredSize(new Dimension(150, 30));
	    panBrouillard.setBorder(BorderFactory.createTitledBorder("Brouillard :"));
	    brouillardLabel= new JLabel("Activer / Desactiver :");
	    panBrouillard.add(brouillardLabel);
	    panBrouillard.add(brouillard);
	    
	    JPanel content = new JPanel();
	    content.setBackground(Color.white);
	    content.add(panTaille);
	    content.add(panRocher);
	    content.add(panBrouillard);
	    JPanel control = new JPanel();
	    JButton okBouton = new JButton("OK");
	    okBouton.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent arg0) {        
		    	params = new Parametre(Integer.parseInt((String)taille.getSelectedItem()), 
		    			Integer.parseInt((String)rocher.getSelectedItem()),
		    			returnValue((String)brouillard.getSelectedItem()));
		    	setVisible(false);
		    }
	    });
	    JButton cancelBouton = new JButton("Par défaut");
	    cancelBouton.addActionListener(new ActionListener(){
	     public void actionPerformed(ActionEvent arg0) {
	    	 params = new Parametre(15,10,true);
	        setVisible(false);
	      }      
	    });
	    control.add(okBouton);
	    control.add(cancelBouton);
	    this.getContentPane().add(content, BorderLayout.CENTER);
	    this.getContentPane().add(control, BorderLayout.SOUTH);
	}
	private void initComponent(){
		//La taille
	    JPanel panTaille = new JPanel();
	    panTaille.setBackground(Color.white);
	    panTaille.setPreferredSize(new Dimension(260, 60));
	    taille = new JComboBox();
	    taille.addItem("10");
	    taille.addItem("11");
	    taille.addItem("12");
	    taille.addItem("13");
	    taille.addItem("14");
	    taille.addItem("15");
	    taille.addItem("16");
	    taille.addItem("17");
	    taille.setPreferredSize(new Dimension(75, 25));
	    panTaille.setBorder(BorderFactory.createTitledBorder("Taille de l'ile"));
	    tailleLabel = new JLabel("Selectionnez la taille :");
	    panTaille.add(tailleLabel);
	    panTaille.add(taille);
	    
	    //Le pourcentage de rocher
	    JPanel panRocher = new JPanel();
	    panRocher.setBackground(Color.white);
	    panRocher.setPreferredSize(new Dimension(260, 60));
	    rocher = new JComboBox();
	    rocher.addItem("10");
	    rocher.addItem("11");
	    rocher.addItem("12");
	    rocher.addItem("13");
	    rocher.addItem("14");
	    rocher.addItem("15");
	    rocher.addItem("16");
	    rocher.addItem("17");
	    rocher.setPreferredSize(new Dimension(75, 25));
	    panRocher.setBorder(BorderFactory.createTitledBorder("Pourcentage de rocher"));
	    rocherLabel = new JLabel("Saisir un entier :");
	    panRocher.add(rocherLabel);
	    panRocher.add(rocher);
	    
	    //Selection des personnages 
	    // Voleur equipe 1
	    JPanel panVoleur1 = new JPanel();
	    panVoleur1.setBackground(Color.white);
	    panVoleur1.setPreferredSize(new Dimension(300, 60));
	    voleur1 = new JComboBox();
	    voleur1.addItem("OUI");
	    voleur1.addItem("NON");
	    voleur1.setPreferredSize(new Dimension(75, 25));
	    panVoleur1.setBorder(BorderFactory.createTitledBorder("Voleur (equipe 1) :"));
	    voleur1Label= new JLabel("Selectionnez oui ou non");
	    panVoleur1.add(voleur1Label);
	    panVoleur1.add(voleur1);
	    // Voleur equipe 2
	    JPanel panVoleur2 = new JPanel();
	    panVoleur2.setBackground(Color.white);
	    panVoleur2.setPreferredSize(new Dimension(300, 60));
	    voleur2 = new JComboBox();
	    voleur2.addItem("OUI");
	    voleur2.addItem("NON");
	    voleur2.setPreferredSize(new Dimension(75, 25));
	    panVoleur2.setBorder(BorderFactory.createTitledBorder("Voleur (equipe 2) :"));
	    voleur2Label= new JLabel("Selectionnez oui ou non");
	    panVoleur2.add(voleur2Label);
	    panVoleur2.add(voleur2);
	    // Piegeur equipe 1
	    JPanel panPiegeur1 = new JPanel();
	    panPiegeur1.setBackground(Color.white);
	    panPiegeur1.setPreferredSize(new Dimension(300, 60));
	    piegeur1 = new JComboBox();
	    piegeur1.addItem("OUI");
	    piegeur1.addItem("NON");
	    piegeur1.setPreferredSize(new Dimension(75, 25));
	    panPiegeur1.setBorder(BorderFactory.createTitledBorder("Piegeur (equipe 1) :"));
	    piegeur1Label= new JLabel("Selectionnez oui ou non");
	    panPiegeur1.add(piegeur1Label);
	    panPiegeur1.add(piegeur1);
	    // Piegeur equipe 2
	    JPanel panPiegeur2 = new JPanel();
	    panPiegeur2.setBackground(Color.white);
	    panPiegeur2.setPreferredSize(new Dimension(300, 60));
	    piegeur2 = new JComboBox();
	    piegeur2.addItem("OUI");
	    piegeur2.addItem("NON");
	    piegeur2.setPreferredSize(new Dimension(75, 25));
	    panPiegeur2.setBorder(BorderFactory.createTitledBorder("Piegeur (equipe 2) :"));
	    piegeur2Label= new JLabel("Selectionnez oui ou non");
	    panPiegeur2.add(piegeur2Label);
	    panPiegeur2.add(piegeur2);
	    // Guerrier equipe 1
	    JPanel panGuerrier1 = new JPanel();
	    panGuerrier1.setBackground(Color.white);
	    panGuerrier1.setPreferredSize(new Dimension(300, 60));
	    guerrier1 = new JComboBox();
	    guerrier1.addItem("OUI");
	    guerrier1.addItem("NON");
	    guerrier1.setPreferredSize(new Dimension(75, 25));
	    panGuerrier1.setBorder(BorderFactory.createTitledBorder("Guerrier (equipe 1) :"));
	    guerrier1Label= new JLabel("Selectionnez oui ou non");
	    panGuerrier1.add(guerrier1Label);
	    panGuerrier1.add(guerrier1);
	    // Guerrier equipe 2
	    JPanel panGuerrier2 = new JPanel();
	    panGuerrier2.setBackground(Color.white);
	    panGuerrier2.setPreferredSize(new Dimension(300, 60));
	    guerrier2 = new JComboBox();
	    guerrier2.addItem("OUI");
	    guerrier2.addItem("NON");
	    guerrier2.setPreferredSize(new Dimension(75, 25));
	    panGuerrier2.setBorder(BorderFactory.createTitledBorder("Guerrier (equipe 2) :"));
	    guerrier2Label= new JLabel("Selectionnez oui ou non");
	    panGuerrier2.add(guerrier2Label);
	    panGuerrier2.add(guerrier2);
	    
	    // Brouillard
	    JPanel panBrouillard = new JPanel();
	    panBrouillard.setBackground(Color.white);
	    panBrouillard.setPreferredSize(new Dimension(400, 60));
	    brouillard = new JComboBox();
	    brouillard.addItem("ACTIVER");
	    brouillard.addItem("DESACTIVER");
	    brouillard.setPreferredSize(new Dimension(150, 30));
	    panBrouillard.setBorder(BorderFactory.createTitledBorder("Brouillard :"));
	    brouillardLabel= new JLabel("Activer / Desactiver :");
	    panBrouillard.add(brouillardLabel);
	    panBrouillard.add(brouillard);
	   
	       
	    JPanel content = new JPanel();
	    content.setBackground(Color.white);
	    content.add(panTaille);
	    content.add(panRocher);
	    content.add(panVoleur1);
	    content.add(panVoleur2);
	    content.add(panPiegeur1);
	    content.add(panPiegeur2);
	    content.add(panGuerrier1);
	    content.add(panGuerrier2);
	    content.add(panBrouillard);
	    JPanel control = new JPanel();
	    JButton okBouton = new JButton("OK");
	    okBouton.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent arg0) {        
		    	params = new Parametre(Integer.parseInt((String)taille.getSelectedItem()), 
		    			Integer.parseInt((String)rocher.getSelectedItem()),
		    			true,returnValue((String)voleur1.getSelectedItem()),
		    			returnValue((String)piegeur1.getSelectedItem()),
		    			returnValue((String)guerrier1.getSelectedItem()),
		    			true,returnValue((String)voleur2.getSelectedItem()),
		    			returnValue((String)piegeur2.getSelectedItem()),
		    			returnValue((String)guerrier2.getSelectedItem()),
		    			returnValue((String)brouillard.getSelectedItem()));
		    	setVisible(false);
		    }
	    });
	    JButton cancelBouton = new JButton("Par défaut");
	    cancelBouton.addActionListener(new ActionListener(){
	     public void actionPerformed(ActionEvent arg0) {
	    	 params = new Parametre(15,15,true,true,true,true,true,true,true,true,true);
	        setVisible(false);
	      }      
	    });
	    control.add(okBouton);
	    control.add(cancelBouton);
	    this.getContentPane().add(content, BorderLayout.CENTER);
	    this.getContentPane().add(control, BorderLayout.SOUTH);
	}
	public boolean returnValue(String msg){
		if(msg.equals("OUI") || msg.equals("ACTIVER"))
			return true;
		else
			return false;
			
	}
}


