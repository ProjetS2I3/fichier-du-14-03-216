package jalon1;

import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
/**
 * La classe Jeu permet de simuler la phase de jeu du jeu 
 * Treasure Hunter en chargeant des images d'un tableau "element" 
 * à travers un plateau chargé à partir d'un tableau d'entier
 * de la classe ile.
 * @author GroupI-Team
 */
public class Jeu {
	private static int taille=15,pourcentage=10,rocher=(int)((taille-2)*(taille-2)*((double)(pourcentage)/(double)(100)));
	private static boolean membreEquipe0[]=new boolean[]{true,true,true,true};
	private static boolean membreEquipe1[]=new boolean[]{true,true,true,true};
	private static Equipe []equipes=new Equipe [2];	
	private static boolean finished=false,findetour=false,modeJeu=true,quitter,brouillard;
	private static InputEvent event;
	private static Plateau [] grille=new Plateau [4]; 
	private static Ile ile,navire=new Ile(6);
	private static boolean actionFaite []=new boolean [4];
	private static String[] elements={
			"images/mer.png", // 1
			"images/sable.png", // 2
			"images/rocher.png", // 3
			"images/1.navire.png", // 4
			"images/2.navire.png", // 5
			"images/1.explorateur.png", // 6
			"images/2.explorateur.png", // 7
			"images/1.voleur.png", // 8
			"images/2.voleur.png", // 9
			"images/1.piegeur.png", // 10
			"images/2.piegeur.png", // 11
			"images/1.guerrier.png", // 12
			"images/2.guerrier.png", // 13
			"images/coffreferme.png", // 14
			"images/coffreouvert.png", // 15
			"images/brouillard.png", // 16
			"images/piege.png", // 17
			"images/RIP.png", // 18
			"", // 19
			"images/planche.png", // 20
			"images/tonneau.png", // 21
			"images/mat1.png", // 22
			"images/1.explorateur.navire.png", // 23
			"images/2.explorateur.navire.png", // 24
			"images/1.voleur.navire.png", // 25
			"images/2.voleur.navire.png", // 26
			"images/1.piegeur.navire.png", // 27
			"images/2.piegeur.navire.png", // 28
			"images/1.guerrier.navire.png", // 29
			"images/2.guerrier.navire.png", // 30
			"images/piegeExplo.png", // 31
			"images/piegeExplo.png", // 32
			"images/piegeVoleur.png", //33
			"images/piegeVoleur.png", // 34
			"images/piegePiegeur.png", // 35
			"images/piegePiegeur.png", // 36
			"images/piegeGuerrier.png", // 37
			"images/piegeGuerrier.png", // 38
			};
	private static int x=0,y=0,equipe=1;
public static void main(String[] args) {
	while (!quitter){
		finished=false;
		menuPrincipal(); // Choix du mode de jeu (mode test, mode jeu, quitter)
		if (modeJeu && !quitter){
			menuModeJeu();
			while(!finished){		
				findetour=false;
				if ((equipes[equipe].getExplorateur() instanceof Explorateur 
						&& ((Explorateur)equipes[equipe].getExplorateur()).getTresor() 
						&& ((Explorateur)equipes[equipe].getExplorateur()).getSurnavire())
						|| teamDead(0) || teamDead(1)){
						finished=true;
						findetour=true;
						closeAll();
						if (teamDead(0))
							JOptionPane.showMessageDialog(null,"Tout les personnages de l'équipe 1 sont morts, l'équipe 2 gagne ! CQFD","Information",JOptionPane.INFORMATION_MESSAGE);
						else if (teamDead(1))
							JOptionPane.showMessageDialog(null,"Tout les personnages de l'équipe 2 sont morts, l'équipe 1 gagne ! CQFD","Information",JOptionPane.INFORMATION_MESSAGE);
						else 
							JOptionPane.showMessageDialog(null,"L'équipe "+(equipe+1)+" a rapporté le trésor sur son navire et remporte la partie !","Information",JOptionPane.INFORMATION_MESSAGE);
					}
				resetTour();
				decrementerTourPiege();
				equipe=1-equipe;
				while (!findetour){
					if (teamDead(equipe)){
						findetour=true;
						break;
					}
					recuperationEnergie();
					infoEnergie();
					affichage();
					tourEquipe();
					changementDeTour();
				}
			}
		}else if (!quitter){
			menuModeJeu();
			while(!finished){		
				findetour=false;
				if ((equipes[equipe].getExplorateur() instanceof Explorateur 
					&& ((Explorateur)equipes[equipe].getExplorateur()).getTresor() 
					&& ((Explorateur)equipes[equipe].getExplorateur()).getSurnavire())
					|| teamDead(0) || teamDead(1)){
					finished=true;
					findetour=true;
					closeAll();
					if (teamDead(0))
						JOptionPane.showMessageDialog(null,"Tout les personnages de l'équipe 1 sont morts, l'équipe 2 gagne ! CQFD","Information",JOptionPane.INFORMATION_MESSAGE);
					else if (teamDead(1))
						JOptionPane.showMessageDialog(null,"Tout les personnages de l'équipe 2 sont morts, l'équipe 1 gagne ! CQFD","Information",JOptionPane.INFORMATION_MESSAGE);
					else 
						JOptionPane.showMessageDialog(null,"L'équipe "+(equipe+1)+" a rapporté le trésor sur son navire et remporte la partie !","Information",JOptionPane.INFORMATION_MESSAGE);
				}
				resetTour();
				decrementerTourPiege();
				equipe=1-equipe;
				while (!findetour){
					if (teamDead(equipe)){
						findetour=true;
						break;
					}
					recuperationEnergie();
					resetTour(); // mode Test
					infoEnergie(); // mode Test
					affichage();
					tourEquipe();
					changementDeTour();
				}
			}
		}
	}
}
public static void resetTour(){
	setEquipe();
	setEquipe();
	if (equipes[equipe].getExplorateur() instanceof Explorateur)
		((Explorateur)equipes[equipe].getExplorateur()).setTourjoue(false);
	if (equipes[equipe].getVoleur() instanceof Voleur)
		((Voleur)equipes[equipe].getVoleur()).setTourjoue(false);
	if (equipes[equipe].getPiegeur() instanceof Piegeur)
		((Piegeur)equipes[equipe].getPiegeur()).setTourjoue(false);
	if (equipes[equipe].getGuerrier() instanceof Guerrier)
		((Guerrier)equipes[equipe].getGuerrier()).setTourjoue(false);
}
public static void decrementerTourPiege(){
	for (int i=0 ; i<taille ; i++){
		for (int j=0 ; j<taille ; j++){
			if (ile.getParcelle(i, j) instanceof Personnage && ((Personnage)ile.getParcelle(i, j)).getPiege() && ((Personnage)ile.getParcelle(i, j)).getEquipe()==1-equipe){
				((Personnage)ile.getParcelle(i, j)).setToursRestants(((Personnage)ile.getParcelle(i, j)).getToursRestants()-1);
				if (((Personnage)ile.getParcelle(i, j)).getToursRestants()==0)
				((Personnage)ile.getParcelle(i, j)).setPiege(false);
			}
		}
	}
}
public static void affichage(){
	grille[1-equipe].close();
	grille[2].close();
	grille[3].close();
	grille[equipe].setJeu(ile.getJeu(equipe,brouillard));
	grille[equipe].affichage();
}
public static void tourEquipe(){
	grille[equipe].clearHighlight();
	if (!modeJeu)
		setTourJouer();
	cliqueSouris();
	personnagePiege();
	tourNavire();
	tourExplorateur();
	tourVoleur();
	tourPiegeur();
	tourGuerrier();
	if (modeJeu)
		setTourJouer();
}
public static void tourNavire(){
	if (equipe==0){
		if(ile.getInt(x, y)==4){ //Selection du navire
			navire.setNavire(((Explorateur)equipes[equipe].getExplorateur()),((Voleur)equipes[equipe].getVoleur()),((Piegeur)equipes[equipe].getPiegeur()),((Guerrier)equipes[equipe].getGuerrier()));
			grille[equipe+2].setJeu(navire.getJeu(equipe,false));
			grille[equipe+2].affichage();
			int keyCode=0;
			int xbis=0,ybis=0;
			boolean sortir=false;
			do {
				grille[equipe+2].affichage();
				event=grille[equipe+2].waitEvent();
				if (event instanceof MouseEvent) {
					xbis = grille[equipe+2].getX((MouseEvent) event) ;
					ybis = grille[equipe+2].getY((MouseEvent) event) ;
					sortir=true;
				}else if(event instanceof KeyEvent) {
					keyCode = ((KeyEvent) event).getKeyCode() ;
					if (keyCode==27){
						sortir=true;
				}
			}
			}while (!sortir);
			if(navire.getParcelle(ybis,xbis) instanceof Explorateur){
				if(ile.getInt(x+1,y)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x+1,y);
					((Explorateur)equipes[equipe].getExplorateur()).setSurnavire(false); // pas certain que ça fonctionne
				}else if (ile.getInt(x,y+1)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y+1);
					((Explorateur)equipes[equipe].getExplorateur()).setSurnavire(false);
				}
			}else if(navire.getParcelle(ybis,xbis) instanceof Voleur){
				if(ile.getInt(x+1,y)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x+1,y);
					((Voleur)equipes[equipe].getVoleur()).setSurnavire(false);
				}else if (ile.getInt(x,y+1)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y+1);
					((Voleur)equipes[equipe].getVoleur()).setSurnavire(false);
				}
			}else if(navire.getParcelle(ybis,xbis) instanceof Piegeur){
				if(ile.getInt(x+1,y)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x+1,y);
					((Piegeur)equipes[equipe].getPiegeur()).setSurnavire(false);
				}else if (ile.getInt(x,y+1)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y+1);
					((Piegeur)equipes[equipe].getPiegeur()).setSurnavire(false);
				}
			}else if(navire.getParcelle(ybis,xbis) instanceof Guerrier){
				if(ile.getInt(x+1,y)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x+1,y);
					((Guerrier)equipes[equipe].getGuerrier()).setSurnavire(false);
				}else if (ile.getInt(x,y+1)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y+1);
					((Guerrier)equipes[equipe].getGuerrier()).setSurnavire(false);
				}
			}
		}
	}else{
		if(ile.getInt(x, y)==5){ //Selection du navire
			navire.setNavire(((Explorateur)equipes[equipe].getExplorateur()),((Voleur)equipes[equipe].getVoleur()),((Piegeur)equipes[equipe].getPiegeur()),((Guerrier)equipes[equipe].getGuerrier()));
			grille[equipe+2].setJeu(navire.getJeu(equipe,true));
			grille[equipe+2].affichage();	
			int KeyCode=0;
			int xbis=0,ybis=0;
			boolean sortir=false;
			do {
				event=grille[equipe+2].waitEvent();
				if (event instanceof MouseEvent) {
					xbis = grille[equipe+2].getX((MouseEvent) event) ;
		        	ybis = grille[equipe+2].getY((MouseEvent) event) ;
		        	sortir=true;
		        } else if (event instanceof KeyEvent) {
		        	KeyCode = ((KeyEvent) event).getKeyCode() ;
		        	if (KeyCode==27)
		        		sortir=true;
		        }
			}while (!sortir);
			if(navire.getParcelle(ybis,xbis) instanceof Explorateur){
				if(ile.getInt(x-1,y)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x-1,y);
					((Explorateur)equipes[equipe].getExplorateur()).setSurnavire(false);
				}else if (ile.getInt(x,y-1)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y-1);
					((Explorateur)equipes[equipe].getExplorateur()).setSurnavire(false);
				}
			}else if(navire.getParcelle(ybis,xbis) instanceof Voleur){
				if(ile.getInt(x-1,y)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x-1,y);
					((Voleur)equipes[equipe].getVoleur()).setSurnavire(false);
				}else if (ile.getInt(x,y-1)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y-1);
					((Voleur)equipes[equipe].getVoleur()).setSurnavire(false);
				}
			}else if(navire.getParcelle(ybis,xbis) instanceof Piegeur){
				if(ile.getInt(x-1,y)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x-1,y);
					((Piegeur)equipes[equipe].getPiegeur()).setSurnavire(false);
				}else if (ile.getInt(x,y-1)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y-1);
					((Piegeur)equipes[equipe].getPiegeur()).setSurnavire(false);
				}
			}else if(navire.getParcelle(ybis,xbis) instanceof Guerrier){
				if(ile.getInt(x-1,y)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x-1,y);
					((Guerrier)equipes[equipe].getGuerrier()).setSurnavire(false);
				}else if (ile.getInt(x,y-1)==2){
					ile.PlacerCase(navire.getParcelle(ybis,xbis),x,y-1);
					((Guerrier)equipes[equipe].getGuerrier()).setSurnavire(false);
				}
			}
		}
	}
}
public static void tourExplorateur(){
	if(ile.getInt(x,y)==6+equipe && !actionFaite[0] && !((Personnage)ile.getParcelle(x, y)).getPiege()){
		grille[equipe].setHighlight(y, x);
		int xbis=x,ybis=y;
		do{ event = grille[equipe].waitEvent();
		if(event instanceof MouseEvent){
			y = grille[equipe].getX((MouseEvent) event);
			x = grille[equipe].getY((MouseEvent) event);
		}
		}while (!(event instanceof MouseEvent));
			if (ile.Deplacer(new Explorateur(6+equipe),x,y,false))
				((Explorateur)equipes[equipe].getExplorateur()).setTourjoue(true);
		if(ile.GetBack()&& ile.getParcelle(x, y).getInt()==4+equipe){
			((Explorateur)equipes[equipe].getExplorateur()).setSurnavire(true);
			navire.PlacerCase(ile.getParcelle(xbis, ybis),1,4);
			ile.PlacerCase(new Parcelle(2), xbis, ybis);
			ile.setGetBack(false);
		}
	}
}
public static void tourVoleur(){
	if(ile.getInt(x,y)==8+equipe &&!actionFaite[1] && !((Personnage)ile.getParcelle(x, y)).getPiege()){
		grille[equipe].setHighlight(y, x);
		int xbis=x,ybis=y;
		do{ 
			event = grille[equipe].waitEvent();
			if(event instanceof MouseEvent){
			y = grille[equipe].getX((MouseEvent) event);
			x = grille[equipe].getY((MouseEvent) event);
			}
		}while (!(event instanceof MouseEvent));
		if (ile.Deplacer(new Voleur(8+equipe),x,y,false))
			((Voleur)equipes[equipe].getVoleur()).setTourjoue(true);
		if(ile.GetBack() && ile.getParcelle(x, y).getInt()==4+equipe){
			((Voleur)equipes[equipe].getVoleur()).setSurnavire(true);
			navire.PlacerCase(ile.getParcelle(xbis, ybis),2,4);
			ile.PlacerCase(new Parcelle(2), xbis, ybis);
			ile.setGetBack(false);
		}
	}
}
public static void personnagePiege(){
	if (ile.getParcelle(x, y) instanceof Personnage && ((Personnage)ile.getParcelle(x, y)).getPiege()){
		JOptionPane.showMessageDialog(null,"Ce personnage est piégé pour encore "+((Personnage)ile.getParcelle(x, y)).getToursRestants()+" tours de jeu.","Information",JOptionPane.INFORMATION_MESSAGE);
	}
}
public static void tourPiegeur(){
	if(ile.getInt(x, y)==10+equipe &&!actionFaite[2] && !((Personnage)ile.getParcelle(x, y)).getPiege()){
		grille[equipe].setHighlight(y, x);
		int xbis=x,ybis=y;
		boolean p=false;
		do{ 
			event = grille[equipe].waitEvent();
			if(event instanceof MouseEvent){
				y = grille[equipe].getX((MouseEvent) event);
				x = grille[equipe].getY((MouseEvent) event);
			}else if (event instanceof KeyEvent && ((KeyEvent)event).getKeyCode()==80){
				p=true;
			}
		}while (!(event instanceof MouseEvent));
			if (ile.Deplacer(new Piegeur(10+equipe),x,y,p))
				((Piegeur)equipes[equipe].getPiegeur()).setTourjoue(true);	
		if(ile.GetBack()&& ile.getParcelle(x, y).getInt()==4+equipe){
			((Piegeur)equipes[equipe].getPiegeur()).setSurnavire(true);
			navire.PlacerCase(ile.getParcelle(xbis, ybis),3,4);
			ile.PlacerCase(new Parcelle(2), xbis, ybis);
			ile.setGetBack(false);
		}
		}
}
public static void tourGuerrier(){
	if(ile.getInt(x,y)==12+equipe &&!actionFaite[3] && !((Personnage)ile.getParcelle(x, y)).getPiege()){
		grille[equipe].setHighlight(y, x);
		int xbis=x,ybis=y;
		do{ event = grille[equipe].waitEvent();
		if(event instanceof MouseEvent){
			y = grille[equipe].getX((MouseEvent) event);
			x = grille[equipe].getY((MouseEvent) event);
		}
		}while (!(event instanceof MouseEvent));
			if (ile.Deplacer(new Guerrier(12+equipe),x,y,false))
				((Guerrier)equipes[equipe].getGuerrier()).setTourjoue(true);
			if(ile.GetBack()&& ile.getParcelle(x, y).getInt()==4+equipe){
				((Guerrier)equipes[equipe].getGuerrier()).setSurnavire(true);
				navire.PlacerCase(ile.getParcelle(xbis, ybis),4,4);
				ile.PlacerCase(new Parcelle(2), xbis, ybis);
				ile.setGetBack(false);
			}
		}
}
public static void cliqueSouris(){
	do{
		event = grille[equipe].waitEvent();
	if(event instanceof MouseEvent){
		y = grille[equipe].getX((MouseEvent) event);
		x = grille[equipe].getY((MouseEvent) event);
	}
	if (event instanceof KeyEvent && ((KeyEvent) event).getKeyCode()==27){
		findetour=true;
		break;
	}
	}while (!(event instanceof MouseEvent) || (event instanceof KeyEvent && ((KeyEvent) event).getKeyCode()==27));
}
public static void setTourJouer(){
	if (equipes[equipe].getExplorateur() instanceof Explorateur)
		actionFaite[0]=((Explorateur)equipes[equipe].getExplorateur()).getTourjoue();
	else 
		actionFaite[0]=true;
	if (equipes[equipe].getVoleur() instanceof Voleur)
		actionFaite[1]=((Voleur)equipes[equipe].getVoleur()).getTourjoue();
	else 
		actionFaite[1]=true;
	if (equipes[equipe].getPiegeur() instanceof Piegeur)
		actionFaite[2]=((Piegeur)equipes[equipe].getPiegeur()).getTourjoue();
	else 
		actionFaite[2]=true;
	if (equipes[equipe].getGuerrier() instanceof Guerrier)
		actionFaite[3]=((Guerrier)equipes[equipe].getGuerrier()).getTourjoue();
	else 
		actionFaite[3]=true;
}
public static void changementDeTour(){
	if (actionFaite[0] && actionFaite[1] && actionFaite[2] && actionFaite[3]){
		findetour=true;
	}
}
public static void setEquipe(){
	if (equipes[equipe].getExplorateur() instanceof Explorateur && ((Explorateur)equipes[equipe].getExplorateur()).getEnergy()<=0){
		ile.PlacerCase(new RIP(((Explorateur)equipes[equipe].getExplorateur()).getClef(),((Explorateur)equipes[equipe].getExplorateur()).getTresor()),ile.SearchElement(((Explorateur)equipes[equipe].getExplorateur()))[0],ile.SearchElement(((Explorateur)equipes[equipe].getExplorateur()))[1]);
		equipes[equipe].setExplorateur(null);
	}
	if (equipes[equipe].getVoleur() instanceof Voleur && ((Voleur)equipes[equipe].getVoleur()).getEnergy()<=0){
		ile.PlacerCase(new RIP(((Voleur)equipes[equipe].getVoleur()).getClef(),((Voleur)equipes[equipe].getVoleur()).getTresor()),ile.SearchElement(((Voleur)equipes[equipe].getVoleur()))[0],ile.SearchElement(((Voleur)equipes[equipe].getVoleur()))[1]);
		equipes[equipe].setVoleur(null);
	}
	if (equipes[equipe].getPiegeur() instanceof Piegeur && ((Piegeur)equipes[equipe].getPiegeur()).getEnergy()<=0){
		ile.PlacerCase(new RIP(((Piegeur)equipes[equipe].getPiegeur()).getClef(),((Piegeur)equipes[equipe].getPiegeur()).getTresor()),ile.SearchElement(((Piegeur)equipes[equipe].getPiegeur()))[0],ile.SearchElement(((Piegeur)equipes[equipe].getPiegeur()))[1]);
		equipes[equipe].setPiegeur(null);
	}
	if (equipes[equipe].getGuerrier() instanceof Guerrier && ((Guerrier)equipes[equipe].getGuerrier()).getEnergy()<=0){
		ile.PlacerCase(new RIP(((Guerrier)equipes[equipe].getGuerrier()).getClef(),((Guerrier)equipes[equipe].getGuerrier()).getTresor()),ile.SearchElement(((Guerrier)equipes[equipe].getGuerrier()))[0],ile.SearchElement(((Guerrier)equipes[equipe].getGuerrier()))[1]);
		equipes[equipe].setGuerrier(null);
	}
	equipe=1-equipe;
}
public static void recuperationEnergie(){
	if (equipes[equipe].getExplorateur() instanceof Explorateur && ((Explorateur)equipes[equipe].getExplorateur()).getSurnavire())
		((Explorateur)equipes[equipe].getExplorateur()).setEnergy(10);
	if (equipes[equipe].getVoleur() instanceof Voleur && ((Voleur)equipes[equipe].getVoleur()).getSurnavire())
		((Voleur)equipes[equipe].getVoleur()).setEnergy(10);
	if (equipes[equipe].getPiegeur() instanceof Piegeur && ((Piegeur)equipes[equipe].getPiegeur()).getSurnavire())
		((Piegeur)equipes[equipe].getPiegeur()).setEnergy(10);
	if (equipes[equipe].getGuerrier() instanceof Guerrier && ((Guerrier)equipes[equipe].getGuerrier()).getSurnavire())
		((Guerrier)equipes[equipe].getGuerrier()).setEnergy(10);
}
public static void infoEnergie(){
	String message="Energie :\n ";
	if (equipes[equipe].getExplorateur() instanceof Explorateur)
		message+="-Explorateur"+((Explorateur)equipes[equipe].getExplorateur()).getEnergy()+"\n ";
	if (equipes[equipe].getVoleur() instanceof Voleur)
		message+="-Voleur"+((Voleur)equipes[equipe].getVoleur()).getEnergy()+"\n ";
	if (equipes[equipe].getPiegeur() instanceof Piegeur)
		message+="-Piegeur"+((Piegeur)equipes[equipe].getPiegeur()).getEnergy()+"\n ";
	if (equipes[equipe].getGuerrier() instanceof Guerrier)
		message+="-Guerrier"+((Guerrier)equipes[equipe].getGuerrier()).getEnergy()+"\n ";
							
	grille[equipe].setConsole(message);
}
public static void initParametres(){
	ile=new Ile(taille,rocher);
	grille[0]=new Plateau(elements,taille,true,"Plateau de jeu");
	grille[1]=new Plateau(elements,taille,true,"Plateau de jeu");
	grille[2]=new Plateau(elements,6,true,"Navire");
	grille[3]=new Plateau(elements,6,true,"Navire");
	equipes[0]=new Equipe(membreEquipe0,0);
	equipes[1]=new Equipe(membreEquipe1,1);
}
public static void menuPrincipal(){
	String[] choixMode = {"Jouer", "Mode Teste", "Quitter"};
	int choix = JOptionPane.showOptionDialog(null, "Bienvenue sur l'ile de JAVA !","MENU",JOptionPane.YES_NO_CANCEL_OPTION,
			   JOptionPane.QUESTION_MESSAGE,null,choixMode,choixMode[2]);
	if (choix ==0)
		modeJeu=true;
	if (choix ==1)
		modeJeu=false;
	if (choix ==2)
		quitter=true;
}
public static void menuModeJeu(){
	Fenetre window=new Fenetre(null, "Paramètres", true);
	Parametre params= window.showFenetre();
	setParametres(params);
	initParametres();
}
public static void setParametres(Parametre params){
	taille=params.getParam()[0];
	pourcentage=params.getParam()[1];
	rocher=(int)((taille-2)*(taille-2)*((double)(pourcentage)/(double)(100)));
	membreEquipe0=new boolean []{params.getEquipe(0)[0],params.getEquipe(0)[1],params.getEquipe(0)[2],params.getEquipe(0)[3]};
	membreEquipe1=new boolean []{params.getEquipe(1)[0],params.getEquipe(1)[1],params.getEquipe(1)[2],params.getEquipe(1)[3]};
	brouillard=params.getBrouillard();
}
public static void closeAll(){
	grille[0].close();
	grille[1].close();
	grille[2].close();
	grille[3].close();
}
public static boolean teamDead(int equipe){
	boolean b;
	if (!(equipes[equipe].getExplorateur() instanceof Explorateur)
		&& !(equipes[equipe].getVoleur() instanceof Voleur)
		&& !(equipes[equipe].getPiegeur() instanceof Piegeur)
		&& !(equipes[equipe].getGuerrier() instanceof Guerrier))
		b=true;
	else
		b=false;

	return b;
}
}