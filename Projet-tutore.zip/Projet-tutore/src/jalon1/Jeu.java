package jalon1;

import java.awt.event.InputEvent;
import javax.swing.JOptionPane;
public class Jeu {
	
	public static void main(String[] args) {
		int taille=15;
		int pourcentage=10;
		int rocher=(int)((taille-1)*(taille-1)*((double)(pourcentage)/(double)(100)));
		boolean finished=false;
		String[] elements={"images/mer.png","images/sable.png","images/1.navire.png",
				"images/rocher.png","images/2.navire.png","images/1.explorateur.png",
				"images/2.explorateur.png","images/1.piegeur.png","images/2.piegeur.png",
				"images/arbre","images/coffre.png",};
		Iles ile=new Iles(taille,rocher);
		System.out.println(ile);
		Plateau [] grille=new Plateau [2];
		grille[0]=new Plateau(elements,taille,true);
		grille[0].setJeu(ile.getJeu());
			grille[0].setJeu(ile.getJeu());
			grille[0].affichage();
			//ile.PlacerExplorateurs();
			String choix=null;
			while(!finished){
				grille[0].setJeu(ile.getJeu());
				grille[0].affichage();
				choix=ile.Choix();
				ile.Deplacer(new Explorateur(6,false,false),choix);
				//try{Thread.sleep(1000);}catch(Exception ie){}
				/*while(!finished){
					
				}*/
			}
		//grille[1]=new Plateau(elements,taille,false);
		/*for (int e = 0 ; e < 2 ; e++) {
			grille[e].setJeu(ile.getJeu());
		}*/
		/*int x=1,equipe=0;
		while (!finished){
			InputEvent event ;
			grille[equipe].setJeu(ile.getJeu());
			event =grille[equipe].waitEvent(3000);
			if(x!=taille-2 && ile.getInt(x,4)!=4){
				ile.PlacerCase(new Explorateur(6), x, 4);
				ile.PlacerCase(new Parcelles(2), x-1, 4);
				x++;
			}
			//equipe = 1-equipe ;
		}*/
	}
}
/* 1=mer
 * 2=herbe
 * 3=Navire 1
 * 4=Rocher
 * 5=Navires 2
 * 6=explorateur 1
 * 7=explorateur 2
 * 8=piegeur 1
 * 9=piegeur 2*/