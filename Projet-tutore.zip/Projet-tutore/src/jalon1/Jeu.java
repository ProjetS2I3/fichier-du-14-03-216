package jalon1;

public class Jeu {
	static int taille=15; 
	int tour;
	public static void main(String[] args) {
		int pourcentage=10;
		int rocher=(int)((taille-1)*(taille-1)*((double)(pourcentage)/(double)(100)));
		String[] elements={
				"images/mer.png",
				"images/sable.png",
				"images/1.navire.png",
				"images/rocher.png",
				"images/2.navire.png",
				"images/1.explorateur.png",
				"images/2.explorateur.png",
				"images/1.piegeur.png",
				"images/2.piegeur.png",
				"images/arbre",
				"images/coffre.png",};
		Iles ile=new Iles(taille,rocher);
		SuperPlateau jeu=new SuperPlateau(elements,taille);
		Iles.getActualPositionOf("n");
		Iles.getActualPositionOf("N");
		Iles.placer_Explorateurs();
		jeu.setJeu(ile.getJeu(taille));
		jeu.affichage();
		System.out.println(ile);
		while(true){
			Iles.getActualPositionOf("e");
			Iles.getActualPositionOf("E");
			Deplacement d=new Deplacement("e");
			String choisir=d.choix();
			d.deplacer(choisir);
			jeu.setJeu(ile.getJeu(taille));
			System.out.println(ile);
			jeu.affichage();
		}
	}
	public static  int getTaille(){
		return taille;
	}
}
/* 1=mer
 * 2=herbe
 * 3=Navire 1
 * 4=Rocher
 * 5=Navires 2
 * 6=explorateur 1
 * 7=explorateur 2
 * 8=piegeur 1
 * 9=piegeur 2*/