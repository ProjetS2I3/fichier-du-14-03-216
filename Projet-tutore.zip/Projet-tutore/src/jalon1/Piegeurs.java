package jalon1;

public class Piegeurs {
	int energy;
}
