package jalon1;

public class Piegeurs extends Parcelles{
	int energy;
	/**constructeur par defaut heritant de la classe Parcelle et inclu int energie **/
	public Piegeurs(int n) {
		super(n);
	}
}
