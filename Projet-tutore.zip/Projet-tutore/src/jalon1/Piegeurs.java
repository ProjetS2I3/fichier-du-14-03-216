package jalon1;

public class Piegeurs extends Parcelles{
	int energy;
	public Piegeurs(int n) {
		super(n);
	}
}
