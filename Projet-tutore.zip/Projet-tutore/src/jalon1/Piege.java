package jalon1;
/**
 * La classe Piege est un heritage de Parcelle et est definie par 
 * un entier correspondant a l equipe qui a pose le piege.
 * @author GroupI-Team
 */
public class Piege extends Parcelle {
	private int equipe;
	public Piege(int equipe) {
		super(17);
		this.equipe=equipe;
	}
	public int getEquipe() {
		return equipe;
	}
}
