package jalon1;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.Popup;

public class popUP {
	private JOptionPane pane;
	private String location;
	private ImageIcon img;
	
	
	public popUP(String location){
	 this.pane = new JOptionPane();
	 this.location=location;
	 this.img = new ImageIcon(location);
	}
	public void afficher(String title ,String message){
	    this.pane.showMessageDialog(null, title, message, JOptionPane.INFORMATION_MESSAGE, this.img);
	}
}
