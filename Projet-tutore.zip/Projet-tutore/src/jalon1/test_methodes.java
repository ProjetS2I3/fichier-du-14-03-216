package jalon1;

public class test_methodes {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Equipes eq =new Equipes();
		String res;
		res=Iles.boite_Deplacement();
		System.out.print(res);
		System.out.println(eq.toString());
	}

}
