package jalon1;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
 
public class IHMbarreDeVie extends JFrame
 {
 
  JProgressBar barre_progression;
  static final int MINIMUM=0;
  static final int MAXIMUM=100;
 
  public IHMbarreDeVie()
 {
 	 // Cr�er un objet de la Barre de progression
     barre_progression = new JProgressBar( );
 
     // D�finir la valeur initiale de la barre de progression
     barre_progression.setMinimum(MINIMUM);
     // D�finir la valeur maximale de la barre de progression
     barre_progression.setMaximum(MAXIMUM);
     barre_progression.setBackground(Color.RED);
     barre_progression.setForeground(Color.GREEN);
 
     // Cr�er un JPanel et ajouter la barre de progression dans le JPanel
     JPanel pnl=new JPanel();
     pnl.add(barre_progression);
 
     setTitle("barre de vie");
     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     setContentPane(pnl);
     pack( );
     setVisible(true);

 
  }
 
  public void updateBar(double newValue)
  {
    barre_progression.setValue((int) newValue); // methode permettant de mettre a jour la barre
  }
 
}