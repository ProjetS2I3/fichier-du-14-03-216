package jalon1;

public class Rochers extends Parcelles{
	private boolean clef=false;
	private boolean coffre=false;
	/** Constructeur herite de Parcelle, cree une Parcelle avec comme parametres l entier n, ainsi que deux booleen determinant si la clef ou le coffre sont presents sous le rocher. **/
	public Rochers(int n,boolean clef,boolean coffre) {
		super(n);
		this.clef=clef;
		this.coffre=coffre;
	}
	public Rochers(int n) {
		super(n);
	}
}
