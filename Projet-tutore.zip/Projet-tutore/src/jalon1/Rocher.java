package jalon1;

public class Rocher {
	private Parcelle rocher;
	 private boolean contientClef;
	 private boolean contientCoffre;
	 
	 /* Constructeurs */
	 public Rocher(){
		 this.contientClef=false;
		 this.contientCoffre=false;
		 this.rocher=new Parcelle(3);
	 }
	 public Rocher(boolean contientClef,boolean contientCoffre){
		 this.contientClef=contientClef;
		 this.contientCoffre=contientCoffre;
		 this.rocher=new Parcelle(4);
	 }
	 /*Methodes associee a Rocher */
	 
	public String toString() {
		return this.rocher.toString();
	}
	
	 
}
