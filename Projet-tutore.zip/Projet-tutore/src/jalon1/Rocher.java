package jalon1;

public class Rocher extends Parcelle{
	private boolean clef=false;
	private boolean coffre=false;
	/** Constructeur herite de Parcelle, cree une Parcelle avec comme parametres l entier n, ainsi que deux booleen determinant si la clef ou le coffre sont presents sous le rocher. **/
	public Rocher(int n,boolean clef,boolean coffre) {
		super(n);
		this.clef=clef;
		this.coffre=coffre;
	}
	public Rocher(int n) {
		super(n);
	}
	public boolean getClef(){
		return clef;
	}
	public void setClef(boolean clef){
		this.clef=clef;
	}
	public void setCoffre(boolean coffre){
		this.coffre=coffre;
	}
	public boolean getCoffre(){
		return coffre;
	}
}
