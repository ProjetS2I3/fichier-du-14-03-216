package jalon1;
/**
 * La classe Rocher est un heritage de Parcelle elle peut contenir
 * soit une clef soit un coffre ET le tresor.
 * @author GroupI-Team
 */
public class Rocher extends Parcelle{
	private boolean clef=false,coffre=false,tresor=false;
	/** Constructeur herite de Parcelle, cree une Parcelle avec comme parametres l entier n, ainsi que deux booleen determinant si la clef ou le coffre sont presents sous le rocher. **/
	public Rocher(int n,boolean clef,boolean coffre) {
		super(n);
		this.clef=clef;
		this.coffre=coffre;
		this.tresor=coffre;
	}
	public Rocher(int n) {
		super(n);
	}
	public boolean getClef(){
		return clef;
	}
	public boolean getTresor() {
		return tresor;
	}
	public void setTresor(boolean tresor) {
		this.tresor = tresor;
	}
	public void setClef(boolean clef){
		this.clef=clef;
	}
	public void setCoffre(boolean coffre){
		this.coffre=coffre;
	}
	public boolean getCoffre(){
		return coffre;
	}
}
