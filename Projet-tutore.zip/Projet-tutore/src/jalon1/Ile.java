package jalon1;
import java.util.Random;
import javax.swing.*;

import tps.Plateau;
public class Ile {
	private Plateau plateau;
	/**
	 * javadoc a generer
	 * @param dim
	 */
	public Ile(int dim,boolean alea){
		final String[] gifs={"images/sable.png","images/mer.png","images/rocher.png","images/1.navire.png","images/2.navire.png"};
		int[][] map=new int[dim][dim];
		Navire j1 ,j2;
		plateau=new Plateau(gifs,dim);
		Random rd=new Random();
		//nombre de rochers a choisir 
		final int nbOfRock=(int) (0.1*(dim*dim));
		int x=0,y=0;

		for(int idxC=0;idxC<dim;idxC++){

			for(int idxL=0;idxL<dim;idxL++){

				map[idxC][idxL]=new Parcelle(1).toInt();

				if(idxL==0 ||idxL==dim-1 ||idxC==dim-1||idxC==0 ){

					map[idxC][idxL]=new Parcelle(2).toInt();
				}
			}
		}
		if(alea == true){
			//generation des Rochers
			for(int k=0;k<nbOfRock;k++){

				//dispositions aléatoire 
				x=rd.nextInt(dim);
				y=rd.nextInt(dim); 
				while(x == dim-1 || x==0 || y==dim-1 || y==0){
					x=rd.nextInt(dim);
					y=rd.nextInt(dim); 
				}
				map[x][y]=new Parcelle(3).toInt();
			}
		}else{
			for(int k=0;k<nbOfRock;k++){

				//dispositions aléatoire 
				x=(int)JOptionPane.showInputDialog("Entre l'abscisse :").charAt(0);
				y=(int)JOptionPane.showInputDialog("Entre l'ordonne : ").charAt(0);
				if(x<1 || x>=dim-1 || y<1 || y>=dim-1){
					x=rd.nextInt(dim);
					y=rd.nextInt(dim); 
					System.out.println("erreur le systeme a genere le rocher aleatoirement");
				}
				map[x][y]=new Parcelle(3).toInt();
			}
		}
		/*Generation des navires */
		j1=new Navire(false,true,0,0);
		map[j1.getAbscisse()][j1.getOrdonne()+dim/2]=new Parcelle(4).toInt();
		j2=new Navire(false,true,dim-1,dim-1);
		map[j2.getAbscisse()][j2.getOrdonne()/2]=new Parcelle(5).toInt();
		plateau.setJeu(map);

	}
	public void Verifier(){
		/*Verification */
		boolean flag=false;
		int x,y;
		Random rd=new Random();
		int[][]tmp=plateau.getJeu();
		for(int idxL=0;idxL<tmp.length;idxL++){
			for(int idxC=0;idxC<tmp.length;idxC++){
				do{
					if(tmp[idxL][idxC]==3 && tmp[idxL][idxC-1]==3 && tmp[idxL-1][idxC-1]==3){
						tmp[idxL][idxC]=new Parcelle(1).toInt();
						tmp[idxL][idxC]=new Parcelle(3).toInt();
						flag=true;
					}
					plateau.setJeu(tmp);
						

				}		
				while(!flag);
			}
		}
		
	}
	public void affichage() {

		this.plateau.affichage();

	}



	/* Methode d'affichage */



}
