package jalon1;
import jalon1.*;
import javax.swing.JOptionPane;

public class Deplacement {
	private Parcelles[][] tmp_Ile;
	static int taille;
private int pos_X;
	private int pos_Y;
	static int valeur_X_apresDeplacement;
	static int valeur_Y_apresDeplacement;

	/*Recup de la table */
	public Deplacement(String entitee){
		Iles.getActualPositionOf(entitee);
		if(entitee == "e"){
			this.pos_X=Iles.coordonnes_personnages[0];//position actuelle du joueur selectionné X
			this.pos_Y=Iles.coordonnes_personnages[1];//position actuelle du joueur selectionné Y
		}else if(entitee == "E"){
		this.pos_X=Iles.coordonnes_personnages[2];//position actuelle du joueur selectionné X
		this.pos_Y=Iles.coordonnes_personnages[3];//position actuelle du joueur selectionné Y
		}
		Deplacement.taille=Jeu.taille;
		this.tmp_Ile=Iles.ile;
	}


	/**foction de deplacement **/
	public String choix(){
		String[] deplacements = new String[]{"Nord","Sud","Est","Ouest"};
		String[] deplacements_possibles;//contient uniquement les deplacements possibles;
		String choix = null;

		String operateur = (String)JOptionPane.showInputDialog(null,"Choississez un deplacement",
				"Direction",JOptionPane.QUESTION_MESSAGE, null, deplacements, deplacements[0]);
		if(deplacements[0].equals(operateur)){
			choix = deplacements[0];
		}
		else if (deplacements[1].equals(operateur)){
			choix=deplacements[1];
		}
		else if (deplacements[2].equals(operateur)){
			choix=deplacements[2];
		}
		else if (deplacements[3].equals(operateur)){
			choix=deplacements[3];
		}
		return choix;
	}
	/** @author brisseta @params choix revoie faux si deplacement possible vrai sinon **/
	/*faux si case voulue <> de rocher ou eau (bateau ennemis a faire */
	public boolean estbloque(String choix){
		if(choix.equals("Nord")){
			if(tmp_Ile[pos_X][pos_Y+1].equals(new Parcelles(1)) ||tmp_Ile[pos_X][pos_Y+1].equals(new Parcelles(4))){
				JOptionPane.showMessageDialog(null,"deplacement impossible vers l' "+choix) ;
				return true;
			}else{
				valeur_X_apresDeplacement=pos_X;
				valeur_Y_apresDeplacement=pos_Y+1;
			}
		}else if(choix.equals("Sud")){
			if(tmp_Ile[pos_X][pos_Y-1].equals(new Parcelles(1)) ||tmp_Ile[pos_X][pos_Y-1].equals(new Parcelles(4))){
				JOptionPane.showMessageDialog(null,"deplacement impossible vers l' "+choix) ;
				return true;
			}else{
				valeur_X_apresDeplacement=pos_X;                                               //deplacements impossibles si rocher ou eau pour le 
				valeur_Y_apresDeplacement=pos_Y-1;												//moment (rajouter le bateau ennemis apres !
			}

		}else if(choix.equals("Est")){
			if(tmp_Ile[pos_X+1][pos_Y].equals(new Parcelles(1))||tmp_Ile[pos_X+1][pos_Y].equals(new Parcelles(4))){
				JOptionPane.showMessageDialog(null,"deplacement impossible vers l' "+choix) ;
				return true;
			}else{
				valeur_X_apresDeplacement=pos_X+1;
				valeur_Y_apresDeplacement=pos_Y;
			}

		}else if(choix.equals("Ouest")){
			if(tmp_Ile[pos_X-1][pos_Y].equals(new Parcelles(1)) ||tmp_Ile[pos_X-1][pos_Y].equals(new Parcelles(4))){
				JOptionPane.showMessageDialog(null,"deplacement impossible vers l' "+choix) ;
				return true;
			}else{
				valeur_X_apresDeplacement=pos_X-1;
				valeur_Y_apresDeplacement=pos_Y;
			}

		}
		return false;
	}
	public void deplacer(String choix){
		if(choix.equals("Nord")&&this.estbloque(choix)){
			Parcelles sauvegarde=tmp_Ile[pos_X][pos_Y];
			tmp_Ile[pos_X][pos_Y]=tmp_Ile[valeur_X_apresDeplacement][valeur_Y_apresDeplacement];
			tmp_Ile[valeur_X_apresDeplacement][valeur_Y_apresDeplacement]=sauvegarde;

		}else if(choix.equals("Sud")&&this.estbloque(choix)){
			Parcelles sauvegarde=tmp_Ile[pos_X][pos_Y];
			tmp_Ile[pos_X][pos_Y]=tmp_Ile[valeur_X_apresDeplacement][valeur_Y_apresDeplacement];
			tmp_Ile[valeur_X_apresDeplacement][valeur_Y_apresDeplacement]=sauvegarde;

		}else if(choix.equals("Est")&&this.estbloque(choix)){
			Parcelles sauvegarde=tmp_Ile[pos_X][pos_Y];
			tmp_Ile[pos_X][pos_Y]=tmp_Ile[valeur_X_apresDeplacement][valeur_Y_apresDeplacement];
			tmp_Ile[valeur_X_apresDeplacement][valeur_Y_apresDeplacement]=sauvegarde;

		}else if(choix.equals("Ouest")&&this.estbloque(choix)){
			Parcelles sauvegarde=tmp_Ile[pos_X][pos_Y];
			tmp_Ile[pos_X][pos_Y]=tmp_Ile[valeur_X_apresDeplacement][valeur_Y_apresDeplacement];
			tmp_Ile[valeur_X_apresDeplacement][valeur_Y_apresDeplacement]=sauvegarde;
		}
		Iles.ile=tmp_Ile;
	}
}
