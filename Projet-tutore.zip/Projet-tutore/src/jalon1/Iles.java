package jalon1;

import java.util.Random;
public class Iles {
	private Parcelles [][]ile;
	private int rocher=0;
	private Random r=new Random();
	/** Constructeur par defaut sans parametres, cree un tableau 10x10 de Parcelles et initialise ce tableau via la methode init(). **/
	public Iles(){
		ile=new Parcelles[10][10];
		init(10);
	}
	/** Constructeur avec en parametre la taille de l'ile ainsi que le nombre de rocher sur l ile, et initialise ce tableau via la methode init().**/
	public Iles(int taille,int nbrocher){
		ile=new Parcelles[taille][taille];
		init(nbrocher);
	}
	/** Initialise les elements de l ile (mer ,navires ,rochers ,clef ,coffre). **/
	public void init(int nbrocher){
		int x,y;
		for (int i=0 ; i< ile.length ; i++){
			for (int j=0 ; j< ile.length ; j++){
				if (i==0 || i==ile.length-1 || j==0 || j==ile.length-1){
					this.ile[i][j]=new Parcelles(1);
				}else{
				PlacerCase(new Parcelles(2), i, j);}
			}
		}
		x=r.nextInt(ile.length-2)+1;
		y=r.nextInt(2);
		if(y==0){
			PlacerCase(new Navires(3,true), x, 0);
			PlacerCase(new Navires(5,false), ile.length-1-x, ile.length-1);
		}else {
			PlacerCase(new Navires(3,true), 0, x);
			PlacerCase(new Navires(5,false), ile.length-1, ile.length-1-x);
		}
		while (rocher<nbrocher){
			x=r.nextInt(ile.length-2)+1;
			y=r.nextInt(ile.length-2)+1;
			if (ile[x][y].remplacable() && rocherPlacable(x, y)){
			    rocher++;
				PlacerCase(new Rochers(4), x, y);
			}
		}
		placerClefCoffre(nbrocher);
	}
	/** Renvoie un booleen, vrai si la parcelle correspondante (parametres x et y) n a pas de rochers ou de navires adjacents. **/
	public boolean rocherPlacable(int x,int y){
		if (ile[x][y+1].getInt()==4 || 
			ile[x][y-1].getInt()==4 || 
			ile[x+1][y].getInt()==4 || 
			ile[x-1][y].getInt()==4 ||
			ile[x][y-1].getInt()==3 ||
			ile[x][y+1].getInt()==3 ||
			ile[x+1][y].getInt()==3 || 
			ile[x-1][y].getInt()==3 ||
			ile[x][y-1].getInt()==5 ||
			ile[x][y+1].getInt()==5 ||
			ile[x+1][y].getInt()==5 || 
			ile[x-1][y].getInt()==5 /*||
			ile[x+1][y+1].getInt()==4 || 
			ile[x+1][y-1].getInt()==4 || 
			ile[x-1][y+1].getInt()==4 || 
			ile[x-1][y-1].getInt()==4*/){
			return false;
		}
		return true;
	}
	/** Place la clef ainsi que le coffre sous deux rochers distinct, prend en parametre le nombre de rochers sur l ile. **/
	public void placerClefCoffre(int rocher){
		int nbRocher=0;
		Random r=new Random();
		int Rclef=r.nextInt(rocher)+1;
		int Rcoffre;
		do{
		Rcoffre=((r.nextInt(rocher)+1+5)%rocher)+1;
		}while (Rcoffre==Rclef);
		boolean clef=false,coffre=false;
			for (int i=0 ; i<ile.length ; i++){
				for (int j=0 ; j<ile.length ; j++){
					if (ile[i][j].getInt()==4){nbRocher++;}
					if (nbRocher==Rclef && !clef){PlacerCase(new Rochers(4,true,false), i, j); clef=true;/*System.out.println("Clef sous le "+nbRocher+"eme rocher en x="+i+" et y="+j);*/}
					if (nbRocher==Rcoffre && !coffre){PlacerCase(new Rochers(4,false,true), i, j);coffre=true;/*System.out.println("Coffre sous le "+nbRocher+"eme rocher en x="+i+" et y="+j);*/}
				}
			}
	}
	/** Renvoie un tableau d'entier ou chaque entier correspond a l entier de sa parcelle. **/
	public int [][] getJeu(int taille){
		int [][] result=new int [taille][taille];
		for (int i=0 ; i<result.length ; i++){
			for (int j=0 ; j<result.length ; j++){
				result[i][j]=ile[i][j].getInt();
			}
		}
		return result;
	}
	/** Place un element (Parcelles) a la case correspondante (x,y) du tableau de Parcelles ile, parametres : l element, coordonnees x et y. **/
	public void PlacerCase(Parcelles element,int x,int y){
		ile[x][y]=element;
	}
	/** Renvoie une chaine correspondant a l affichage texte de l ile. **/
	/*public String toString(){
		String result="";
		for (int i=0 ; i<ile.length ; i++){
			for (int j=0 ; j<ile.length ; j++){
				result+=" "+ile[j][i];
			}result+="\n";
		}
		return result;
	}*/
	public String toString() {
		String s = "";
		for (int i = 0 ; i < ile.length ; i++) {
			s += "+";
			for (int j = 0 ; j < ile.length ; j++) {
				s += "---+";
			}
			s += "\n|";

			for (int k = 0 ; k < ile.length ; k++) {
				s += " ";
				if (ile[k][i].getInt()==1){s +="~";}
				if (ile[k][i].getInt()==2){s +=" ";}
				if (ile[k][i].getInt()==3){s +="N";}
				if (ile[k][i].getInt()==4){s +="R";}
				if (ile[k][i].getInt()==5){s +="n";}// Ici la valeur des cases
				s += " |";
			}
			s += "\n";
		}
		s += "+";
		for (int l = 0 ; l < ile.length ; l++) {
			s += "---+";
		}
		return s;
	}
}