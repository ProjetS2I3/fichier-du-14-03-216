package jalon1;

import java.util.Random;

import javax.swing.JOptionPane;
public class Iles {
	static Parcelles [][]ile;
	private int rocher=0;
	private Random r=new Random();
	/** Constructeur par defaut sans parametres, cree un tableau 10x10 de Parcelles et initialise ce tableau via la methode init(). **/
	public Iles(){
		ile=new Parcelles[10][10];
		init(10);
	}
	/** Constructeur avec en parametre la taille de l'ile ainsi que le nombre de rocher sur l ile, et initialise ce tableau via la methode init().**/
	public Iles(int taille,int nbrocher){
		ile=new Parcelles[taille][taille];
		init(nbrocher);
	}
	/** Initialise les elements de l ile (mer ,navires ,rochers ,clef ,coffre). **/
	public void init(int nbrocher){
		int x,y;
		for (int i=0 ; i< ile.length ; i++){
			for (int j=0 ; j< ile.length ; j++){
				if (i==0 || i==ile.length-1 || j==0 || j==ile.length-1){
					this.ile[i][j]=new Parcelles(1);
				}else{
					PlacerCase(new Parcelles(2), i, j);}
			}
		}
		x=r.nextInt(ile.length-2)+1;
		y=r.nextInt(2);
		if(y==0){
			PlacerCase(new Navires(3,true), x, 0);
			coordonees_bateaux[0]=x;
			coordonees_bateaux[1]=0;
			PlacerCase(new Navires(5,false), ile.length-1-x, ile.length-1);
			coordonees_bateaux[2]=ile.length-1-x;
			coordonees_bateaux[3]=ile.length-1;
			
		}else {
			PlacerCase(new Navires(3,true), 0, x);
			coordonees_bateaux[0]=0;
			coordonees_bateaux[1]=x;
			PlacerCase(new Navires(5,false), ile.length-1, ile.length-1-x);
			coordonees_bateaux[2]=ile.length-1;
			coordonees_bateaux[3]=ile.length-1-x;
		}
		while (rocher<nbrocher){
			x=r.nextInt(ile.length-2)+1;
			y=r.nextInt(ile.length-2)+1;
			if (ile[x][y].remplacable() && rocherPlacable(x, y)){
				rocher++;
				PlacerCase(new Rochers(4), x, y);
			}
		}
		placerClefCoffre(nbrocher);
	}
	/** Renvoie un booleen, vrai si la parcelle correspondante (parametres x et y) n a pas de rochers ou de navires adjacents. **/
	public boolean rocherPlacable(int x,int y){
		if (ile[x][y+1].getInt()==4 || 
				ile[x][y-1].getInt()==4 || 
				ile[x+1][y].getInt()==4 || 
				ile[x-1][y].getInt()==4 ||
				ile[x][y-1].getInt()==3 ||
				ile[x][y+1].getInt()==3 ||
				ile[x+1][y].getInt()==3 || 
				ile[x-1][y].getInt()==3 ||
				ile[x][y-1].getInt()==5 ||
				ile[x][y+1].getInt()==5 ||
				ile[x+1][y].getInt()==5 || 
				ile[x-1][y].getInt()==5 /*||
			ile[x+1][y+1].getInt()==4 || 
			ile[x+1][y-1].getInt()==4 || 
			ile[x-1][y+1].getInt()==4 || 
			ile[x-1][y-1].getInt()==4*/){
			return false;
		}
		return true;
	}
	/** Place la clef ainsi que le coffre sous deux rochers distinct, prend en parametre le nombre de rochers sur l ile. **/
	public void placerClefCoffre(int rocher){
		int nbRocher=0;
		Random r=new Random();
		int Rclef=r.nextInt(rocher)+1;
		int Rcoffre;
		do{
			Rcoffre=((r.nextInt(rocher)+1+5)%rocher)+1;
		}while (Rcoffre==Rclef);
		boolean clef=false,coffre=false;
		for (int i=0 ; i<ile.length ; i++){
			for (int j=0 ; j<ile.length ; j++){
				if (ile[i][j].getInt()==4){nbRocher++;}
				if (nbRocher==Rclef && !clef){PlacerCase(new Rochers(4,true,false), i, j); clef=true;/*System.out.println("Clef sous le "+nbRocher+"eme rocher en x="+i+" et y="+j);*/}
				if (nbRocher==Rcoffre && !coffre){PlacerCase(new Rochers(4,false,true), i, j);coffre=true;/*System.out.println("Coffre sous le "+nbRocher+"eme rocher en x="+i+" et y="+j);*/}
			}
		}
	}
	/** Renvoie un tableau d'entier ou chaque entier correspond a l entier de sa parcelle. **/
	public int [][] getJeu(int taille){
		int [][] result=new int [taille][taille];
		for (int i=0 ; i<result.length ; i++){
			for (int j=0 ; j<result.length ; j++){
				result[i][j]=ile[i][j].getInt();
			}
		}
		return result;
	}
	/** Place un element (Parcelles) a la case correspondante (x,y) du tableau de Parcelles ile, parametres : l element, coordonnees x et y. **/
	public void PlacerCase(Parcelles element,int x,int y){
		ile[x][y]=element;
	}
	/** Renvoie une chaine correspondant a l affichage texte de l ile. **/
	/*public String toString(){
		String result="";
		for (int i=0 ; i<ile.length ; i++){
			for (int j=0 ; j<ile.length ; j++){
				result+=" "+ile[j][i];
			}result+="\n";
		}
		return result;
	}*/
	public String toString() {
		String s = "";
		for (int i = 0 ; i < ile.length ; i++) {
			s += "+";
			for (int j = 0 ; j < ile.length ; j++) {
				s += "---+";
			}
			s += "\n|";

			for (int k = 0 ; k < ile.length ; k++) {
				s += " ";
				if (ile[k][i].getInt()==1){s +="~";}
				if (ile[k][i].getInt()==2){s +=" ";}
				if (ile[k][i].getInt()==3){s +="N";}
				if (ile[k][i].getInt()==4){s +="R";}
				if (ile[k][i].getInt()==5){s +="n";}// Ici la valeur des cases
				if(ile[k][i].getInt()==6){s +="e";}
				if(ile[k][i].getInt()==7){s +="E";}
				s += " |";
			}
			s += "\n";
		}
		s += "+";
		for (int l = 0 ; l < ile.length ; l++) {
			s += "---+";
		}
		return s;
	}

	/*Ajouts du jalon 2 (deplacementes) */
	//__________________________________________________________________________________________________________________________________
	/* exporateur J1 xpos [0]
	 * explorateur J1 ypos[1]
	 * explorateur J2 xpos[2]
	 * explorateur J2 ypos[3]
	 * 			
	 */
	static int[]coordonnes_personnages;//toutes les 2 cases x|y 
	public static void getActualPositionOf(String entitee){
		//a faire : porcours l'ile a la recherche des pos explo J1
		for(int idxL=0;idxL<ile.length;idxL++){
			for(int idxC=0;idxC<ile.length;idxC++){
				if(ile[idxL][idxC].equals(entitee)){
					if(entitee== "e"){
						coordonnes_personnages[0]=idxL;
						coordonnes_personnages[1]=idxC;
					}else if(entitee == "E"){
						coordonnes_personnages[2]=idxL;
						coordonnes_personnages[3]=idxC;
					}else if(entitee == "n"){
						coordonees_bateaux[0]=idxL;
						coordonees_bateaux[1]=idxC;
					}else if(entitee == "N"){
						coordonees_bateaux[2]=idxL;
						coordonees_bateaux[3]=idxC;
					}
				}
			}
		}
	}
	static int []coordonees_bateaux=new int[4];//meme choses que pour coordonne_personnages
	public static void  placer_Explorateurs(){
		int placement_J1_x=coordonees_bateaux[0];
		int placement_J1_y=coordonees_bateaux[1];
		int placement_J2_x=coordonees_bateaux[2];
		int placement_J2_y=coordonees_bateaux[3];
		//verfication du spawn
		if(ile[coordonees_bateaux[0]+1][coordonees_bateaux[1]].equals(new Parcelles(1))){
			ile[placement_J1_x+1][placement_J1_y]=new Parcelles(6);
			ile[placement_J2_x-1][placement_J2_y]=new Parcelles(7);
		}else{
		//placement des deux explorateurs
		ile[placement_J1_x][placement_J1_y]=new Parcelles(6);
		ile[placement_J2_x][placement_J2_y]=new Parcelles(7);
		}
	}






































}