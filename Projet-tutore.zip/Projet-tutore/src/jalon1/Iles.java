package jalon1;

import java.util.Random;
public class Iles {
	private Parcelles [][]ile;
	private int rocher=0;
	private Random r=new Random();
	public Iles(){
		ile=new Parcelles[10][10];
		init();
	}
	public Iles(int taille){
		ile=new Parcelles[taille][taille];
		init();
	}
	public void init(){
		for (int i=0 ; i< ile.length ; i++){
			for (int j=0 ; j< ile.length ; j++){
				if (i==0 || i==ile.length-1 || j==0 || j==ile.length-1){
					this.ile[i][j]=new Parcelles(1);
				}else{
				PlacerCase(new Parcelles(2), i, j);}
			}
		}
		PlacerCase(new Parcelles(3), 1, 1);
		PlacerCase(new Parcelles(3), ile.length-2, ile.length-2);
		int x,y;
		while (rocher<ile.length*ile.length/10-1){
			x=r.nextInt(ile.length-2)+1;
			y=r.nextInt(ile.length-2)+1;
			if (ile[x][y].remplacable()){
			    rocher++;
				PlacerCase(new Parcelles(4), x, y);
			}
		}
	}
	public int [][] getJeu(int taille){
		int [][] result=new int [taille][taille];
		for (int i=0 ; i<result.length ; i++){
			for (int j=0 ; j<result.length ; j++){
				result[i][j]=ile[i][j].getInt();
			}
		}
		return result;
	}
	public void PlacerCase(Parcelles element,int x,int y){
		ile[x][y]=element;
	}
	public String toString(){
		String result="";
		for (int i=0 ; i<ile.length ; i++){
			for (int j=0 ; j<ile.length ; j++){
				result+=" "+ile[i][j].getInt();
			}result+="\n";
		}
		return result;
	}
}