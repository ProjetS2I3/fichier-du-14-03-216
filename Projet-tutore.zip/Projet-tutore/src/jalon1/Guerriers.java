package jalon1;

public class Guerriers extends Parcelles{
	int energy;
	public Guerriers(int n) {
		super(n);
	}
}
