package jalon1;

public class Guerriers {
	int energy;
}
