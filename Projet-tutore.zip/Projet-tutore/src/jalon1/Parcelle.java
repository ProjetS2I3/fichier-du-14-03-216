package jalon1;
/**
 * La classe Parcelle est definie par un entier ainsi qu un boolean 
 * accessible qui derterminera si la Parcelle est accessible depuis les navires.
 * @author GroupI-Team
 */
public class Parcelle {
	boolean accessible=false;
	private int parcelle;
	/** Constructeur avec entier correspondant en parametre. **/
	public Parcelle (int n){
			this.parcelle=n;
	}
    /** Renvoie l entier correspondant d une parcelle. **/
	public int getInt(){
		return parcelle;
	}
	/** Renvoie l entier correpondant de la parcelle sous la forme d une chaine. **/
	public String toString(){
		return ""+parcelle;
	}
	public void setInt(int parcelle) {
		this.parcelle = parcelle;
	}
	/** Renvoie un booleen vrai si la parcelle est une parcelle vide (une parcelle vide est egale a 2). **/
	public boolean remplacable(){
		if (this.getInt()==2){
			return true;
		}
		else return false;
	}
}
