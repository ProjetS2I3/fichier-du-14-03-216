package jalon1;
public class Parcelle {
	private int element;

	//generation des constructeur

	public Parcelle(int element){

		this.element=element;
	}
	public Parcelle(){
		this.element=0;
	}
	public int toInt(){
		return element;
	}
}