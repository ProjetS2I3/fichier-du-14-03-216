package jalon1;

public class Parcelle {
	private int parcelle;
	/** Constructeur avec entier correspondant en parametre. **/
	public Parcelle (int n){
			this.parcelle=n;
	}
    /** Renvoie l entier correspondant d une parcelle. **/
	public int getInt(){
		return parcelle;
	}
	/** Renvoie l entier correpondant de la parcelle sous la forme d une chaine. **/
	public String toString(){
		return ""+parcelle;
	}
	/** Renvoie un booleen vrai si la parcelle est une parcelle vide (une parcelle vide est egale a 2). **/
	public boolean remplacable(){
		if (this.getInt()==2){
			return true;
		}
		else return false;
	}
}
