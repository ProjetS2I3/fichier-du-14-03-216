package jalon1;
public class GenerationAleatoire {

	public static void main(String[]args){

		final int taille=10;

		System.out.println("Les dimensions par default sont : "+taille+"x"+taille);
		//true si aleatoire , faux sinon (rochers)
		Ile ile=new Ile(taille,true);
		
		ile.Verifier();

		ile.affichage();
	}
}
