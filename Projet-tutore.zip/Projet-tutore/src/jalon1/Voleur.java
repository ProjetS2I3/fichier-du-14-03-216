package jalon1;
/**
 * La classe RIP est un heritage de Personnage
 * @author GroupI-Team
 */
public class Voleur extends Personnage {
	public Voleur(int n) {
		super(n);
	}
}
