package jalon1;

public class Voleur extends Parcelle{
	int energy;
	public Voleur(int n) {
		super(n);
	}
}
