package jalon1;

public class Equipes {
	private Explorateur explorateur;
	private Voleurs voleur;
	
	
	
	public Equipes(Explorateur explorateur, Voleurs voleur) {
		this.explorateur = explorateur;
		this.voleur = voleur;
	} 
	public Equipes(){
		this.explorateur=new Explorateur(6);
		this.voleur=new Voleurs(0);// a inclure dans le String gifs
	}
	@Override
	public String toString() {
		return "Equipes [explorateur=" + explorateur + ", voleur=" + voleur
				+ "]";
	}
	
	

}
