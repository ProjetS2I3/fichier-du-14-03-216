package jalon1;

import tps.Plateau;

public class SuperPlateau {
	private Plateau plateau;
	public SuperPlateau(String[] elements,int taille){
		plateau=new Plateau(elements, taille);
	}
	public void affichage(){
		plateau.affichage();
	}
	public void setJeu(int [][] jeu){
		plateau.setJeu(jeu);
	}
	public int[][] getJeu(){
		return plateau.getJeu();
	}	
	public boolean Deplacer(int x,int y,int a,int b){
		int [][] jeu=this.getJeu();
		if (jeu[a][b]==0){
			jeu [a][b]=jeu[x][y];
			jeu [x][y]=0;
			return true;
		}else{
			return false;
		}
	}
}
