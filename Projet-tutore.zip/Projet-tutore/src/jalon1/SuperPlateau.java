package jalon1;

import tps.Plateau;

public class SuperPlateau {
	/*private String[] elements={"" +
			"images/1.explorateur.png",
			"images/1.navire.png",
			"images/1.piegeur.png",
			"images/2.explorateur.png",
			"images/2.navire.png",
			"images/2.piegeur.png",
			"images/arbre",
			"images/coffre.png",
			"images/mer.png",
			"images/rocher.png"};*/
	private Plateau plateau;
	public SuperPlateau(String[] elements,int taille){
		plateau=new Plateau(elements, taille);
	}
	public void affichage(){
		plateau.affichage();
	}
	public void setJeu(int [][] jeu){
		plateau.setJeu(jeu);
	}
	public int[][] getJeu(){
		return plateau.getJeu();
	}	
	public boolean Deplacer(int x,int y,int a,int b){
		int [][] jeu=this.getJeu();
		if (jeu[a][b]==0){
			jeu [a][b]=jeu[x][y];
			jeu [x][y]=0;
			return true;
		}else{
			return false;
		}
	}
}
