package jalon1;
/**
 * La classe RIP est un heritage de Personnage
 * @author GroupI-Team
 */
public class Piegeur extends Personnage{
	private int nbpiege=5;
	public Piegeur(int n) {
		super(n);
	}
	public int getNbpiege() {
		return nbpiege;
	}
	public void setNbpiege(int nbpiege) {
		this.nbpiege += nbpiege;
	}
}
