package jalon1;

public class Piegeur extends Parcelle{
	int energy;
	public Piegeur(int n) {
		super(n);
	}
}
