package jalon1;

public class Guerrier extends Parcelle{
	int energy;
	public Guerrier(int n) {
		super(n);
	}
}
