package jalon1;
/**
 * La classe RIP est un heritage de Personnage
 * @author GroupI-Team
 */
public class Guerrier extends Personnage{
	public Guerrier(int n) {
		super(n);
	}
	
}
