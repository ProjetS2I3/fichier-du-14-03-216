package jalon1;

public class Equipe {

}
