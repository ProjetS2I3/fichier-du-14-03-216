package jalon1;
/**
 * La classe RIP est un heritage de Personnage
 * @author GroupI-Team
 */
public class Explorateur extends Personnage{
	private boolean coffreFound,tresorFound;
	public Explorateur(int n) {
		super(n);
	}
	public boolean getTresorFound() {
		return tresorFound;
	}
	public void setTresorFound(boolean tresorFound) {
		this.tresorFound = tresorFound;
	}
	public boolean getCoffreFound() {
		return coffreFound;
	}
	public void setCoffreFound(boolean coffreFound) {
		this.coffreFound = coffreFound;
	}
}
