package jalon1;

public class Explorateur extends Parcelles{
	private int energy;
	private boolean contient_clef;
	private boolean contient_coffre;
	public Explorateur(int n) {
		super(n);
		this.contient_clef=false;
		this.contient_coffre=false;
	}
	public Explorateur(int n,boolean clef , boolean coffe){
		super(n);
		this.contient_clef=clef;
		this.contient_coffre=coffe;
	}
	
}
