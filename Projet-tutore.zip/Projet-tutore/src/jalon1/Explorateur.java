package jalon1;

public class Explorateur extends Parcelle{
	private int energy;
	private boolean clef,coffre;
	public Explorateur(int n) {
		super(n);
	}
	public boolean getCoffre(){
		return coffre;
	}
	public boolean getClef(){
		return clef;
	}
	public void setClef(boolean clef){
		this.clef=clef;
	}
	public void setCoffre(boolean coffre){
		this.coffre=coffre;
	}
}
