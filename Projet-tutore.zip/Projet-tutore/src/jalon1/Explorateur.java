package jalon1;

public class Explorateur extends Parcelles{
	private int energy;
	private boolean clef,coffre;
	public Explorateur(int n,boolean clef,boolean coffre) {
		super(n);
		this.clef=clef;
		this.coffre=coffre;
	}
	public boolean getCoffre(){
		return coffre;
	}
	public boolean getClef(){
		return clef;
	}
	public void setClef(boolean clef){
		this.clef=clef;
	}
	public void setCoffre(boolean coffre){
		this.coffre=coffre;
	}
}
