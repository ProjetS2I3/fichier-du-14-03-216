package jalon1;

public class Parcelles {
	//private final int vide=0,rocher=1,coffre=2,clef=3,navire=4,explorateur=5,voleur=6,clefsousrocher=7,coffresousrocher=8;
	private int parcelle;
	public Parcelles (int n){
		this.parcelle=n;
	}
	public int getInt(){
		return parcelle;
	}
	public boolean remplacable(){
		if (this.getInt()==2){
			//System.out.println("erfghjk");
			return true;
		}
		else return false;
	}
}
