package jalon1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.TextField;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.xml.ws.Action;

public class IHM {
	static JFrame frame;/**frame **/
	static JPanel pane; /**Panel**/
	@SuppressWarnings("deprecation")
	@Action
	/**frame size : dim de l'ecran -50 pour la largeur **/
	public static void main(String[] args) {
		/*initialisation de la frame*/
		Dimension dimension = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		final int taskbarpadding=50;
		int height = (int)dimension.getHeight();
		int width  = (int)dimension.getWidth();
		frame=new JFrame("Treasure_Hunt");
		pane=new JPanel();
		frame.getContentPane().setBackground(Color.darkGray);
		frame.setSize(width,height-taskbarpadding);
		/**action a faire avant premier afficahge (generatuion de l'interface**/
		MenuGeneration();
		frame.setVisible(false);
	}
	public static void MenuGeneration(){

		JButton gameaccess= new JButton("acces au JEU");
		gameaccess.setSize(400, 400);
		JButton testaccess=new JButton("acces au menu de tests");
		testaccess.setSize(400, 400);
		JFrame menu=new JFrame("Menu");
		menu.setSize(500, 200);
		menu.add(gameaccess,BorderLayout.NORTH);
		menu.add(testaccess,BorderLayout.SOUTH);
		JTextField tf=new JTextField("Fait ton choix");
		tf.setForeground(Color.red);
		menu.add(tf,BorderLayout.CENTER);
		menu.show();

	}

}
