package jalon1;

public class Voleurs extends Parcelles{
	int energy;
	public Voleurs(int n) {
		super(n);
	}
}
