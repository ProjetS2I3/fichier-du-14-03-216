package jalon1;

public class Voleurs {
	int energy;
}
