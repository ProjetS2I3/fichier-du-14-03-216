package jalon1;

import javax.swing.JOptionPane;

public class Navire extends Parcelle{
	/** Constructeur herite de Parcelle, cree une Parcelle de valeur n=3 qui correspond au navire, prend en parametres l entier n ainsi que le booleen camp qui determinenera a quel joueur appartient le navire.  **/
	public Navire(int n,boolean camp) {
		super(n);
		this.camp=camp;
	}
	private boolean camp;
	private boolean Explorateurs;
	private boolean Guerriers;
	private boolean Voleurs;


	public boolean isCamp() {
		return camp;
	}
	public void setCamp(boolean camp) {
		this.camp = camp;
	}
	public boolean isExplorateurs() {
		return Explorateurs;
	}
	public void setExplorateurs(boolean explorateurs) {
		Explorateurs = explorateurs;
	}
	public boolean isGuerriers() {
		return Guerriers;
	}
	public void setGuerriers(boolean guerriers) {
		Guerriers = guerriers;
	}
	public boolean isVoleurs() {
		return Voleurs;
	}
	public void setVoleurs(boolean voleurs) {
		Voleurs = voleurs;
	}
	public static void debarquement(int equipe, Plateau grille){
		/* 1=mer
		 * 2=herbe
		 * 3=Navire 1
		 * 4=Rocher
		 * 5=Navires 2
		 * 6=explorateur 1
		 * 7=explorateur 2
		 * 8=voleur 1
		 * 9=voleur 2*/
		String[] personnage = new String[]{"Explorateur","Voleur","Piegeur","Guerrier"};
		String choix = (String)JOptionPane.showInputDialog(null,"Choississez le personnage que vous aller debarquer","Personnage",JOptionPane.QUESTION_MESSAGE, null, personnage, personnage[0]);
		switch (equipe) {
		case 0:
			switch (choix) {
			case "Explorateur":
				grille.println("Explorateur debarqu�");
				Ile.PlacerCase(new Parcelle(6), Jeu.x, Jeu.y);
				break;
			case "Voleur":
				grille.println("Voleur debarqu�");
				Ile.PlacerCase(new Parcelle(8), Jeu.x, Jeu.y);
				break;
			case "Piegeur":
				grille.println("Piegeur debarqu�");
				Ile.PlacerCase(new Parcelle(0), Jeu.x, Jeu.y);
				break;
			case "Guerrier":
				grille.println("Piegeur debarqu�");
				Ile.PlacerCase(new Parcelle(0), Jeu.x, Jeu.y);
				break;
			}

			break;

		case 1:
			switch (choix) {
			case "Explorateur":
				grille.println("Explorateur debarqu�");
				Ile.PlacerCase(new Parcelle(7), Jeu.x, Jeu.y);
				break;
			case "Voleur":
				grille.println("Voleur debarqu�");
				Ile.PlacerCase(new Parcelle(9), Jeu.x, Jeu.y);
				break;
			case "Piegeur":
				grille.println("Piegeur debarqu�");
				Ile.PlacerCase(new Parcelle(0), Jeu.x, Jeu.y);
				break;
			case "Guerrier":
				grille.println("Guerrier debarqu�");
				if(peutEtreDebarque(TEST_menu.ile,1) == true)
					Ile.PlacerCase(new Parcelle(0), Jeu.x, Jeu.y);
				break;
			}
			break;
		}
	}
	public static boolean peutEtreDebarque(Ile i, int joueur){
		int[][]tmp=i.getJeu();
		if(joueur == 0){
			if(tmp[Plateau.x][Plateau.y] == 3){
				return true;
			}
		}else if(joueur == 1){
			if(tmp[Plateau.x][Plateau.y] == 5){
				return true;
			}
		}
		return false;
	}
	public static void direction(int equipe){
		String []directions=new String[]{"Nord","Sud","Est","Ouest"};
		String direction=(String) ( JOptionPane.showInputDialog(null,"Choississez le personnage que vous aller debarquer","Personnage",JOptionPane.QUESTION_MESSAGE, null, directions, directions[0]));
		switch (direction) {
		case "Nord":
			if(equipe == 0){
				Jeu.x=Ile.SearchElement(new Parcelle(3))[0];
				Jeu.y=Ile.SearchElement(new Parcelle(3))[1]+1;
			}else{
				Jeu.x=Ile.SearchElement(new Parcelle(5))[0];
				Jeu.y=Ile.SearchElement(new Parcelle(5))[1]+1;
			}
			break;

		case "Sud":
			if(equipe == 0){
				Jeu.x=Ile.SearchElement(new Parcelle(3))[0];
				Jeu.y=Ile.SearchElement(new Parcelle(3))[1]-1;
			}else{
				Jeu.x=Ile.SearchElement(new Parcelle(5))[0];
				Jeu.y=Ile.SearchElement(new Parcelle(5))[1]-1;
			}
			break;
		case "Est":
			if(equipe == 0){
				Jeu.x=Ile.SearchElement(new Parcelle(3))[0]+1;
				Jeu.y=Ile.SearchElement(new Parcelle(3))[1];
			}else{
				Jeu.x=Ile.SearchElement(new Parcelle(5))[0]+1;
				Jeu.y=Ile.SearchElement(new Parcelle(5))[1];
			}
			break;
		case "Ouest":
			if(equipe == 0){
				Jeu.x=Ile.SearchElement(new Parcelle(3))[0]-1;
				Jeu.y=Ile.SearchElement(new Parcelle(3))[1];
			}else{
				Jeu.x=Ile.SearchElement(new Parcelle(5))[0]-1;
				Jeu.y=Ile.SearchElement(new Parcelle(5))[1];
			}
			break;
		}
	}

}
