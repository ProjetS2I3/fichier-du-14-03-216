package jalon1;
import java.util.Random;
public class Navire {
	private boolean statut;
	private Parcelle parcelle;
	private int x;
	private int y;
	//debut des methodes

	public Navire(boolean statut,boolean joueur){
		this.statut=statut;
		//true pour J1 ; False pour J2
		if(joueur == true){
			this.parcelle=new Parcelle(3);
		}else{
			this.parcelle=new Parcelle(4);
		}
		//Ile map = map.getMap(map);
	}
	/*Constructeur par defaut */
	public Navire(){
		this.statut=false;
		this.parcelle=new Parcelle(0);
	}
	/*Constructeur complet */
	public Navire(boolean statut,boolean joueur,int x,int y){
		this.statut=statut;
		if(joueur == true)
			this.parcelle=new Parcelle(3);
		else
			this.parcelle=new Parcelle(4);
		this.x=x;
		this.y=y;
	}
	public int getAbscisse(){
		return this.x;
	}
	public int getOrdonne(){
		return this.y;
	}

	public String toString() {
		return  parcelle.toString();
	}


}
