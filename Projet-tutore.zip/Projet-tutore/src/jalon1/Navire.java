package jalon1;

public class Navire extends Parcelle{
	/** Constructeur herite de Parcelle, cree une Parcelle de valeur n=3 qui correspond au navire, prend en parametres l entier n ainsi que le booleen camp qui determinenera a quel joueur appartient le navire.  **/
	public Navire(int n,boolean camp) {
		super(n);
		this.camp=camp;
	}
	private boolean camp;
	private boolean Explorateurs;
	private boolean Guerriers;
	private boolean Voleurs;

}
