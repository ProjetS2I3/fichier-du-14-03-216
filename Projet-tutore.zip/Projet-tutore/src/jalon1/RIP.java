package jalon1;
/**
 * La classe RIP est un heritage de Parcelle
 * @author GroupI-Team
 */
public class RIP extends Parcelle{
	boolean clef=false,tresor=false;
	public RIP(boolean clef,boolean tresor) {
		super(18);
		this.clef=clef;
		this.tresor=tresor;
	}
	public boolean getClef() {
		return clef;
	}
	public void setClef(boolean clef) {
		this.clef = clef;
	}
	public boolean getTresor() {
		return tresor;
	}
	public void setTresor(boolean tresor) {
		this.tresor = tresor;
	} 
}
