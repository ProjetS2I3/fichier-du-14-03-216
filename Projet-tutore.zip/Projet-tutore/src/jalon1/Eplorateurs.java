package jalon1;

public class Eplorateurs extends Parcelles{
	int energy;
	public Eplorateurs(int n) {
		super(n);
	}
}
