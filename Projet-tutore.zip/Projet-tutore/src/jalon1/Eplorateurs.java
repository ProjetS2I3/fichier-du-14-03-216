package jalon1;

public class Eplorateurs {
	int energy;
}
